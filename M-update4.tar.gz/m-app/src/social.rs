use crate::{
    api::{call, dial_code, file_url, invite_link, to_e164, url_encode, Contact, MatchUser, Method, PublicUser, User, API},
    avatar,
    i18n::{err_text, tr},
    login::Icon,
    Ctx,
};
use dioxus::prelude::*;
use gloo_storage::{LocalStorage, Storage};
use serde_json::{json, Value};
use std::collections::{HashMap, HashSet};

/// Full-screen pages that sit on top of the tabs.
#[derive(Clone, PartialEq)]
pub enum Overlay {
    None,
    Contacts,
    Profile(String),
    Chat(String),
    Story(String),
    NewStory,
}

pub const ICON_BACK: &str = "M15 6l-6 6 6 6";
pub const ICON_SEARCH: &str = "M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM21 21l-4.3-4.3";

/// Finds or creates the one-to-one chat with a connected person. Returns the chat id.
pub async fn open_chat(token: Option<String>, user_id: String) -> Option<String> {
    let v = call(Method::POST, "/chats/open", Some(json!({ "user_id": user_id })), token).await.ok()?;
    v["id"].as_str().map(|s| s.to_string())
}

// ---------------------------------------------------------------- uploads

/// Runs in the browser: shrinks a photo, then sends the chosen file straight to the server.
/// Replies with the updated profile, or { error: "code" }.
const UPLOAD_JS: &str = r#"
(async () => {
  const input = document.getElementById('__ID__');
  try {
    const f = input && input.files && input.files[0];
    if (!f) { dioxus.send({ error: 'generic' }); return; }
    let body = f, type = f.type;
    if (f.type.startsWith('image/')) {
      const bmp = await createImageBitmap(f);
      const s = Math.min(1, __MAX__ / Math.max(bmp.width, bmp.height));
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(bmp.width * s));
      c.height = Math.max(1, Math.round(bmp.height * s));
      c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
      body = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.85));
      type = 'image/jpeg';
    } else if (!__VIDEO__) {
      dioxus.send({ error: 'unsupported_file' }); return;
    } else if (f.size > 20 * 1024 * 1024) {
      dioxus.send({ error: 'file_too_large' }); return;
    }
    const r = await fetch('__URL__', {
      method: 'POST',
      headers: { 'Authorization': 'Bearer __TOKEN__', 'Content-Type': type },
      body: body
    });
    const t = await r.text();
    let j = {};
    try { j = JSON.parse(t); } catch (e) {}
    dioxus.send(r.ok ? j : { error: j.error || 'generic' });
  } catch (e) {
    dioxus.send({ error: 'network' });
  } finally {
    if (input) input.value = '';
  }
})();
"#;

/// Uploads the file chosen in `<input id=input_id type=file>` to `path` and returns the server's JSON answer.
pub async fn upload_value(input_id: &str, path: &str, max_dim: u32, allow_video: bool, token: Option<String>) -> Result<Value, String> {
    let token = token.ok_or_else(|| "unauthorized".to_string())?;
    let js = UPLOAD_JS
        .replace("__ID__", input_id)
        .replace("__MAX__", &max_dim.to_string())
        .replace("__VIDEO__", if allow_video { "true" } else { "false" })
        .replace("__URL__", &format!("{API}{path}"))
        .replace("__TOKEN__", &token);
    let mut ev = document::eval(&js);
    let v: Value = ev.recv::<Value>().await.map_err(|_| "network".to_string())?;
    if let Some(e) = v.get("error").and_then(|e| e.as_str()) {
        return Err(e.to_string());
    }
    Ok(v)
}

/// Same, for uploads that answer with the updated profile.
pub async fn upload(input_id: &str, path: &str, max_dim: u32, allow_video: bool, token: Option<String>) -> Result<User, String> {
    let v = upload_value(input_id, path, max_dim, allow_video, token).await?;
    serde_json::from_value(v).map_err(|_| "generic".to_string())
}

// ---------------------------------------------------------------- banner

/// The profile banner: a ready-made animated gradient, or the person's own photo or looping video.
#[component]
pub fn BannerView(kind: String, preset: i16, url: String) -> Element {
    let src = file_url(&url);
    match kind.as_str() {
        "video" => rsx! {
            div { class: "banner-media",
                video {
                    key: "{src}", class: "banner-vid", src: "{src}",
                    autoplay: true, muted: true, "loop": "true", "playsinline": "true",
                    onmounted: move |_| {
                        let _ = document::eval("document.querySelectorAll('video.banner-vid').forEach(v=>{v.muted=true;v.defaultMuted=true;v.setAttribute('playsinline','');v.play().catch(()=>{});});");
                    },
                }
            }
        },
        "image" => rsx! {
            div { class: "banner-media", img { src: "{src}", alt: "" } }
        },
        _ => rsx! { div { class: "banner b{preset}" } },
    }
}

// ---------------------------------------------------------------- someone else's profile

#[component]
pub fn ProfileView(id: String, mut overlay: Signal<Overlay>) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let mut profile = use_signal(|| None::<PublicUser>);
    let mut missing = use_signal(|| false);

    let load_id = id.clone();
    use_hook(move || {
        spawn(async move {
            match call(Method::GET, &format!("/users/{load_id}"), None, token()).await {
                Ok(v) => profile.set(serde_json::from_value(v).ok()),
                Err(_) => missing.set(true),
            }
        });
    });

    let back_label = tr(&lang(), "back");
    rsx! {
        div { class: "screen",
            div { class: "screen-body",
                header { class: "bar",
                    button {
                        class: "icon-btn", r#type: "button", "aria-label": "{back_label}",
                        onclick: move |_| overlay.set(Overlay::None),
                        Icon { d: ICON_BACK }
                    }
                }
                match profile() {
                    Some(p) => rsx! {
                        section { class: "card profile",
                            BannerView { kind: p.banner_kind.clone(), preset: p.banner, url: p.banner_url.clone() }
                            div { class: "profile-body",
                                img { class: "avatar lg", src: "{avatar::user_uri(&p.avatar_kind, &p.avatar_value)}", alt: "" }
                                h2 { class: "display name", "{p.name}" }
                                p { class: "hint", "{p.bio}" }
                            }
                        }
                    },
                    None => rsx! {
                        p { class: "hint center-text",
                            if missing() { {tr(&lang(), "profile_missing")} } else { {tr(&lang(), "loading")} }
                        }
                    },
                }
            }
        }
    }
}

// ---------------------------------------------------------------- phone contacts

/// Runs in the browser: opens the phone's contact picker (Chrome on Android).
const PICK_JS: &str = r#"
(async () => {
  try {
    if (!('contacts' in navigator) || !navigator.contacts || !navigator.contacts.select) {
      dioxus.send({ error: 'unsupported' }); return;
    }
    const r = await navigator.contacts.select(['name', 'tel'], { multiple: true });
    const out = [];
    for (const c of r) {
      const n = (c.name && c.name[0]) || '';
      for (const t of (c.tel || [])) out.push([n, t]);
    }
    dioxus.send({ ok: out });
  } catch (e) {
    dioxus.send({ error: 'cancelled' });
  }
})();
"#;

#[component]
fn MatchRow(name: String, num: String, m: MatchUser, mut overlay: Signal<Overlay>) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;

    let open = {
        let id = m.id.clone();
        let is_contact = m.is_contact;
        let num = num.clone();
        move |_| {
            let id = id.clone();
            let num = num.clone();
            spawn(async move {
                if !is_contact {
                    let _ = call(Method::POST, "/me/contacts", Some(json!({ "phone": num })), token()).await;
                }
                if let Some(conv) = open_chat(token(), id).await {
                    overlay.set(Overlay::Chat(conv));
                }
            });
        }
    };

    rsx! {
        button { class: "chat-row", r#type: "button", onclick: open,
            img { class: "avatar md", src: "{avatar::user_uri(&m.avatar_kind, &m.avatar_value)}", alt: "" }
            div { class: "chat-main",
                div { class: "chat-name", "{name}" }
                div { class: "chat-sub", {tr(&lang(), "on_m")} }
            }
        }
    }
}

#[component]
fn ContactRow(c: Contact, mut overlay: Signal<Overlay>) -> Element {
    let ctx = use_context::<Ctx>();
    let token = ctx.token;
    let id = c.id.clone();
    rsx! {
        button {
            class: "chat-row", r#type: "button",
            onclick: move |_| {
                let id = id.clone();
                spawn(async move {
                    if let Some(conv) = open_chat(token(), id).await {
                        overlay.set(Overlay::Chat(conv));
                    }
                });
            },
            img { class: "avatar md", src: "{avatar::user_uri(&c.avatar_kind, &c.avatar_value)}", alt: "" }
            div { class: "chat-main", div { class: "chat-name", "{c.name}" } }
        }
    }
}

#[component]
fn InviteRow(name: String, num: String) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let user = ctx.user;

    let code = user().map(|u| u.invite_code).unwrap_or_default();
    let text = format!("{} {}", tr(&lang(), "invite_msg"), invite_link(&code));
    let href = format!("sms:{}?&body={}", num, url_encode(&text));
    let shown = if name.is_empty() { num.clone() } else { name.clone() };
    let initial: String = shown.chars().next().map(|c| c.to_uppercase().to_string()).unwrap_or_else(|| "?".to_string());

    rsx! {
        div { class: "chat-row",
            span { class: "avatar md ph", "{initial}" }
            div { class: "chat-main",
                div { class: "chat-name", "{shown}" }
                div { class: "chat-sub", "{num}" }
            }
            a { class: "add-btn", href: "{href}", {tr(&lang(), "add")} }
        }
    }
}

#[component]
pub fn ContactsScreen(mut overlay: Signal<Overlay>) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let user = ctx.user;

    // The phone book stays on this device. Only the numbers are sent to the server to see who is on M.
    let mut book = use_signal(|| LocalStorage::get::<Vec<(String, String)>>("m_phonebook").unwrap_or_default());
    let mut matches = use_signal(Vec::<MatchUser>::new);
    let mut query = use_signal(String::new);
    let mut note = use_signal(String::new);
    let mut failed = use_signal(|| false);
    let mut busy = use_signal(|| false);
    let mut phone = use_signal(String::new);
    let mut my_contacts = use_signal(Vec::<Contact>::new);
    use_hook(move || {
        spawn(async move {
            if let Ok(v) = call(Method::GET, "/me/contacts", None, token()).await {
                my_contacts.set(serde_json::from_value(v).unwrap_or_default());
            }
        });
    });

    // (name, +number) pairs. Numbers without a country code get the person's own country code.
    let normalized = move || -> Vec<(String, String)> {
        let cc = user()
            .and_then(|u| u.phone)
            .and_then(|p| dial_code(&p))
            .unwrap_or_else(|| "20".to_string());
        let mut seen = HashSet::new();
        book()
            .iter()
            .filter_map(|(n, t)| to_e164(t, &cc).map(|e| (n.clone(), e)))
            .filter(|(_, e)| seen.insert(e.clone()))
            .collect()
    };

    let run_match = move || {
        spawn(async move {
            let list = normalized();
            if list.is_empty() {
                matches.set(Vec::new());
                return;
            }
            busy.set(true);
            let phones: Vec<String> = list.iter().map(|(_, e)| e.clone()).collect();
            match call(Method::POST, "/contacts/match", Some(json!({ "phones": phones })), token()).await {
                Ok(v) => matches.set(serde_json::from_value(v).unwrap_or_default()),
                Err(e) => {
                    failed.set(true);
                    note.set(err_text(&lang(), &e));
                }
            }
            busy.set(false);
        });
    };
    use_hook(move || {
        if !book.read().is_empty() {
            run_match();
        }
    });

    let pick = move |_| {
        spawn(async move {
            let mut ev = document::eval(PICK_JS);
            let v: Value = match ev.recv::<Value>().await {
                Ok(v) => v,
                Err(_) => return,
            };
            if let Some(list) = v.get("ok") {
                let picked: Vec<(String, String)> = serde_json::from_value(list.clone()).unwrap_or_default();
                let mut merged = book();
                for p in picked {
                    if !merged.iter().any(|(_, t)| *t == p.1) {
                        merged.push(p);
                    }
                }
                let _ = LocalStorage::set("m_phonebook", merged.clone());
                book.set(merged);
                failed.set(false);
                note.set(String::new());
                run_match();
            } else if v["error"] == "unsupported" {
                failed.set(true);
                note.set(tr(&lang(), "picker_unsupported"));
            }
        });
    };

    // Invite link and add-by-number (always available, also where the picker is not).
    let link = user().map(|u| invite_link(&u.invite_code)).unwrap_or_default();
    let copy_link = {
        let link = link.clone();
        move |_| {
            // Link characters are limited to letters, digits and URL punctuation, so it is safe in a JS string.
            let _ = document::eval(&format!("navigator.clipboard.writeText('{link}')"));
            failed.set(false);
            note.set(tr(&lang(), "copied"));
        }
    };
    let add_phone = move |_| {
        spawn(async move {
            match call(Method::POST, "/me/contacts", Some(json!({ "phone": phone() })), token()).await {
                Ok(_) => {
                    failed.set(false);
                    note.set(tr(&lang(), "added"));
                    phone.set(String::new());
                }
                Err(e) => {
                    failed.set(true);
                    note.set(if e == "not_found" { tr(&lang(), "not_found") } else { err_text(&lang(), &e) });
                }
            }
        });
    };

    // Split the phone book into people already on M and people to invite.
    let by_number: HashMap<String, MatchUser> = matches()
        .into_iter()
        .filter_map(|m| m.phone.clone().map(|p| (p, m)))
        .collect();
    let q = query().to_lowercase();
    let mut on_m: Vec<(String, String, MatchUser)> = Vec::new();
    let mut others: Vec<(String, String)> = Vec::new();
    for (name, num) in normalized() {
        if !q.is_empty() && !name.to_lowercase().contains(&q) && !num.contains(&q) {
            continue;
        }
        match by_number.get(&num) {
            Some(m) => on_m.push((name, num, m.clone())),
            None => others.push((name, num)),
        }
    }

    let back_label = tr(&lang(), "back");
    let search_ph = tr(&lang(), "search");
    let pick_label = tr(&lang(), if book().is_empty() { "pick_contacts" } else { "pick_again" });

    rsx! {
        div { class: "screen",
            div { class: "screen-body",
                header { class: "bar",
                    button {
                        class: "icon-btn", r#type: "button", "aria-label": "{back_label}",
                        onclick: move |_| overlay.set(Overlay::None),
                        Icon { d: ICON_BACK }
                    }
                    h2 { class: "bar-title", {tr(&lang(), "new_chat")} }
                }

                div { class: "search",
                    Icon { d: ICON_SEARCH }
                    input {
                        r#type: "search", placeholder: "{search_ph}", value: "{query}",
                        oninput: move |e| query.set(e.value()),
                    }
                }

                button { class: "silver small", r#type: "button", onclick: pick, "{pick_label}" }
                if book().is_empty() {
                    p { class: "hint", {tr(&lang(), "picker_hint")} }
                }
                if !note().is_empty() {
                    p { class: if failed() { "note err" } else { "note ok" }, role: "status", "{note}" }
                }
                if busy() {
                    p { class: "hint", {tr(&lang(), "matching")} }
                }

                if !my_contacts().is_empty() {
                    h3 { class: "section-title", {tr(&lang(), "my_contacts")} }
                    div { class: "chat-list",
                        for c in my_contacts() {
                            ContactRow { key: "{c.id}", c: c.clone(), overlay }
                        }
                    }
                }
                if !on_m.is_empty() {
                    h3 { class: "section-title", {tr(&lang(), "on_m")} }
                    div { class: "chat-list",
                        for (name, num, m) in on_m {
                            MatchRow { key: "{num}", name: name, num: num.clone(), m: m, overlay }
                        }
                    }
                }
                if !others.is_empty() {
                    h3 { class: "section-title", {tr(&lang(), "invite_to_m")} }
                    div { class: "chat-list",
                        for (name, num) in others {
                            InviteRow { key: "{num}", name: name, num: num.clone() }
                        }
                    }
                }

                section { class: "card",
                    h2 { {tr(&lang(), "invite_title")} }
                    p { class: "hint", {tr(&lang(), "invite_sub")} }
                    div { class: "link", "{link}" }
                    button { class: "silver small", r#type: "button", onclick: copy_link, {tr(&lang(), "copy")} }
                }
                section { class: "card",
                    h2 { {tr(&lang(), "add_phone")} }
                    div { class: "row",
                        input {
                            class: "plain", r#type: "tel", inputmode: "tel", placeholder: "+20 101 234 5678",
                            value: "{phone}", oninput: move |e| phone.set(e.value()),
                        }
                        button { class: "silver small", r#type: "button", onclick: add_phone, {tr(&lang(), "add")} }
                    }
                }
            }
        }
    }
}
