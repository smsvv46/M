//! Profile customisation: name style, avatar decoration, profile effect, profile frame,
//! nameplate, search frame and the app icon. All of them are pure CSS looks picked by number.

use crate::{avatar, social::BannerView};
use dioxus::prelude::*;
use gloo_storage::{LocalStorage, Storage};

pub const NAME_STYLES: usize = 8;
pub const DECOS: usize = 8;
pub const EFFECTS: usize = 6;
pub const FRAMES: usize = 7;
pub const PLATES: usize = 7;
pub const SEARCH_FRAMES: usize = 6;
pub const ICONS: usize = 6;

/// The five looks other people see on my profile. Sent to the server as "n.a.e.f.p".
#[derive(Clone, Copy, PartialEq, Default, Debug)]
pub struct Look {
    pub name: usize,
    pub deco: usize,
    pub effect: usize,
    pub frame: usize,
    pub plate: usize,
}

impl Look {
    pub fn parse(s: &str) -> Look {
        let v: Vec<usize> = s.split('.').filter_map(|x| x.parse().ok()).collect();
        let get = |i: usize, max: usize| v.get(i).copied().unwrap_or(0).min(max - 1);
        Look {
            name: get(0, NAME_STYLES),
            deco: get(1, DECOS),
            effect: get(2, EFFECTS),
            frame: get(3, FRAMES),
            plate: get(4, PLATES),
        }
    }

    pub fn encode(&self) -> String {
        format!("{}.{}.{}.{}.{}", self.name, self.deco, self.effect, self.frame, self.plate)
    }

    pub fn with(mut self, field: &str, value: usize) -> Look {
        match field {
            "name" => self.name = value,
            "deco" => self.deco = value,
            "effect" => self.effect = value,
            "frame" => self.frame = value,
            _ => self.plate = value,
        }
        self
    }
}

// ---------------------------------------------------------------- app icon

const ICON_COLORS: [(&str, &str, &str); ICONS] = [
    ("e9e9ee", "8b8b96", "111111"),
    ("22222c", "000000", "ffffff"),
    ("a96bff", "3a0a7a", "ffffff"),
    ("ff4fa3", "5a0a38", "ffffff"),
    ("f5c46b", "7a4a05", "1a1203"),
    ("2fe0a0", "03402a", "031a12"),
];

pub fn icon_uri(i: usize) -> String {
    let (a, b, fg) = ICON_COLORS[i.min(ICONS - 1)];
    format!(
        "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='%23{a}'/><stop offset='1' stop-color='%23{b}'/></linearGradient></defs><rect width='64' height='64' rx='16' fill='url(%23g)'/><text x='32' y='47' font-size='42' text-anchor='middle' font-family='serif' font-weight='700' fill='%23{fg}'>M</text></svg>"
    )
}

/// Puts the chosen icon on the browser tab / home-screen shortcut.
pub fn apply_icon(i: usize) {
    let uri = serde_json::to_string(&icon_uri(i)).unwrap_or_default();
    let js = format!(
        "(function(u){{var l=document.querySelector(\"link[rel~='icon']\");if(!l){{l=document.createElement('link');l.rel='icon';document.head.appendChild(l);}}l.href=u;var a=document.querySelector(\"link[rel='apple-touch-icon']\");if(!a){{a=document.createElement('link');a.rel='apple-touch-icon';document.head.appendChild(a);}}a.href=u;}})({uri});"
    );
    let _ = document::eval(&js);
}

pub fn apply_saved_icon() {
    if let Ok(i) = LocalStorage::get::<usize>("m_app_icon") {
        apply_icon(i);
    }
}

// ---------------------------------------------------------------- profile header

/// Banner, avatar, name and bio with the person's chosen decoration, effect, frame and nameplate.
#[component]
pub fn ProfileHeader(
    look: String,
    banner_kind: String,
    banner: i16,
    banner_url: String,
    picture: String,
    name: String,
    sub: String,
) -> Element {
    let l = Look::parse(&look);
    let wrap = format!("pf fr{} pe{}", l.frame, l.effect);
    let av = format!("av-wrap ad{}", l.deco);
    let nm = format!("pf-name ns{}", l.name);
    let plate = format!("pf-plate np{}", l.plate);
    rsx! {
        div { class: "{wrap}",
            div { class: "pf-banner",
                BannerView { kind: banner_kind, preset: banner, url: banner_url }
            }
            div { class: "{av}",
                img { class: "avatar lg pf-avatar", src: "{picture}", alt: "" }
            }
            div { class: "{plate}",
                h2 { class: "{nm}", "{name}" }
                p { class: "pf-sub", "{sub}" }
            }
        }
    }
}

// ---------------------------------------------------------------- picker

fn opt_class(kind: &str, i: usize, on: bool) -> String {
    format!("opt {kind}{i}{}", if on { " on" } else { "" })
}

fn preview(kind: &str, i: usize) -> Element {
    match kind {
        "ad" => rsx! { img { class: "avatar sm", src: "{avatar::preset_uri(3)}", alt: "" } },
        "ic" => rsx! { img { class: "icon-prev", src: "{icon_uri(i)}", alt: "" } },
        "ns" | "sf" => rsx! { span { "Aa" } },
        "np" => rsx! { span { "M" } },
        _ => rsx! { span {} },
    }
}

/// A row of small previews; tapping one picks it.
#[component]
pub fn Picker(title: String, kind: &'static str, count: usize, current: usize, onpick: EventHandler<usize>) -> Element {
    rsx! {
        div { class: "pk",
            h3 { class: "section-title", "{title}" }
            div { class: "pk-row",
                for i in 0..count {
                    button {
                        key: "{i}", r#type: "button",
                        class: opt_class(kind, i, current == i),
                        "aria-label": "{title} {i + 1}",
                        onclick: move |_| onpick.call(i),
                        {preview(kind, i)}
                    }
                }
            }
        }
    }
}
