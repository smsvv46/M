use serde::{Deserialize, Serialize};
use serde_json::Value;

pub use reqwest::Method;

/// Server address. Override at build time: M_API=https://api.example.com dx build
pub const API: &str = match option_env!("M_API") {
    Some(v) => v,
    None => "http://localhost:8080",
};

#[derive(Clone, PartialEq, Deserialize, Serialize, Debug)]
pub struct User {
    pub id: String,
    pub email: Option<String>,
    pub phone: Option<String>,
    pub name: String,
    pub bio: String,
    pub avatar_kind: String,
    pub avatar_value: String,
    pub banner: i16,
    #[serde(default)]
    pub banner_kind: String,
    #[serde(default)]
    pub banner_url: String,
    pub invite_code: String,
    #[serde(default)]
    pub look: String,
}

impl User {
    /// Placeholder used while the real profile is not available (for example right after sign-out).
    pub fn blank() -> Self {
        User {
            id: String::new(),
            email: None,
            phone: None,
            name: String::new(),
            bio: String::new(),
            avatar_kind: "preset".into(),
            avatar_value: "0".into(),
            banner: 0,
            banner_kind: "preset".into(),
            banner_url: String::new(),
            invite_code: String::new(),
            look: String::new(),
        }
    }
}

#[derive(Clone, PartialEq, Deserialize, Serialize, Debug)]
pub struct Settings {
    pub read_receipts: bool,
    pub show_online: bool,
    pub last_seen: String,
    pub photo_vis: String,
    pub story_vis: String,
    pub add_by_phone: String,
    pub calls: String,
    pub language: String,
}

impl Settings {
    pub fn text(&self, key: &str) -> String {
        match key {
            "last_seen" => self.last_seen.clone(),
            "photo_vis" => self.photo_vis.clone(),
            "story_vis" => self.story_vis.clone(),
            "add_by_phone" => self.add_by_phone.clone(),
            "calls" => self.calls.clone(),
            _ => String::new(),
        }
    }
    pub fn flag(&self, key: &str) -> bool {
        match key {
            "read_receipts" => self.read_receipts,
            "show_online" => self.show_online,
            _ => false,
        }
    }
}

#[derive(Clone, PartialEq, Deserialize, Debug)]
pub struct Contact {
    pub id: String,
    pub name: String,
    #[serde(default)]
    pub bio: String,
    pub avatar_kind: String,
    pub avatar_value: String,
}

/// One request to the server. Returns the JSON body (Null when empty) or the server's error code.
pub async fn call(method: Method, path: &str, body: Option<Value>, token: Option<String>) -> Result<Value, String> {
    let client = reqwest::Client::new();
    let mut req = client.request(method, format!("{API}{path}"));
    if let Some(t) = token {
        req = req.bearer_auth(t);
    }
    if let Some(b) = body {
        req = req.json(&b);
    }
    let res = req.send().await.map_err(|_| "network".to_string())?;
    let ok = res.status().is_success();
    let text = res.text().await.map_err(|_| "network".to_string())?;
    let value: Value = if text.is_empty() { Value::Null } else { serde_json::from_str(&text).unwrap_or(Value::Null) };
    if ok {
        Ok(value)
    } else {
        Err(value["error"].as_str().unwrap_or("generic").to_string())
    }
}

/// `?invite=CODE` from the page address, if present.
pub fn invite_from_url() -> Option<String> {
    let search = web_sys::window()?.location().search().ok()?;
    search
        .trim_start_matches('?')
        .split('&')
        .find_map(|p| p.strip_prefix("invite=").map(|s| s.to_string()))
        .filter(|s| !s.is_empty())
}

/// The address people should share, for example https://m.app/?invite=abc123xy
pub fn invite_link(code: &str) -> String {
    let origin = web_sys::window()
        .and_then(|w| w.location().origin().ok())
        .unwrap_or_default();
    format!("{origin}/?invite={code}")
}

/// Someone else's profile, as the server shows it to people they are connected with.
#[derive(Clone, PartialEq, Deserialize, Debug)]
pub struct PublicUser {
    pub id: String,
    pub name: String,
    #[serde(default)]
    pub bio: String,
    pub avatar_kind: String,
    pub avatar_value: String,
    pub banner: i16,
    #[serde(default)]
    pub banner_kind: String,
    #[serde(default)]
    pub banner_url: String,
    #[serde(default)]
    pub look: String,
}

/// A phone-book number that belongs to a registered M user.
#[derive(Clone, PartialEq, Deserialize, Debug)]
pub struct MatchUser {
    pub id: String,
    pub phone: Option<String>,
    pub name: String,
    pub avatar_kind: String,
    pub avatar_value: String,
    pub is_contact: bool,
}

/// Uploaded files come back from the server as `/files/name.jpg`. Make them full addresses.
pub fn file_url(path: &str) -> String {
    if path.starts_with('/') {
        format!("{API}{path}")
    } else {
        path.to_string()
    }
}

/// Country calling code of a number written like +201012345678 (returns "20").
pub fn dial_code(phone: &str) -> Option<String> {
    const TWO: &[&str] = &[
        "20", "27", "30", "31", "32", "33", "34", "36", "39", "40", "41", "43", "44", "45", "46", "47", "48", "49",
        "51", "52", "53", "54", "55", "56", "57", "58", "60", "61", "62", "63", "64", "65", "66", "81", "82", "84",
        "86", "90", "91", "92", "93", "94", "95", "98",
    ];
    let d = phone.strip_prefix('+')?;
    if !d.chars().all(|c| c.is_ascii_digit()) {
        return None;
    }
    if d.starts_with('1') || d.starts_with('7') {
        return Some(d[..1].to_string());
    }
    if d.len() >= 2 && TWO.contains(&&d[..2]) {
        return Some(d[..2].to_string());
    }
    if d.len() >= 3 {
        return Some(d[..3].to_string());
    }
    None
}

/// Turns a number from the address book into +<country><number>. `cc` is the person's own country code.
pub fn to_e164(raw: &str, cc: &str) -> Option<String> {
    let t = raw.trim();
    let digits: String = t.chars().filter(|c| c.is_ascii_digit()).collect();
    let out = if t.starts_with('+') {
        digits
    } else if let Some(rest) = digits.strip_prefix("00") {
        rest.to_string()
    } else if digits.starts_with(cc) && digits.len() >= cc.len() + 8 {
        digits
    } else if let Some(rest) = digits.strip_prefix('0') {
        format!("{cc}{rest}")
    } else {
        format!("{cc}{digits}")
    };
    if out.len() < 8 || out.len() > 15 {
        None
    } else {
        Some(format!("+{out}"))
    }
}

/// Percent-encodes text for use inside a link.
pub fn url_encode(s: &str) -> String {
    let mut out = String::new();
    for b in s.bytes() {
        if b.is_ascii_alphanumeric() || matches!(b, b'-' | b'_' | b'.' | b'~') {
            out.push(b as char);
        } else {
            out.push_str(&format!("%{b:02X}"));
        }
    }
    out
}

/// One row of the chat list.
#[derive(Clone, PartialEq, Deserialize, Debug)]
pub struct ChatItem {
    pub id: String,
    pub peer_id: String,
    pub name: String,
    pub avatar_kind: String,
    pub avatar_value: String,
    pub last_body: Option<String>,
    pub last_ts: Option<i64>,
    pub unread: i64,
}

#[derive(Clone, PartialEq, Deserialize, Debug)]
pub struct Msg {
    pub id: i64,
    pub sender_id: String,
    pub body: String,
    pub ts: i64,
}

#[derive(Clone, PartialEq, Deserialize, Debug)]
pub struct Peer {
    pub id: String,
    pub name: String,
    pub avatar_kind: String,
    pub avatar_value: String,
    pub online: bool,
}

#[derive(Clone, PartialEq, Deserialize, Debug)]
pub struct Thread {
    pub peer: Peer,
    pub messages: Vec<Msg>,
    pub peer_receipt: i64,
}

#[derive(Clone, PartialEq, Deserialize, Debug)]
pub struct StoryItem {
    pub id: String,
    pub user_id: String,
    pub name: String,
    pub avatar_kind: String,
    pub avatar_value: String,
    pub kind: String,
    pub media_url: String,
    pub caption: String,
    pub bg: i16,
    #[serde(default)]
    pub repost_name: String,
    pub ts: i64,
    pub likes: i64,
    pub liked: bool,
    pub comments: i64,
    pub views: i64,
    pub viewed: bool,
}

#[derive(Clone, PartialEq, Deserialize, Debug)]
pub struct CommentItem {
    pub id: i64,
    pub user_id: String,
    pub name: String,
    pub avatar_kind: String,
    pub avatar_value: String,
    pub body: String,
    pub ts: i64,
}

#[derive(Clone, PartialEq, Deserialize, Debug)]
pub struct Viewer {
    pub user_id: String,
    pub name: String,
    pub avatar_kind: String,
    pub avatar_value: String,
    pub liked: bool,
    pub ts: i64,
}

/// A true/false preference kept on this phone.
pub fn get_bool(key: &str, default: bool) -> bool {
    use gloo_storage::Storage;
    gloo_storage::LocalStorage::get::<bool>(key).unwrap_or(default)
}

pub fn set_bool(key: &str, value: bool) {
    use gloo_storage::Storage;
    let _ = gloo_storage::LocalStorage::set(key, value);
}

/// Polling delay: backs off to 30 s while the page is in the background, and doubles in data-saver mode.
pub fn poll_ms(normal: u32) -> u32 {
    let hidden = js_sys::eval("document.hidden").ok().and_then(|v| v.as_bool()).unwrap_or(false);
    if hidden {
        30_000
    } else if get_bool("m_datasaver", false) {
        normal * 2
    } else {
        normal
    }
}
