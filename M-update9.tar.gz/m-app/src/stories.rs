use crate::{
    api::{call, file_url, url_encode, CommentItem, Method, StoryItem, Viewer},
    avatar,
    chat::fmt_time,
    i18n::{err_text, tr},
    login::Icon,
    social::{upload_value, Overlay, ICON_BACK},
    Ctx,
};
use dioxus::prelude::*;
use gloo_timers::future::TimeoutFuture;
use serde_json::json;

const ICON_PLUS: &str = "M12 5v14M5 12h14";
const ICON_HEART: &str = "M12 21s-7-4.6-9.3-9.1C1 8.5 3 5 6.4 5c2 0 3.6 1.1 4.6 2.7C12 6.1 13.6 5 15.6 5 19 5 21 8.5 19.3 11.9 17 16.4 12 21 12 21z";
const ICON_COMMENT: &str = "M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z";
const ICON_REPEAT: &str = "M17 2l4 4-4 4M3 11V9a3 3 0 0 1 3-3h15M7 22l-4-4 4-4M21 13v2a3 3 0 0 1-3 3H3";
const ICON_EYE: &str = "M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z";
const ICON_TRASH: &str = "M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3";
const ICON_CLOSE: &str = "M6 6l12 12M18 6L6 18";

/// All of one person's live stories.
#[derive(Clone, PartialEq)]
struct Group {
    user_id: String,
    name: String,
    avatar_kind: String,
    avatar_value: String,
    count: usize,
    newest: i64,
    all_viewed: bool,
}

fn group(items: &[StoryItem]) -> Vec<Group> {
    let mut out: Vec<Group> = Vec::new();
    for it in items {
        match out.iter_mut().find(|g| g.user_id == it.user_id) {
            Some(g) => {
                g.count += 1;
                g.newest = g.newest.max(it.ts);
                g.all_viewed = g.all_viewed && it.viewed;
            }
            None => out.push(Group {
                user_id: it.user_id.clone(),
                name: it.name.clone(),
                avatar_kind: it.avatar_kind.clone(),
                avatar_value: it.avatar_value.clone(),
                count: 1,
                newest: it.ts,
                all_viewed: it.viewed,
            }),
        }
    }
    // People with something new come first, then the newest.
    out.sort_by(|a, b| a.all_viewed.cmp(&b.all_viewed).then(b.newest.cmp(&a.newest)));
    out
}

/// How full a progress bar is: finished stories are full, the current one grows, the rest are empty.
fn bar_pct(i: usize, current: usize, elapsed: u32, limit: u32) -> u32 {
    if i < current {
        100
    } else if i == current {
        (elapsed * 100 / limit).min(100)
    } else {
        0
    }
}

// ---------------------------------------------------------------- the Stories tab

#[component]
pub fn StoriesTab(mut overlay: Signal<Overlay>) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let user = ctx.user;
    let me = user().map(|u| u.id).unwrap_or_default();

    let mut feed = use_signal(Vec::<StoryItem>::new);
    use_hook(move || {
        spawn(async move {
            loop {
                if let Ok(v) = call(Method::GET, "/stories", None, token()).await {
                    feed.set(serde_json::from_value(v).unwrap_or_default());
                }
                TimeoutFuture::new(crate::api::poll_ms(20000)).await;
            }
        });
    });

    let all = feed();
    let groups = group(&all);
    let mine = groups.iter().find(|g| g.user_id == me).cloned();
    let others: Vec<Group> = groups.into_iter().filter(|g| g.user_id != me).collect();
    let my_picture = user().map(|u| avatar::of(&u)).unwrap_or_default();
    let my_id = me.clone();
    let has_story = mine.is_some();
    let new_story_label = tr(&lang(), "new_story");
    let text_story_label = tr(&lang(), "story_text");
    let quick_post = move |_| {
        spawn(async move {
            if upload_value("pick-story-quick", "/stories/media", 1280, true, token()).await.is_ok() {
                if let Ok(v) = call(Method::GET, "/stories", None, token()).await {
                    feed.set(serde_json::from_value(v).unwrap_or_default());
                }
            }
        });
    };

    rsx! {
        header { class: "top", h1 { class: "display", {tr(&lang(), "stories")} } }

        section { class: "card",
            div { class: "chat-row",
                button {
                    class: if has_story { "ring-btn ring" } else { "ring-btn" }, r#type: "button",
                    onclick: move |_| {
                        if has_story { overlay.set(Overlay::Story(my_id.clone())) } else { overlay.set(Overlay::NewStory) }
                    },
                    img { class: "avatar md", src: "{my_picture}", alt: "" }
                }
                div { class: "chat-main",
                    div { class: "chat-name", {tr(&lang(), "my_story")} }
                    div { class: "chat-sub", {tr(&lang(), "add_story")} }
                }
                button {
                    class: "add-btn round", r#type: "button", "aria-label": "{text_story_label}",
                    onclick: move |_| overlay.set(Overlay::NewStory),
                    "Aa"
                }
                label { class: "add-btn round", "aria-label": "{new_story_label}",
                    Icon { d: ICON_PLUS }
                    input {
                        id: "pick-story-quick", class: "file-hidden", r#type: "file",
                        accept: "image/*,video/mp4,video/webm", onchange: quick_post,
                    }
                }
            }
        }

        if !others.is_empty() {
            h3 { class: "section-title", {tr(&lang(), "recent")} }
        }
        div { class: "chat-list",
            for g in others {
                GroupRow { key: "{g.user_id}", g: g.clone(), overlay }
            }
        }
    }
}

#[component]
fn GroupRow(g: Group, mut overlay: Signal<Overlay>) -> Element {
    let id = g.user_id.clone();
    let time = fmt_time(g.newest);
    rsx! {
        button {
            class: "chat-row", r#type: "button",
            onclick: move |_| overlay.set(Overlay::Story(id.clone())),
            span { class: if g.all_viewed { "ring-btn seen" } else { "ring-btn ring" },
                img { class: "avatar md", src: "{avatar::user_uri(&g.avatar_kind, &g.avatar_value)}", alt: "" }
            }
            div { class: "chat-main",
                div { class: "chat-name", "{g.name}" }
                div { class: "chat-sub", "{time}" }
            }
        }
    }
}

// ---------------------------------------------------------------- posting a story

#[component]
pub fn NewStory(mut overlay: Signal<Overlay>) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;

    let mut text_mode = use_signal(|| false);
    let mut caption = use_signal(String::new);
    let mut body = use_signal(String::new);
    let mut bg = use_signal(|| 0i16);
    let mut note = use_signal(String::new);
    let mut busy = use_signal(|| false);

    let pick = move |_| {
        spawn(async move {
            busy.set(true);
            let path = format!("/stories/media?caption={}", url_encode(&caption()));
            match upload_value("pick-story", &path, 1280, true, token()).await {
                Ok(_) => overlay.set(Overlay::None),
                Err(e) => note.set(err_text(&lang(), &e)),
            }
            busy.set(false);
        });
    };

    let post_text = move |_| {
        spawn(async move {
            busy.set(true);
            match call(Method::POST, "/stories/text", Some(json!({ "body": body(), "bg": bg() })), token()).await {
                Ok(_) => overlay.set(Overlay::None),
                Err(e) => note.set(err_text(&lang(), &e)),
            }
            busy.set(false);
        });
    };

    let back_label = tr(&lang(), "back");
    let caption_ph = tr(&lang(), "caption_ph");
    let text_ph = tr(&lang(), "text_ph");

    rsx! {
        div { class: "screen",
            div { class: "screen-body",
                header { class: "bar",
                    button {
                        class: "icon-btn", r#type: "button", "aria-label": "{back_label}",
                        onclick: move |_| overlay.set(Overlay::None),
                        Icon { d: ICON_BACK }
                    }
                    h2 { class: "bar-title", {tr(&lang(), "new_story")} }
                }

                div { class: "seg",
                    button { class: if !text_mode() { "on" } else { "" }, r#type: "button", onclick: move |_| text_mode.set(false), {tr(&lang(), "story_photo")} }
                    button { class: if text_mode() { "on" } else { "" }, r#type: "button", onclick: move |_| text_mode.set(true), {tr(&lang(), "story_text")} }
                }

                if text_mode() {
                    section { class: "card",
                        div { class: "text-story s{bg()}",
                            textarea {
                                class: "text-story-input", maxlength: "300", placeholder: "{text_ph}",
                                value: "{body}", oninput: move |e| body.set(e.value()),
                            }
                        }
                        div { class: "swatches",
                            for i in 0..8i16 {
                                button {
                                    key: "{i}", r#type: "button", "aria-label": "color {i}",
                                    class: format!("swatch s{i}{}", if bg() == i { " on" } else { "" }),
                                    onclick: move |_| bg.set(i),
                                }
                            }
                        }
                        button { class: "silver small", r#type: "button", disabled: busy(), onclick: post_text, {tr(&lang(), "post")} }
                    }
                } else {
                    section { class: "card",
                        input {
                            class: "plain", r#type: "text", maxlength: "300", placeholder: "{caption_ph}",
                            value: "{caption}", oninput: move |e| caption.set(e.value()),
                        }
                        label { class: "silver small upload",
                            {tr(&lang(), "choose_story")}
                            input {
                                id: "pick-story", class: "file-hidden", r#type: "file",
                                accept: "image/*,video/mp4,video/webm", onchange: pick,
                            }
                        }
                        p { class: "hint", {tr(&lang(), "story_hint")} }
                    }
                }

                if busy() {
                    p { class: "hint", {tr(&lang(), "loading")} }
                }
                if !note().is_empty() {
                    p { class: "note err", role: "status", "{note}" }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- watching stories

#[derive(Clone, Copy, PartialEq)]
enum Panel {
    None,
    Comments,
    Viewers,
}

#[component]
pub fn StoryViewer(user_id: String, mut overlay: Signal<Overlay>) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let user = ctx.user;
    let me = user().map(|u| u.id).unwrap_or_default();
    let mine = user_id == me;

    let mut items = use_signal(Vec::<StoryItem>::new);
    let mut idx = use_signal(|| 0usize);
    let mut elapsed = use_signal(|| 0u32);
    let mut paused = use_signal(|| false);
    let mut panel = use_signal(|| Panel::None);
    let mut comments = use_signal(Vec::<CommentItem>::new);
    let mut viewers = use_signal(Vec::<Viewer>::new);
    let mut draft = use_signal(String::new);
    let mut seen = use_signal(String::new);

    let load_for = user_id.clone();
    use_hook(move || {
        spawn(async move {
            if let Ok(v) = call(Method::GET, "/stories", None, token()).await {
                let all: Vec<StoryItem> = serde_json::from_value(v).unwrap_or_default();
                let list: Vec<StoryItem> = all.into_iter().filter(|s| s.user_id == load_for).collect();
                if list.is_empty() {
                    overlay.set(Overlay::None);
                    return;
                }
                // Start at the first story that was not watched yet.
                let start = list.iter().position(|s| !s.viewed).unwrap_or(0);
                idx.set(start);
                items.set(list);
            } else {
                overlay.set(Overlay::None);
            }
        });
    });

    let mut go_next = move || {
        let n = items.read().len();
        if idx() + 1 < n {
            idx.set(idx() + 1);
            elapsed.set(0);
        } else {
            overlay.set(Overlay::None);
        }
    };
    let mut go_prev = move || {
        if idx() > 0 {
            idx.set(idx() - 1);
        }
        elapsed.set(0);
    };

    // Photos and text last 5 seconds, videos play to the end (at most 20 seconds).
    use_hook(move || {
        spawn(async move {
            loop {
                TimeoutFuture::new(100).await;
                if paused() || panel() != Panel::None {
                    continue;
                }
                let current = items.read().get(idx()).cloned();
                let Some(it) = current else { continue };
                let limit: u32 = if it.kind == "video" { 20_000 } else { 5_000 };
                let next = elapsed() + 100;
                if next >= limit {
                    go_next();
                } else {
                    elapsed.set(next);
                }
            }
        });
    });

    // Tell the server a story was watched (once per story).
    use_effect(move || {
        let current = items.read().get(idx()).cloned();
        if let Some(it) = current {
            if !mine && *seen.peek() != it.id {
                seen.set(it.id.clone());
                spawn(async move {
                    let _ = call(Method::POST, &format!("/stories/{}/view", it.id), None, token()).await;
                });
            }
        }
    });

    let like = move |_| {
        let Some(it) = items().get(idx()).cloned() else { return };
        spawn(async move {
            if let Ok(v) = call(Method::POST, &format!("/stories/{}/like", it.id), None, token()).await {
                let liked = v["liked"].as_bool().unwrap_or(false);
                let likes = v["likes"].as_i64().unwrap_or(0);
                let mut w = items.write();
                if let Some(x) = w.iter_mut().find(|x| x.id == it.id) {
                    x.liked = liked;
                    x.likes = likes;
                }
            }
        });
    };

    let mut reposted = use_signal(Vec::<String>::new);
    let repost = move |_| {
        let Some(it) = items().get(idx()).cloned() else { return };
        spawn(async move {
            if call(Method::POST, &format!("/stories/{}/repost", it.id), None, token()).await.is_ok() {
                reposted.write().push(it.id.clone());
            }
        });
    };

    let open_comments = move |_| {
        let Some(it) = items().get(idx()).cloned() else { return };
        panel.set(Panel::Comments);
        spawn(async move {
            if let Ok(v) = call(Method::GET, &format!("/stories/{}/comments", it.id), None, token()).await {
                comments.set(serde_json::from_value(v).unwrap_or_default());
            }
        });
    };
    let open_viewers = move |_| {
        let Some(it) = items().get(idx()).cloned() else { return };
        panel.set(Panel::Viewers);
        spawn(async move {
            if let Ok(v) = call(Method::GET, &format!("/stories/{}/viewers", it.id), None, token()).await {
                viewers.set(serde_json::from_value(v).unwrap_or_default());
            }
        });
    };

    let send_comment = move |e: FormEvent| {
        e.prevent_default();
        let text = draft().trim().to_string();
        let Some(it) = items().get(idx()).cloned() else { return };
        if text.is_empty() {
            return;
        }
        draft.set(String::new());
        spawn(async move {
            if let Ok(v) = call(Method::POST, &format!("/stories/{}/comments", it.id), Some(json!({ "body": text })), token()).await {
                if let Ok(c) = serde_json::from_value::<CommentItem>(v) {
                    comments.write().push(c);
                    let mut w = items.write();
                    if let Some(x) = w.iter_mut().find(|x| x.id == it.id) {
                        x.comments += 1;
                    }
                }
            }
        });
    };

    let delete = move |_| {
        let Some(it) = items().get(idx()).cloned() else { return };
        spawn(async move {
            if call(Method::DELETE, &format!("/stories/{}", it.id), None, token()).await.is_ok() {
                items.write().retain(|x| x.id != it.id);
                if items.read().is_empty() {
                    overlay.set(Overlay::None);
                } else if idx() >= items.read().len() {
                    idx.set(items.read().len() - 1);
                }
                elapsed.set(0);
            }
        });
    };

    let list = items();
    let Some(cur) = list.get(idx()).cloned() else {
        return rsx! { div { class: "story-screen" } };
    };
    let limit: u32 = if cur.kind == "video" { 20_000 } else { 5_000 };
    let src = file_url(&cur.media_url);
    let time = fmt_time(cur.ts);
    let owner_picture = avatar::user_uri(&cur.avatar_kind, &cur.avatar_value);
    let close_label = tr(&lang(), "back");
    let comment_ph = tr(&lang(), "comment_ph");
    let delete_label = tr(&lang(), "delete");
    let repost_label = tr(&lang(), "repost");
    let repost_from = tr(&lang(), "repost_from");
    let did_repost = reposted().contains(&cur.id);
    let total = list.len();

    rsx! {
        div { class: "story-screen",
            match cur.kind.as_str() {
                "video" => rsx! {
                    video {
                        key: "{cur.id}", class: "story-media", src: "{src}", autoplay: true, "playsinline": "true",
                        onended: move |_| go_next(),
                        onmounted: move |_| {
                            let _ = document::eval("document.querySelectorAll('video.story-media').forEach(v=>{v.play().catch(()=>{v.muted=true;v.play().catch(()=>{});});});");
                        },
                    }
                },
                "image" => rsx! { img { key: "{cur.id}", class: "story-media", src: "{src}", alt: "" } },
                _ => rsx! {
                    div { key: "{cur.id}", class: "story-media text-story s{cur.bg}", span { class: "story-words", "{cur.caption}" } }
                },
            }
            div { class: "story-shade" }

            div { class: "story-tap prev", onclick: move |_| go_prev() }
            div { class: "story-tap next", onclick: move |_| go_next() }

            div { class: "story-top",
                div { class: "story-bars",
                    for i in 0..total {
                        div { key: "{i}", class: "story-bar",
                            div {
                                class: "story-fill",
                                style: "width: {bar_pct(i, idx(), elapsed(), limit)}%",
                            }
                        }
                    }
                }
                div { class: "story-who",
                    img { class: "avatar sm", src: "{owner_picture}", alt: "" }
                    div { class: "chat-main",
                        div { class: "chat-name", "{cur.name}" }
                        div { class: "chat-sub", "{time}" }
                        if !cur.repost_name.is_empty() {
                            div { class: "chat-sub", "{repost_from} {cur.repost_name}" }
                        }
                    }
                    if mine {
                        button { class: "icon-btn glass", r#type: "button", "aria-label": "{delete_label}", onclick: delete, Icon { d: ICON_TRASH } }
                    }
                    button {
                        class: "icon-btn glass", r#type: "button", "aria-label": "{close_label}",
                        onclick: move |_| overlay.set(Overlay::None),
                        Icon { d: ICON_CLOSE }
                    }
                }
            }

            if cur.kind != "text" && !cur.caption.is_empty() {
                p { class: "story-caption", "{cur.caption}" }
            }

            div { class: "story-actions",
                if mine {
                    button { class: "story-pill", r#type: "button", onclick: open_viewers,
                        Icon { d: ICON_EYE } span { "{cur.views}" }
                    }
                    button { class: "story-pill", r#type: "button", onclick: open_comments,
                        Icon { d: ICON_COMMENT } span { "{cur.comments}" }
                    }
                    span { class: "story-pill static",
                        Icon { d: ICON_HEART } span { "{cur.likes}" }
                    }
                } else {
                    button { class: "story-pill grow", r#type: "button", onclick: open_comments,
                        Icon { d: ICON_COMMENT } span { {tr(&lang(), "comment_ph")} } span { class: "count", "{cur.comments}" }
                    }
                    button {
                        class: if did_repost { "story-pill liked" } else { "story-pill" }, r#type: "button",
                        "aria-label": "{repost_label}", onclick: repost,
                        Icon { d: ICON_REPEAT }
                        if did_repost { span { {tr(&lang(), "reposted")} } }
                    }
                    button {
                        class: if cur.liked { "story-pill liked" } else { "story-pill" }, r#type: "button",
                        "aria-label": "like", onclick: like,
                        Icon { d: ICON_HEART } span { "{cur.likes}" }
                    }
                }
            }

            if panel() != Panel::None {
                div { class: "sheet-back", onclick: move |_| panel.set(Panel::None) }
                div { class: "sheet",
                    h3 { class: "section-title",
                        if panel() == Panel::Comments { {tr(&lang(), "comments")} } else { {tr(&lang(), "viewers")} }
                    }
                    div { class: "sheet-list",
                        if panel() == Panel::Comments {
                            if comments().is_empty() { p { class: "hint", {tr(&lang(), "no_comments")} } }
                            for c in comments() {
                                div { key: "{c.id}", class: "chat-row",
                                    img { class: "avatar sm", src: "{avatar::user_uri(&c.avatar_kind, &c.avatar_value)}", alt: "" }
                                    div { class: "chat-main",
                                        div { class: "chat-name", "{c.name}" }
                                        div { class: "comment-body", "{c.body}" }
                                    }
                                }
                            }
                        } else {
                            for v in viewers() {
                                div { key: "{v.user_id}", class: "chat-row",
                                    img { class: "avatar sm", src: "{avatar::user_uri(&v.avatar_kind, &v.avatar_value)}", alt: "" }
                                    div { class: "chat-main", div { class: "chat-name", "{v.name}" } }
                                    if v.liked { span { class: "tick read", "♥" } }
                                }
                            }
                        }
                    }
                    if panel() == Panel::Comments {
                        form { class: "composer", onsubmit: send_comment,
                            input {
                                class: "composer-input", r#type: "text", autocomplete: "off", maxlength: "500", placeholder: "{comment_ph}",
                                value: "{draft}", oninput: move |e| draft.set(e.value()),
                            }
                            button { class: "send-btn", r#type: "submit", "aria-label": "send", Icon { d: ICON_BACK } }
                        }
                    }
                }
            }
        }
    }
}
