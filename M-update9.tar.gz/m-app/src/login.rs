use crate::{
    api::{call, invite_from_url, Method},
    i18n::{err_text, tr},
    Ctx,
};
use dioxus::prelude::*;
use gloo_storage::{LocalStorage, Storage};
use serde_json::json;

const BG_VIDEO: Asset = asset!("/assets/login-bg.mp4");

#[component]
pub fn Icon(d: &'static str) -> Element {
    rsx! {
        svg {
            width: "24", height: "24", view_box: "0 0 24 24", fill: "none", stroke: "currentColor",
            stroke_width: "1.8", stroke_linecap: "round", stroke_linejoin: "round",
            "aria-hidden": "true",
            path { d: "{d}" }
        }
    }
}

pub const ICON_USER: &str = "M12 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM4 21v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1";
pub const ICON_LOCK: &str = "M7 11h10a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2zM8 11V8a4 4 0 0 1 8 0v3";
pub const ICON_ARROW: &str = "M4 12h16M14 6l6 6-6 6";

#[component]
pub fn Login() -> Element {
    let ctx = use_context::<Ctx>();
    let mut token = ctx.token;
    let lang = ctx.lang;

    let mut ident = use_signal(String::new);
    let mut code = use_signal(String::new);
    let mut note = use_signal(String::new);
    let mut failed = use_signal(|| false);
    let mut busy = use_signal(|| false);

    let send_code = move |_| {
        spawn(async move {
            busy.set(true);
            match call(Method::POST, "/auth/request-code", Some(json!({ "target": ident() })), None).await {
                Ok(_) => {
                    failed.set(false);
                    note.set(tr(&lang(), "code_sent"));
                }
                Err(e) => {
                    failed.set(true);
                    note.set(err_text(&lang(), &e));
                }
            }
            busy.set(false);
        });
    };

    let login = move |_| {
        spawn(async move {
            busy.set(true);
            let mut body = json!({ "target": ident(), "code": code() });
            if let Some(inv) = invite_from_url() {
                body["invite"] = json!(inv);
            }
            match call(Method::POST, "/auth/verify", Some(body), None).await {
                Ok(v) => {
                    if let Some(t) = v["token"].as_str() {
                        let _ = LocalStorage::set("m_token", t);
                        token.set(Some(t.to_string()));
                    }
                }
                Err(e) => {
                    failed.set(true);
                    note.set(err_text(&lang(), &e));
                }
            }
            busy.set(false);
        });
    };

    // Google sign-in needs a Google OAuth client; until it is set up, say so.
    let google = move |_| {
        failed.set(false);
        note.set(tr(&lang(), "google_soon"));
    };

    let focus_ident = move |_| {
        let _ = document::eval("document.getElementById('lg-ident')?.focus();");
    };

    use_effect(move || {
        let _ = document::eval(
            "document.querySelectorAll('video').forEach(v=>{v.muted=true;v.defaultMuted=true;v.setAttribute('playsinline','');const p=()=>v.play().catch(()=>{});p();['pointerdown','touchstart','keydown'].forEach(e=>document.addEventListener(e,p,{once:true}));});",
        );
    });

    let ident_ph = tr(&lang(), "ident_ph");
    let code_ph = tr(&lang(), "code_ph");

    rsx! {
        main { class: "lg",
            div { class: "lg-content",
                div { class: "lg-logo", "aria-hidden": "true",
                    svg { class: "lg-orbit", view_box: "0 0 120 60", fill: "none",
                        ellipse { cx: "60", cy: "38", rx: "55", ry: "17", transform: "rotate(-12 60 38)", stroke: "currentColor", stroke_width: "1.4" }
                        path { d: "M9 2 L11 9 L18 11 L11 13 L9 20 L7 13 L0 11 L7 9 Z", fill: "currentColor" }
                    }
                    span { "M" }
                }
                h1 { class: "display lg-title", {tr(&lang(), "welcome")} }
                p { class: "lg-sub", {tr(&lang(), "signin_sub")} }
                video {
                    class: "lg-video", src: "{BG_VIDEO}",
                    autoplay: true, muted: true, "loop": "true", "playsinline": "true",
                    "aria-hidden": "true"
                }

                div { class: "lg-form",
                    label { class: "field",
                        crate::login::Icon { d: ICON_USER }
                        input {
                            id: "lg-ident",
                            r#type: "text", inputmode: "email", autocomplete: "username",
                            placeholder: "{ident_ph}",
                            value: "{ident}",
                            oninput: move |e| ident.set(e.value()),
                        }
                    }
                    label { class: "field",
                        crate::login::Icon { d: ICON_LOCK }
                        input {
                            r#type: "text", inputmode: "numeric", autocomplete: "one-time-code", maxlength: "6",
                            placeholder: "{code_ph}",
                            value: "{code}",
                            oninput: move |e| code.set(e.value()),
                        }
                        button { class: "chip-btn", r#type: "button", disabled: busy(), onclick: send_code,
                            {tr(&lang(), "send_code")}
                        }
                    }
                    if !note().is_empty() {
                        p { class: if failed() { "note err" } else { "note ok" }, role: "status", "{note}" }
                    }
                    button { class: "silver", r#type: "button", disabled: busy(), onclick: login,
                        span { {tr(&lang(), "login")} }
                        crate::login::Icon { d: ICON_ARROW }
                    }
                    div { class: "lg-or", span { {tr(&lang(), "or")} } }
                    button { class: "lg-google", r#type: "button", "aria-label": "Google", onclick: google, "G" }
                    p { class: "lg-signup",
                        {tr(&lang(), "no_account")} " "
                        button { class: "lg-link", r#type: "button", onclick: focus_ident, {tr(&lang(), "sign_up")} }
                    }
                }
            }
        }
    }
}
