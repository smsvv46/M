# M app (phase 1 web)

Rust and Dioxus. One codebase that builds the website now and the Android app later.

## Run

```bash
cargo install dioxus-cli          # once
rustup target add wasm32-unknown-unknown
dx serve                          # serves the app on http://localhost:8080
```

The server in `m-server` also defaults to port 8080. Start the server with `PORT=8081 cargo run`, then point the app at it:

```bash
M_API=http://localhost:8081 dx serve
```

Open the app with an invite link by adding `?invite=CODE` to the address.

## What works

Login with a phone or email plus the verification code, profile (name, bio, 12 avatars, 6 animated banners, password), invite link and contacts, settings (language Arabic or English, read receipts, show online, last seen, photo, stories, add by number, calls).

## Not done yet

Uploading your own photo, chat, groups, stories, calls, the other pages from the design, more languages, and the Android build.
