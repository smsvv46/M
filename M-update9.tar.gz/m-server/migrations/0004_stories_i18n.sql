CREATE TABLE stories (
    id         UUID PRIMARY KEY,
    user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    kind       TEXT NOT NULL,                -- image, video or text
    media_url  TEXT NOT NULL DEFAULT '',
    caption    TEXT NOT NULL DEFAULT '',     -- the text itself for text stories
    bg         SMALLINT NOT NULL DEFAULT 0,  -- background colour for text stories
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at TIMESTAMPTZ NOT NULL DEFAULT now() + interval '24 hours'
);
CREATE INDEX stories_user_idx ON stories (user_id, created_at DESC);
CREATE INDEX stories_expiry_idx ON stories (expires_at);

CREATE TABLE story_likes (
    story_id   UUID NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
    user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (story_id, user_id)
);

CREATE TABLE story_comments (
    id         BIGSERIAL PRIMARY KEY,
    story_id   UUID NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
    user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    body       TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX story_comments_idx ON story_comments (story_id, id);

CREATE TABLE story_views (
    story_id  UUID NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
    user_id   UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    viewed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (story_id, user_id)
);

-- Translations of the app's texts into any language, filled on demand and kept for everyone.
CREATE TABLE translations (
    lang TEXT NOT NULL,
    key  TEXT NOT NULL,
    text TEXT NOT NULL,
    PRIMARY KEY (lang, key)
);
