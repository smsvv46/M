CREATE TABLE users (
    id            UUID PRIMARY KEY,
    email         TEXT UNIQUE,
    phone         TEXT UNIQUE,
    password_hash TEXT,
    name          TEXT NOT NULL,
    bio           TEXT NOT NULL DEFAULT '',
    avatar_kind   TEXT NOT NULL DEFAULT 'preset',
    avatar_value  TEXT NOT NULL DEFAULT '0',
    banner        SMALLINT NOT NULL DEFAULT 0,
    invite_code   TEXT NOT NULL UNIQUE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (email IS NOT NULL OR phone IS NOT NULL)
);

CREATE TABLE user_settings (
    user_id        UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    read_receipts  BOOLEAN NOT NULL DEFAULT TRUE,
    show_online    BOOLEAN NOT NULL DEFAULT TRUE,
    last_seen      TEXT NOT NULL DEFAULT 'all',
    photo_vis      TEXT NOT NULL DEFAULT 'all',
    story_vis      TEXT NOT NULL DEFAULT 'contacts',
    add_by_phone   TEXT NOT NULL DEFAULT 'all',
    calls          TEXT NOT NULL DEFAULT 'contacts',
    language       TEXT NOT NULL DEFAULT 'ar'
);

CREATE TABLE otp_codes (
    id          BIGSERIAL PRIMARY KEY,
    target      TEXT NOT NULL,
    code_hash   TEXT NOT NULL,
    expires_at  TIMESTAMPTZ NOT NULL,
    attempts    INT NOT NULL DEFAULT 0,
    used        BOOLEAN NOT NULL DEFAULT FALSE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX otp_target_idx ON otp_codes (target, created_at DESC);

CREATE TABLE contacts (
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    contact_id  UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, contact_id),
    CHECK (user_id <> contact_id)
);
