# M server (phase 1)

Rust, Axum, PostgreSQL. Covers sign-in with a verification code (email or phone), profile, privacy settings, invite links and contacts.

## Run

```bash
docker compose up -d            # PostgreSQL
cp .env.example .env            # then set JWT_SECRET
cargo run
```

The migration runs on start. With no SMTP or Twilio settings, verification codes are printed in the server log.

## Try it

```bash
curl -X POST localhost:8080/auth/request-code -H 'content-type: application/json' -d '{"target":"you@example.com"}'
# read the code in the server log, then:
curl -X POST localhost:8080/auth/verify -H 'content-type: application/json' -d '{"target":"you@example.com","code":"123456"}'
# use the returned token:
curl localhost:8080/me -H 'authorization: Bearer <token>'
```

## Endpoints

| Method | Path | Purpose |
|---|---|---|
| POST | /auth/request-code | send a 6-digit code to an email or a phone in +country format |
| POST | /auth/verify | check the code; creates the account on first use; optional `invite` code |
| GET, PATCH | /me | profile: name, bio, avatar, banner |
| POST | /me/password | set or change the password |
| GET, PATCH | /me/settings | read receipts, show online, last seen, photo, stories, add by number, calls, language |
| GET, POST | /me/contacts | list contacts, add by phone (respects the other person's privacy) |
| POST | /invite/:code | accept an invite link; both people become contacts |

## Not done yet

Chat, groups, stories, calls, online status over WebSocket, password sign-in, and restricting CORS. This code has not been compiled yet, so expect a few small fixes on the first `cargo build`.
