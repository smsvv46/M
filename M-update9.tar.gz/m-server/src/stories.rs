use axum::{
    body::Bytes,
    extract::{Path, Query, State},
    http::{HeaderMap, StatusCode},
    Json,
};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sqlx::FromRow;
use uuid::Uuid;

use crate::{
    auth::AuthUser,
    error::AppError,
    routes::{remove_file, store_file, upload_ext},
    AppState,
};

type Res<T> = Result<T, AppError>;

/// The part of a query that decides who may see a story. `$1` is the viewer, `st` the story, `s` the owner's settings.
const VISIBLE: &str = "st.expires_at > now() AND (
    st.user_id = $1
    OR (s.story_vis <> 'nobody'
        AND (EXISTS (SELECT 1 FROM contacts c WHERE c.user_id = $1 AND c.contact_id = st.user_id)
             OR EXISTS (SELECT 1 FROM contacts c2 WHERE c2.user_id = st.user_id AND c2.contact_id = $1))))";

/// Returns the story owner if `me` may see this story.
async fn visible_owner(db: &sqlx::PgPool, me: Uuid, story: Uuid) -> Res<Uuid> {
    let sql = format!(
        "SELECT st.user_id FROM stories st JOIN user_settings s ON s.user_id = st.user_id
         WHERE st.id = $2 AND {VISIBLE}"
    );
    sqlx::query_scalar::<_, Uuid>(&sql)
        .bind(me)
        .bind(story)
        .fetch_optional(db)
        .await?
        .ok_or(AppError::NotFound)
}

// ---------- the feed ----------

#[derive(Serialize, FromRow)]
pub struct StoryItem {
    id: Uuid,
    user_id: Uuid,
    name: String,
    avatar_kind: String,
    avatar_value: String,
    kind: String,
    media_url: String,
    caption: String,
    bg: i16,
    repost_name: String,
    ts: i64,
    likes: i64,
    liked: bool,
    comments: i64,
    views: i64,
    viewed: bool,
}

/// My stories and the live stories of the people I am connected with, oldest first.
pub async fn feed(State(s): State<AppState>, AuthUser(me): AuthUser) -> Res<Json<Vec<StoryItem>>> {
    let sql = format!(
        "SELECT st.id, st.user_id, u.name,
                CASE WHEN s.photo_vis = 'nobody' AND st.user_id <> $1 THEN 'preset' ELSE u.avatar_kind END AS avatar_kind,
                CASE WHEN s.photo_vis = 'nobody' AND st.user_id <> $1 THEN '0' ELSE u.avatar_value END AS avatar_value,
                st.kind, st.media_url, st.caption, st.bg, st.repost_name,
                EXTRACT(EPOCH FROM st.created_at)::bigint AS ts,
                (SELECT COUNT(*) FROM story_likes l WHERE l.story_id = st.id) AS likes,
                EXISTS (SELECT 1 FROM story_likes l WHERE l.story_id = st.id AND l.user_id = $1) AS liked,
                (SELECT COUNT(*) FROM story_comments c WHERE c.story_id = st.id) AS comments,
                (SELECT COUNT(*) FROM story_views v WHERE v.story_id = st.id) AS views,
                EXISTS (SELECT 1 FROM story_views v WHERE v.story_id = st.id AND v.user_id = $1) AS viewed
         FROM stories st
         JOIN users u ON u.id = st.user_id
         JOIN user_settings s ON s.user_id = st.user_id
         WHERE {VISIBLE}
         ORDER BY st.created_at ASC"
    );
    let rows = sqlx::query_as::<_, StoryItem>(&sql).bind(me).fetch_all(&s.db).await?;
    Ok(Json(rows))
}

// ---------- posting ----------

#[derive(Deserialize)]
pub struct CaptionQuery {
    caption: Option<String>,
}

/// A photo or video story. The file is the request body; an optional caption goes in the query string.
pub async fn create_media(
    State(s): State<AppState>,
    AuthUser(me): AuthUser,
    headers: HeaderMap,
    Query(q): Query<CaptionQuery>,
    body: Bytes,
) -> Res<Json<Value>> {
    let ext = upload_ext(&headers, true)?;
    if body.is_empty() {
        return Err(AppError::BadRequest("empty_file"));
    }
    let is_video = ext == "mp4" || ext == "webm";
    if body.len() > if is_video { 20_000_000 } else { 6_000_000 } {
        return Err(AppError::BadRequest("file_too_large"));
    }
    let caption = q.caption.unwrap_or_default().trim().to_string();
    if caption.chars().count() > 300 {
        return Err(AppError::BadRequest("caption_too_long"));
    }
    let url = store_file(&s, ext, &body).await?;
    let id = Uuid::new_v4();
    sqlx::query("INSERT INTO stories (id, user_id, kind, media_url, caption) VALUES ($1, $2, $3, $4, $5)")
        .bind(id)
        .bind(me)
        .bind(if is_video { "video" } else { "image" })
        .bind(&url)
        .bind(&caption)
        .execute(&s.db)
        .await?;
    Ok(Json(json!({ "id": id })))
}

#[derive(Deserialize)]
pub struct TextStory {
    body: String,
    bg: Option<i16>,
}

pub async fn create_text(State(s): State<AppState>, AuthUser(me): AuthUser, Json(b): Json<TextStory>) -> Res<Json<Value>> {
    let text = b.body.trim().to_string();
    if text.is_empty() {
        return Err(AppError::BadRequest("empty_message"));
    }
    if text.chars().count() > 300 {
        return Err(AppError::BadRequest("caption_too_long"));
    }
    let bg = b.bg.unwrap_or(0);
    if !(0..=7).contains(&bg) {
        return Err(AppError::BadRequest("invalid_banner"));
    }
    let id = Uuid::new_v4();
    sqlx::query("INSERT INTO stories (id, user_id, kind, caption, bg) VALUES ($1, $2, 'text', $3, $4)")
        .bind(id)
        .bind(me)
        .bind(&text)
        .bind(bg)
        .execute(&s.db)
        .await?;
    Ok(Json(json!({ "id": id })))
}

pub async fn delete_story(State(s): State<AppState>, AuthUser(me): AuthUser, Path(id): Path<Uuid>) -> Res<StatusCode> {
    let url: Option<String> = sqlx::query_scalar("DELETE FROM stories WHERE id = $1 AND user_id = $2 RETURNING media_url")
        .bind(id)
        .bind(me)
        .fetch_optional(&s.db)
        .await?;
    match url {
        Some(u) => {
            remove_file(&s, &u).await;
            Ok(StatusCode::NO_CONTENT)
        }
        None => Err(AppError::NotFound),
    }
}

// ---------- views, likes, comments ----------

pub async fn mark_viewed(State(s): State<AppState>, AuthUser(me): AuthUser, Path(id): Path<Uuid>) -> Res<StatusCode> {
    let owner = visible_owner(&s.db, me, id).await?;
    if owner != me {
        sqlx::query("INSERT INTO story_views (story_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING")
            .bind(id)
            .bind(me)
            .execute(&s.db)
            .await?;
    }
    Ok(StatusCode::NO_CONTENT)
}

/// Like or unlike. Returns the new state and the total.
pub async fn toggle_like(State(s): State<AppState>, AuthUser(me): AuthUser, Path(id): Path<Uuid>) -> Res<Json<Value>> {
    visible_owner(&s.db, me, id).await?;
    let removed = sqlx::query("DELETE FROM story_likes WHERE story_id = $1 AND user_id = $2")
        .bind(id)
        .bind(me)
        .execute(&s.db)
        .await?
        .rows_affected();
    if removed == 0 {
        sqlx::query("INSERT INTO story_likes (story_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING")
            .bind(id)
            .bind(me)
            .execute(&s.db)
            .await?;
    }
    let likes: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM story_likes WHERE story_id = $1")
        .bind(id)
        .fetch_one(&s.db)
        .await?;
    Ok(Json(json!({ "liked": removed == 0, "likes": likes })))
}

#[derive(Serialize, FromRow)]
pub struct CommentItem {
    id: i64,
    user_id: Uuid,
    name: String,
    avatar_kind: String,
    avatar_value: String,
    body: String,
    ts: i64,
}

const COMMENT_SELECT: &str = "SELECT c.id, c.user_id, u.name,
        CASE WHEN s.photo_vis = 'nobody' AND c.user_id <> $2 THEN 'preset' ELSE u.avatar_kind END AS avatar_kind,
        CASE WHEN s.photo_vis = 'nobody' AND c.user_id <> $2 THEN '0' ELSE u.avatar_value END AS avatar_value,
        c.body, EXTRACT(EPOCH FROM c.created_at)::bigint AS ts
    FROM story_comments c
    JOIN users u ON u.id = c.user_id
    JOIN user_settings s ON s.user_id = c.user_id";

pub async fn list_comments(State(s): State<AppState>, AuthUser(me): AuthUser, Path(id): Path<Uuid>) -> Res<Json<Vec<CommentItem>>> {
    visible_owner(&s.db, me, id).await?;
    let rows = sqlx::query_as::<_, CommentItem>(&format!("{COMMENT_SELECT} WHERE c.story_id = $1 ORDER BY c.id ASC LIMIT 300"))
        .bind(id)
        .bind(me)
        .fetch_all(&s.db)
        .await?;
    Ok(Json(rows))
}

#[derive(Deserialize)]
pub struct NewComment {
    body: String,
}

pub async fn add_comment(
    State(s): State<AppState>,
    AuthUser(me): AuthUser,
    Path(id): Path<Uuid>,
    Json(b): Json<NewComment>,
) -> Res<Json<CommentItem>> {
    visible_owner(&s.db, me, id).await?;
    let text = b.body.trim().to_string();
    if text.is_empty() {
        return Err(AppError::BadRequest("empty_message"));
    }
    if text.chars().count() > 500 {
        return Err(AppError::BadRequest("message_too_long"));
    }
    let new_id: i64 = sqlx::query_scalar("INSERT INTO story_comments (story_id, user_id, body) VALUES ($1, $2, $3) RETURNING id")
        .bind(id)
        .bind(me)
        .bind(&text)
        .fetch_one(&s.db)
        .await?;
    let row = sqlx::query_as::<_, CommentItem>(&format!("{COMMENT_SELECT} WHERE c.id = $1"))
        .bind(new_id)
        .bind(me)
        .fetch_one(&s.db)
        .await?;
    Ok(Json(row))
}

#[derive(Serialize, FromRow)]
pub struct Viewer {
    user_id: Uuid,
    name: String,
    avatar_kind: String,
    avatar_value: String,
    liked: bool,
    ts: i64,
}

/// Only the owner can see who watched.
pub async fn viewers(State(s): State<AppState>, AuthUser(me): AuthUser, Path(id): Path<Uuid>) -> Res<Json<Vec<Viewer>>> {
    let owner = visible_owner(&s.db, me, id).await?;
    if owner != me {
        return Err(AppError::NotFound);
    }
    let rows = sqlx::query_as::<_, Viewer>(
        "SELECT v.user_id, u.name,
                CASE WHEN s.photo_vis = 'nobody' THEN 'preset' ELSE u.avatar_kind END AS avatar_kind,
                CASE WHEN s.photo_vis = 'nobody' THEN '0' ELSE u.avatar_value END AS avatar_value,
                EXISTS (SELECT 1 FROM story_likes l WHERE l.story_id = v.story_id AND l.user_id = v.user_id) AS liked,
                EXTRACT(EPOCH FROM v.viewed_at)::bigint AS ts
         FROM story_views v
         JOIN users u ON u.id = v.user_id
         JOIN user_settings s ON s.user_id = v.user_id
         WHERE v.story_id = $1 ORDER BY v.viewed_at DESC LIMIT 300",
    )
    .bind(id)
    .fetch_all(&s.db)
    .await?;
    Ok(Json(rows))
}

// ---------- repost ----------

#[derive(FromRow)]
struct Original {
    user_id: Uuid,
    name: String,
    kind: String,
    media_url: String,
    caption: String,
    bg: i16,
    repost_name: String,
}

/// Put someone else's live story on my own story. The file is copied so it outlives the original.
pub async fn repost(State(s): State<AppState>, AuthUser(me): AuthUser, Path(id): Path<Uuid>) -> Res<Json<Value>> {
    visible_owner(&s.db, me, id).await?;
    let o = sqlx::query_as::<_, Original>(
        "SELECT st.user_id, u.name, st.kind, st.media_url, st.caption, st.bg, st.repost_name
         FROM stories st JOIN users u ON u.id = st.user_id WHERE st.id = $1",
    )
    .bind(id)
    .fetch_one(&s.db)
    .await?;
    if o.user_id == me {
        return Err(AppError::BadRequest("own_story"));
    }
    let already: bool = sqlx::query_scalar(
        "SELECT EXISTS (SELECT 1 FROM stories WHERE user_id = $1 AND repost_of = $2 AND expires_at > now())",
    )
    .bind(me)
    .bind(id)
    .fetch_one(&s.db)
    .await?;
    if already {
        return Ok(Json(json!({ "ok": true, "already": true })));
    }
    let mut url = o.media_url.clone();
    if let Some(name) = o.media_url.strip_prefix("/files/") {
        if !name.is_empty() && !name.contains('/') && !name.contains('\\') && !name.contains("..") {
            let ext = name.rsplit('.').next().unwrap_or("bin");
            let bytes = tokio::fs::read(format!("{}/{}", s.upload_dir, name)).await.map_err(|_| AppError::NotFound)?;
            url = store_file(&s, ext, &bytes).await?;
        }
    }
    let from = if o.repost_name.is_empty() { o.name } else { o.repost_name };
    let new_id = Uuid::new_v4();
    sqlx::query(
        "INSERT INTO stories (id, user_id, kind, media_url, caption, bg, repost_name, repost_of)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)",
    )
    .bind(new_id)
    .bind(me)
    .bind(&o.kind)
    .bind(&url)
    .bind(&o.caption)
    .bind(o.bg)
    .bind(&from)
    .bind(id)
    .execute(&s.db)
    .await?;
    Ok(Json(json!({ "ok": true, "id": new_id })))
}
