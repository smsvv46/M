use argon2::{
    password_hash::{rand_core::OsRng, PasswordHash, PasswordHasher, PasswordVerifier, SaltString},
    Argon2,
};
use axum::{
    body::Bytes,
    extract::{Path, State},
    http::{header::CONTENT_TYPE, HeaderMap, StatusCode},
    Json,
};
use rand::Rng;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sqlx::FromRow;
use uuid::Uuid;

use crate::{
    auth::{hash_code, make_token, AuthUser},
    error::AppError,
    AppState,
};

type Res<T> = Result<T, AppError>;

#[derive(Serialize, FromRow)]
pub struct User {
    id: Uuid,
    email: Option<String>,
    phone: Option<String>,
    name: String,
    bio: String,
    avatar_kind: String,
    avatar_value: String,
    banner: i16,
    banner_kind: String,
    banner_url: String,
    invite_code: String,
    look: String,
    created_ts: i64,
}

#[derive(Serialize, FromRow)]
pub struct Settings {
    read_receipts: bool,
    show_online: bool,
    last_seen: String,
    photo_vis: String,
    story_vis: String,
    add_by_phone: String,
    calls: String,
    language: String,
}

const USER_COLS: &str = "id, email, phone, name, bio, avatar_kind, avatar_value, banner, banner_kind, banner_url, invite_code, look, EXTRACT(EPOCH FROM created_at)::bigint AS created_ts";

// ---------- helpers ----------

/// Returns (normalized target, is_email).
fn normalize(raw: &str) -> Res<(String, bool)> {
    let t = raw.trim();
    if t.contains('@') {
        let e = t.to_lowercase();
        let ok = e.len() <= 254 && e.split('@').count() == 2 && e.rsplit('@').next().map_or(false, |d| d.contains('.'));
        if !ok {
            return Err(AppError::BadRequest("invalid_email"));
        }
        Ok((e, true))
    } else {
        let digits: String = t.chars().filter(|c| c.is_ascii_digit()).collect();
        if !t.starts_with('+') || digits.len() < 8 || digits.len() > 15 {
            return Err(AppError::BadRequest("invalid_phone"));
        }
        Ok((format!("+{digits}"), false))
    }
}

fn valid_vis(v: &str) -> bool {
    matches!(v, "all" | "contacts" | "nobody")
}

fn invite_code() -> String {
    const A: &[u8] = b"abcdefghjkmnpqrstuvwxyz23456789";
    let mut r = rand::thread_rng();
    (0..8).map(|_| A[r.gen_range(0..A.len())] as char).collect()
}

async fn fetch_user(db: &sqlx::PgPool, id: Uuid) -> Res<User> {
    sqlx::query_as::<_, User>(&format!("SELECT {USER_COLS} FROM users WHERE id = $1"))
        .bind(id)
        .fetch_optional(db)
        .await?
        .ok_or(AppError::NotFound)
}

// ---------- auth ----------

#[derive(Deserialize)]
pub struct RequestCode {
    target: String,
}

pub async fn request_code(State(s): State<AppState>, Json(b): Json<RequestCode>) -> Res<Json<Value>> {
    let (target, is_email) = normalize(&b.target)?;

    let recent: i64 = sqlx::query_scalar(
        "SELECT COUNT(*) FROM otp_codes WHERE target = $1 AND created_at > now() - interval '10 minutes'",
    )
    .bind(&target)
    .fetch_one(&s.db)
    .await?;
    if recent >= 3 {
        return Err(AppError::TooMany);
    }

    let code = format!("{:06}", rand::thread_rng().gen_range(0..1_000_000));
    sqlx::query("INSERT INTO otp_codes (target, code_hash, expires_at) VALUES ($1, $2, now() + interval '10 minutes')")
        .bind(&target)
        .bind(hash_code(&target, &code, &s.jwt_secret))
        .execute(&s.db)
        .await?;

    s.notifier.send(is_email, &target, &code).await.map_err(|_| AppError::Internal)?;
    Ok(Json(json!({ "ok": true })))
}

#[derive(Deserialize)]
pub struct VerifyCode {
    target: String,
    code: String,
    invite: Option<String>,
}

pub async fn verify_code(State(s): State<AppState>, Json(b): Json<VerifyCode>) -> Res<Json<Value>> {
    let (target, is_email) = normalize(&b.target)?;

    let row: Option<(i64, String, i32)> = sqlx::query_as(
        "SELECT id, code_hash, attempts FROM otp_codes
         WHERE target = $1 AND used = FALSE AND expires_at > now()
         ORDER BY created_at DESC LIMIT 1",
    )
    .bind(&target)
    .fetch_optional(&s.db)
    .await?;
    let (otp_id, expected, attempts) = row.ok_or(AppError::BadRequest("code_expired"))?;
    if attempts >= 5 {
        return Err(AppError::TooMany);
    }
    sqlx::query("UPDATE otp_codes SET attempts = attempts + 1 WHERE id = $1")
        .bind(otp_id)
        .execute(&s.db)
        .await?;
    if hash_code(&target, b.code.trim(), &s.jwt_secret) != expected {
        return Err(AppError::BadRequest("wrong_code"));
    }
    sqlx::query("UPDATE otp_codes SET used = TRUE WHERE id = $1")
        .bind(otp_id)
        .execute(&s.db)
        .await?;

    let col = if is_email { "email" } else { "phone" };
    let existing: Option<Uuid> = sqlx::query_scalar(&format!("SELECT id FROM users WHERE {col} = $1"))
        .bind(&target)
        .fetch_optional(&s.db)
        .await?;

    let user_id = match existing {
        Some(id) => id,
        None => {
            let id = Uuid::new_v4();
            let name = if is_email {
                target.split('@').next().unwrap_or("M user").chars().take(30).collect::<String>()
            } else {
                format!("M {}", &target[target.len() - 4..])
            };
            let avatar = rand::thread_rng().gen_range(0..12).to_string();
            let mut tx = s.db.begin().await?;
            sqlx::query(&format!(
                "INSERT INTO users (id, {col}, name, avatar_value, invite_code) VALUES ($1, $2, $3, $4, $5)"
            ))
            .bind(id)
            .bind(&target)
            .bind(name)
            .bind(avatar)
            .bind(invite_code())
            .execute(&mut *tx)
            .await?;
            sqlx::query("INSERT INTO user_settings (user_id) VALUES ($1)")
                .bind(id)
                .execute(&mut *tx)
                .await?;
            tx.commit().await?;
            id
        }
    };

    if let Some(code) = b.invite.as_deref() {
        let _ = connect_by_invite(&s.db, user_id, code).await;
    }

    let token = make_token(&s.jwt_secret, user_id)?;
    Ok(Json(json!({ "token": token, "user": fetch_user(&s.db, user_id).await? })))
}

// ---------- profile ----------

pub async fn get_me(State(s): State<AppState>, AuthUser(id): AuthUser) -> Res<Json<User>> {
    Ok(Json(fetch_user(&s.db, id).await?))
}

#[derive(Deserialize)]
pub struct PatchMe {
    name: Option<String>,
    bio: Option<String>,
    avatar_kind: Option<String>,
    avatar_value: Option<String>,
    banner: Option<i16>,
    look: Option<String>,
}

/// Profile look = five numbers joined by dots (name style, avatar decoration, effect, frame, nameplate).
fn valid_look(l: &str) -> bool {
    let parts: Vec<&str> = l.split('.').collect();
    parts.len() == 5 && parts.iter().all(|p| p.parse::<u8>().map_or(false, |n| n < 20))
}

pub async fn patch_me(State(s): State<AppState>, AuthUser(id): AuthUser, Json(b): Json<PatchMe>) -> Res<Json<User>> {
    if let Some(n) = &b.name {
        if n.trim().is_empty() || n.chars().count() > 30 {
            return Err(AppError::BadRequest("invalid_name"));
        }
    }
    if matches!(&b.bio, Some(x) if x.chars().count() > 120) {
        return Err(AppError::BadRequest("bio_too_long"));
    }
    if matches!(&b.avatar_kind, Some(k) if k != "preset" && k != "photo") {
        return Err(AppError::BadRequest("invalid_avatar"));
    }
    if matches!(&b.avatar_value, Some(v) if v.len() > 300_000) {
        return Err(AppError::BadRequest("avatar_too_large"));
    }
    if matches!(b.banner, Some(x) if !(0..=5).contains(&x)) {
        return Err(AppError::BadRequest("invalid_banner"));
    }
    if matches!(&b.look, Some(l) if !valid_look(l)) {
        return Err(AppError::BadRequest("invalid_look"));
    }

    sqlx::query(
        "UPDATE users SET
           name = COALESCE($2, name), bio = COALESCE($3, bio),
           avatar_kind = COALESCE($4, avatar_kind), avatar_value = COALESCE($5, avatar_value),
           banner = COALESCE($6::smallint, banner),
           banner_kind = CASE WHEN $6::smallint IS NULL THEN banner_kind ELSE 'preset' END,
           look = COALESCE($7, look)
         WHERE id = $1",
    )
    .bind(id)
    .bind(b.name.map(|n| n.trim().to_string()))
    .bind(b.bio)
    .bind(b.avatar_kind)
    .bind(b.avatar_value)
    .bind(b.banner)
    .bind(b.look)
    .execute(&s.db)
    .await?;
    Ok(Json(fetch_user(&s.db, id).await?))
}

#[derive(Deserialize)]
pub struct SetPassword {
    current: Option<String>,
    new: String,
}

pub async fn set_password(State(s): State<AppState>, AuthUser(id): AuthUser, Json(b): Json<SetPassword>) -> Res<StatusCode> {
    if b.new.chars().count() < 8 {
        return Err(AppError::BadRequest("password_too_short"));
    }
    let old: Option<String> = sqlx::query_scalar("SELECT password_hash FROM users WHERE id = $1")
        .bind(id)
        .fetch_one(&s.db)
        .await?;
    if let Some(hash) = old {
        let current = b.current.ok_or(AppError::BadRequest("current_password_required"))?;
        let parsed = PasswordHash::new(&hash).map_err(|_| AppError::Internal)?;
        Argon2::default()
            .verify_password(current.as_bytes(), &parsed)
            .map_err(|_| AppError::Forbidden("wrong_password"))?;
    }
    let salt = SaltString::generate(&mut OsRng);
    let new_hash = Argon2::default()
        .hash_password(b.new.as_bytes(), &salt)
        .map_err(|_| AppError::Internal)?
        .to_string();
    sqlx::query("UPDATE users SET password_hash = $2 WHERE id = $1")
        .bind(id)
        .bind(new_hash)
        .execute(&s.db)
        .await?;
    Ok(StatusCode::NO_CONTENT)
}

// ---------- settings ----------

pub async fn get_settings(State(s): State<AppState>, AuthUser(id): AuthUser) -> Res<Json<Settings>> {
    let row = sqlx::query_as::<_, Settings>(
        "SELECT read_receipts, show_online, last_seen, photo_vis, story_vis, add_by_phone, calls, language
         FROM user_settings WHERE user_id = $1",
    )
    .bind(id)
    .fetch_one(&s.db)
    .await?;
    Ok(Json(row))
}

#[derive(Deserialize)]
pub struct PatchSettings {
    read_receipts: Option<bool>,
    show_online: Option<bool>,
    last_seen: Option<String>,
    photo_vis: Option<String>,
    story_vis: Option<String>,
    add_by_phone: Option<String>,
    calls: Option<String>,
    language: Option<String>,
}

pub async fn patch_settings(State(s): State<AppState>, AuthUser(id): AuthUser, Json(b): Json<PatchSettings>) -> Res<Json<Settings>> {
    for v in [&b.last_seen, &b.photo_vis, &b.story_vis, &b.add_by_phone, &b.calls].into_iter().flatten() {
        if !valid_vis(v) {
            return Err(AppError::BadRequest("invalid_visibility"));
        }
    }
    // Language is a BCP 47 tag such as "ar", "en", "pt-BR". Any language is accepted.
    if matches!(&b.language, Some(l) if l.len() > 12 || !l.chars().all(|c| c.is_ascii_alphanumeric() || c == '-')) {
        return Err(AppError::BadRequest("invalid_language"));
    }
    let row = sqlx::query_as::<_, Settings>(
        "UPDATE user_settings SET
           read_receipts = COALESCE($2, read_receipts), show_online = COALESCE($3, show_online),
           last_seen = COALESCE($4, last_seen), photo_vis = COALESCE($5, photo_vis),
           story_vis = COALESCE($6, story_vis), add_by_phone = COALESCE($7, add_by_phone),
           calls = COALESCE($8, calls), language = COALESCE($9, language)
         WHERE user_id = $1
         RETURNING read_receipts, show_online, last_seen, photo_vis, story_vis, add_by_phone, calls, language",
    )
    .bind(id)
    .bind(b.read_receipts)
    .bind(b.show_online)
    .bind(b.last_seen)
    .bind(b.photo_vis)
    .bind(b.story_vis)
    .bind(b.add_by_phone)
    .bind(b.calls)
    .bind(b.language)
    .fetch_one(&s.db)
    .await?;
    Ok(Json(row))
}

// ---------- invites and contacts ----------

async fn connect_by_invite(db: &sqlx::PgPool, me: Uuid, code: &str) -> Res<()> {
    let inviter: Uuid = sqlx::query_scalar("SELECT id FROM users WHERE invite_code = $1")
        .bind(code)
        .fetch_optional(db)
        .await?
        .ok_or(AppError::NotFound)?;
    if inviter == me {
        return Err(AppError::BadRequest("cannot_invite_self"));
    }
    sqlx::query(
        "INSERT INTO contacts (user_id, contact_id) VALUES ($1, $2), ($2, $1) ON CONFLICT DO NOTHING",
    )
    .bind(me)
    .bind(inviter)
    .execute(db)
    .await?;
    Ok(())
}

pub async fn accept_invite(State(s): State<AppState>, AuthUser(id): AuthUser, Path(code): Path<String>) -> Res<StatusCode> {
    connect_by_invite(&s.db, id, &code).await?;
    Ok(StatusCode::NO_CONTENT)
}

#[derive(Serialize, FromRow)]
pub struct Contact {
    id: Uuid,
    name: String,
    bio: String,
    avatar_kind: String,
    avatar_value: String,
}

pub async fn list_contacts(State(s): State<AppState>, AuthUser(id): AuthUser) -> Res<Json<Vec<Contact>>> {
    let rows = sqlx::query_as::<_, Contact>(
        "SELECT u.id, u.name, u.bio,
                CASE WHEN s.photo_vis = 'nobody' THEN 'preset' ELSE u.avatar_kind END AS avatar_kind,
                CASE WHEN s.photo_vis = 'nobody' THEN '0' ELSE u.avatar_value END AS avatar_value
         FROM contacts c
         JOIN users u ON u.id = c.contact_id
         JOIN user_settings s ON s.user_id = u.id
         WHERE c.user_id = $1 ORDER BY u.name",
    )
    .bind(id)
    .fetch_all(&s.db)
    .await?;
    Ok(Json(rows))
}

#[derive(Deserialize)]
pub struct AddByPhone {
    phone: String,
}

pub async fn add_contact_by_phone(State(s): State<AppState>, AuthUser(id): AuthUser, Json(b): Json<AddByPhone>) -> Res<StatusCode> {
    let (phone, is_email) = normalize(&b.phone)?;
    if is_email {
        return Err(AppError::BadRequest("invalid_phone"));
    }
    let target: Option<(Uuid, String)> = sqlx::query_as(
        "SELECT u.id, s.add_by_phone FROM users u JOIN user_settings s ON s.user_id = u.id WHERE u.phone = $1",
    )
    .bind(&phone)
    .fetch_optional(&s.db)
    .await?;
    let (other, policy) = target.ok_or(AppError::NotFound)?;
    if other == id {
        return Err(AppError::BadRequest("cannot_add_self"));
    }
    let allowed = match policy.as_str() {
        "all" => true,
        "contacts" => sqlx::query_scalar::<_, bool>(
            "SELECT EXISTS (SELECT 1 FROM contacts WHERE user_id = $1 AND contact_id = $2)",
        )
        .bind(other)
        .bind(id)
        .fetch_one(&s.db)
        .await?,
        _ => false,
    };
    if !allowed {
        // Same answer as "not found" so privacy settings cannot be probed.
        return Err(AppError::NotFound);
    }
    sqlx::query("INSERT INTO contacts (user_id, contact_id) VALUES ($1, $2) ON CONFLICT DO NOTHING")
        .bind(id)
        .bind(other)
        .execute(&s.db)
        .await?;
    Ok(StatusCode::NO_CONTENT)
}

// ---------- photo and banner uploads ----------

/// Picks the file extension from the Content-Type header. Only a few safe types are accepted.
pub fn upload_ext(headers: &HeaderMap, allow_video: bool) -> Res<&'static str> {
    let ct = headers.get(CONTENT_TYPE).and_then(|v| v.to_str().ok()).unwrap_or("");
    match ct {
        "image/jpeg" => Ok("jpg"),
        "image/png" => Ok("png"),
        "image/webp" => Ok("webp"),
        "video/mp4" if allow_video => Ok("mp4"),
        "video/webm" if allow_video => Ok("webm"),
        _ => Err(AppError::BadRequest("unsupported_file")),
    }
}

pub async fn store_file(s: &AppState, ext: &str, body: &[u8]) -> Res<String> {
    let name = format!("{}.{}", Uuid::new_v4(), ext);
    tokio::fs::write(format!("{}/{}", s.upload_dir, name), body).await.map_err(|e| {
        tracing::error!("cannot save upload: {e}");
        AppError::Internal
    })?;
    Ok(format!("/files/{name}"))
}

/// Best effort: delete an old uploaded file. Only plain file names inside the uploads folder are touched.
pub async fn remove_file(s: &AppState, url: &str) {
    if let Some(name) = url.strip_prefix("/files/") {
        if !name.is_empty() && !name.contains('/') && !name.contains('\\') && !name.contains("..") {
            let _ = tokio::fs::remove_file(format!("{}/{}", s.upload_dir, name)).await;
        }
    }
}

pub async fn upload_avatar(State(s): State<AppState>, AuthUser(id): AuthUser, headers: HeaderMap, body: Bytes) -> Res<Json<User>> {
    let ext = upload_ext(&headers, false)?;
    if body.is_empty() {
        return Err(AppError::BadRequest("empty_file"));
    }
    if body.len() > 4_000_000 {
        return Err(AppError::BadRequest("file_too_large"));
    }
    let old: (String, String) = sqlx::query_as("SELECT avatar_kind, avatar_value FROM users WHERE id = $1")
        .bind(id)
        .fetch_one(&s.db)
        .await?;
    let url = store_file(&s, ext, &body).await?;
    sqlx::query("UPDATE users SET avatar_kind = 'photo', avatar_value = $2 WHERE id = $1")
        .bind(id)
        .bind(&url)
        .execute(&s.db)
        .await?;
    if old.0 == "photo" {
        remove_file(&s, &old.1).await;
    }
    Ok(Json(fetch_user(&s.db, id).await?))
}

pub async fn upload_banner(State(s): State<AppState>, AuthUser(id): AuthUser, headers: HeaderMap, body: Bytes) -> Res<Json<User>> {
    let ext = upload_ext(&headers, true)?;
    if body.is_empty() {
        return Err(AppError::BadRequest("empty_file"));
    }
    let is_video = ext == "mp4" || ext == "webm";
    let limit = if is_video { 20_000_000 } else { 6_000_000 };
    if body.len() > limit {
        return Err(AppError::BadRequest("file_too_large"));
    }
    let old: (String, String) = sqlx::query_as("SELECT banner_kind, banner_url FROM users WHERE id = $1")
        .bind(id)
        .fetch_one(&s.db)
        .await?;
    let url = store_file(&s, ext, &body).await?;
    sqlx::query("UPDATE users SET banner_kind = $2, banner_url = $3 WHERE id = $1")
        .bind(id)
        .bind(if is_video { "video" } else { "image" })
        .bind(&url)
        .execute(&s.db)
        .await?;
    if old.0 != "preset" {
        remove_file(&s, &old.1).await;
    }
    Ok(Json(fetch_user(&s.db, id).await?))
}

// ---------- viewing other people ----------

#[derive(Serialize, FromRow)]
pub struct PublicUser {
    id: Uuid,
    name: String,
    bio: String,
    avatar_kind: String,
    avatar_value: String,
    banner: i16,
    banner_kind: String,
    banner_url: String,
    look: String,
}

/// A profile can be opened by its owner and by people the owner is connected with.
pub async fn get_user(State(s): State<AppState>, AuthUser(me): AuthUser, Path(id): Path<Uuid>) -> Res<Json<PublicUser>> {
    if id != me {
        let linked: bool = sqlx::query_scalar(
            "SELECT EXISTS (SELECT 1 FROM contacts WHERE user_id = $1 AND contact_id = $2)",
        )
        .bind(me)
        .bind(id)
        .fetch_one(&s.db)
        .await?;
        if !linked {
            return Err(AppError::NotFound);
        }
    }
    let mut u = sqlx::query_as::<_, PublicUser>(
        "SELECT id, name, bio, avatar_kind, avatar_value, banner, banner_kind, banner_url, look FROM users WHERE id = $1",
    )
    .bind(id)
    .fetch_optional(&s.db)
    .await?
    .ok_or(AppError::NotFound)?;
    if id != me {
        let vis: String = sqlx::query_scalar("SELECT photo_vis FROM user_settings WHERE user_id = $1")
            .bind(id)
            .fetch_one(&s.db)
            .await?;
        if vis == "nobody" {
            u.avatar_kind = "preset".into();
            u.avatar_value = "0".into();
        }
    }
    Ok(Json(u))
}

// ---------- which of my phone contacts are on M ----------

#[derive(Deserialize)]
pub struct MatchReq {
    phones: Vec<String>,
}

#[derive(Serialize, FromRow)]
pub struct Match {
    id: Uuid,
    phone: Option<String>,
    name: String,
    avatar_kind: String,
    avatar_value: String,
    is_contact: bool,
}

/// Takes phone numbers from the person's address book and returns the ones registered on M.
/// People who turned off "add me by number" are not revealed.
pub async fn match_contacts(State(s): State<AppState>, AuthUser(me): AuthUser, Json(b): Json<MatchReq>) -> Res<Json<Vec<Match>>> {
    if b.phones.len() > 3000 {
        return Err(AppError::BadRequest("too_many_numbers"));
    }
    let phones: Vec<String> = b
        .phones
        .iter()
        .filter_map(|p| match normalize(p) {
            Ok((n, false)) => Some(n),
            _ => None,
        })
        .collect();
    if phones.is_empty() {
        return Ok(Json(vec![]));
    }
    let rows = sqlx::query_as::<_, Match>(
        "SELECT u.id, u.phone, u.name,
                CASE WHEN s.photo_vis = 'nobody' THEN 'preset' ELSE u.avatar_kind END AS avatar_kind,
                CASE WHEN s.photo_vis = 'nobody' THEN '0' ELSE u.avatar_value END AS avatar_value,
                EXISTS (SELECT 1 FROM contacts c WHERE c.user_id = $1 AND c.contact_id = u.id) AS is_contact
         FROM users u JOIN user_settings s ON s.user_id = u.id
         WHERE u.phone = ANY($2) AND u.id <> $1
           AND (s.add_by_phone = 'all'
                OR (s.add_by_phone = 'contacts'
                    AND EXISTS (SELECT 1 FROM contacts c2 WHERE c2.user_id = u.id AND c2.contact_id = $1))
                OR EXISTS (SELECT 1 FROM contacts c3 WHERE c3.user_id = $1 AND c3.contact_id = u.id))",
    )
    .bind(me)
    .bind(&phones)
    .fetch_all(&s.db)
    .await?;
    Ok(Json(rows))
}
