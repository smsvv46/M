use std::collections::HashMap;

use axum::{extract::State, Json};
use serde::Deserialize;
use serde_json::{json, Value};

use crate::{auth::AuthUser, error::AppError, AppState};

type Res<T> = Result<T, AppError>;

/// The English texts of the app. Regenerated from the app's own table before each release.
const EN_JSON: &str = include_str!("en.json");

#[derive(Deserialize)]
pub struct TranslateReq {
    /// Language code such as "fr", "pt-BR", "ja".
    lang: String,
    /// The language's name in English, used to tell the translator what to produce.
    name: String,
}

/// Returns every app text in the requested language. Texts that were never translated before are
/// translated once, stored, and then served from the database to everyone.
pub async fn translate(State(s): State<AppState>, AuthUser(_me): AuthUser, Json(b): Json<TranslateReq>) -> Res<Json<HashMap<String, String>>> {
    let lang = b.lang.trim().to_string();
    if lang.is_empty() || lang.len() > 12 || !lang.chars().all(|c| c.is_ascii_alphanumeric() || c == '-') {
        return Err(AppError::BadRequest("invalid_language"));
    }
    let name = b.name.trim().to_string();
    if name.is_empty() || name.chars().count() > 60 || !name.chars().all(|c| c.is_alphabetic() || c == ' ' || c == '(' || c == ')' || c == '-') {
        return Err(AppError::BadRequest("invalid_language"));
    }
    // English and Arabic are built into the app.
    if lang == "en" || lang == "ar" {
        return Ok(Json(HashMap::new()));
    }

    let source: HashMap<String, String> = serde_json::from_str(EN_JSON).map_err(|_| AppError::Internal)?;

    let rows: Vec<(String, String)> = sqlx::query_as("SELECT key, text FROM translations WHERE lang = $1")
        .bind(&lang)
        .fetch_all(&s.db)
        .await?;
    let mut out: HashMap<String, String> = rows.into_iter().filter(|(k, _)| source.contains_key(k)).collect();

    let mut missing: Vec<(String, String)> = source
        .iter()
        .filter(|(k, _)| !out.contains_key(*k))
        .map(|(k, v)| (k.clone(), v.clone()))
        .collect();
    missing.sort();

    if !missing.is_empty() {
        match &s.translate_key {
            Some(key) => {
                for chunk in missing.chunks(60) {
                    match translate_chunk(&s, key, &name, chunk).await {
                        Ok(map) => {
                            for (k, v) in map {
                                let v = v.trim().to_string();
                                if v.is_empty() || v.chars().count() > 600 || !source.contains_key(&k) {
                                    continue;
                                }
                                let _ = sqlx::query("INSERT INTO translations (lang, key, text) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING")
                                    .bind(&lang)
                                    .bind(&k)
                                    .bind(&v)
                                    .execute(&s.db)
                                    .await;
                                out.insert(k, v);
                            }
                        }
                        Err(e) => tracing::error!("translation to {lang} failed: {e}"),
                    }
                }
            }
            None => tracing::warn!("ANTHROPIC_API_KEY is not set, so {lang} cannot be translated"),
        }
    }
    Ok(Json(out))
}

async fn translate_chunk(s: &AppState, key: &str, language: &str, items: &[(String, String)]) -> Result<HashMap<String, String>, String> {
    let mut src = serde_json::Map::new();
    for (k, v) in items {
        src.insert(k.clone(), Value::String(v.clone()));
    }
    let prompt = format!(
        "Translate these user-interface texts of a messaging app called M from English into {language}. \
         Rules: keep the app name \"M\" and any numbers, emoji and symbols unchanged; use short, natural wording \
         that a native speaker would expect in a mobile app; return ONLY a JSON object with exactly the same keys \
         and the translated texts as values. No explanations and no markdown.\n\n{}",
        Value::Object(src)
    );
    let req = json!({
        "model": s.translate_model,
        "max_tokens": 8000,
        "messages": [{ "role": "user", "content": prompt }]
    });
    let res = s
        .http
        .post("https://api.anthropic.com/v1/messages")
        .header("x-api-key", key)
        .header("anthropic-version", "2023-06-01")
        .header("content-type", "application/json")
        .body(req.to_string())
        .send()
        .await
        .map_err(|e| e.to_string())?;
    let status = res.status();
    let text = res.text().await.map_err(|e| e.to_string())?;
    if !status.is_success() {
        return Err(format!("{status}: {text}"));
    }
    let v: Value = serde_json::from_str(&text).map_err(|e| e.to_string())?;
    let out = v["content"][0]["text"].as_str().ok_or("no text in the reply")?;
    let start = out.find('{').ok_or("no JSON in the reply")?;
    let end = out.rfind('}').ok_or("no JSON in the reply")?;
    serde_json::from_str::<HashMap<String, String>>(&out[start..=end]).map_err(|e| e.to_string())
}
