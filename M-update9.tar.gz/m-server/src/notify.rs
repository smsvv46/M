use lettre::{
    message::Message, transport::smtp::authentication::Credentials, AsyncSmtpTransport,
    AsyncTransport, Tokio1Executor,
};

struct Twilio {
    sid: String,
    token: String,
    from: String,
}

/// Sends verification codes. Email goes through SMTP, phone through Twilio.
/// When a provider is not configured the code is printed to the server log,
/// which is enough for local development.
pub struct Notifier {
    smtp: Option<AsyncSmtpTransport<Tokio1Executor>>,
    smtp_from: String,
    twilio: Option<Twilio>,
    http: reqwest::Client,
}

impl Notifier {
    pub fn from_env() -> Self {
        let env = |k: &str| std::env::var(k).ok().filter(|v| !v.is_empty());

        let smtp = match (env("SMTP_HOST"), env("SMTP_USER"), env("SMTP_PASS")) {
            (Some(host), Some(user), Some(pass)) => AsyncSmtpTransport::<Tokio1Executor>::relay(&host)
                .ok()
                .map(|b| b.credentials(Credentials::new(user, pass)).build()),
            _ => None,
        };
        let twilio = match (env("TWILIO_SID"), env("TWILIO_TOKEN"), env("TWILIO_FROM")) {
            (Some(sid), Some(token), Some(from)) => Some(Twilio { sid, token, from }),
            _ => None,
        };

        Self {
            smtp,
            smtp_from: env("SMTP_FROM").unwrap_or_else(|| "M <no-reply@localhost>".into()),
            twilio,
            http: reqwest::Client::new(),
        }
    }

    pub async fn send(&self, is_email: bool, target: &str, code: &str) -> Result<(), ()> {
        if is_email {
            match &self.smtp {
                Some(smtp) => {
                    let msg = Message::builder()
                        .from(self.smtp_from.parse().map_err(|_| ())?)
                        .to(target.parse().map_err(|_| ())?)
                        .subject("M verification code")
                        .body(format!("Your M code is {code}. It expires in 10 minutes. Never share it."))
                        .map_err(|_| ())?;
                    smtp.send(msg).await.map_err(|e| tracing::error!("smtp: {e}"))?;
                    Ok(())
                }
                None => {
                    tracing::warn!("SMTP not configured. Code for {target}: {code}");
                    Ok(())
                }
            }
        } else {
            match &self.twilio {
                Some(t) => {
                    let url = format!("https://api.twilio.com/2010-04-01/Accounts/{}/Messages.json", t.sid);
                    let res = self
                        .http
                        .post(url)
                        .basic_auth(&t.sid, Some(&t.token))
                        .form(&[
                            ("To", target),
                            ("From", t.from.as_str()),
                            ("Body", &format!("Your M code is {code}")),
                        ])
                        .send()
                        .await
                        .map_err(|e| tracing::error!("twilio: {e}"))?;
                    if res.status().is_success() { Ok(()) } else { Err(()) }
                }
                None => {
                    tracing::warn!("Twilio not configured. Code for {target}: {code}");
                    Ok(())
                }
            }
        }
    }
}
