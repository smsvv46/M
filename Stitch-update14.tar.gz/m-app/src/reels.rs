//! Reels: short videos from everyone. Like, comment, repost, share, follow.

use crate::{
    api::{call, file_url, fmt_count, get_bool, reel_from_url, reel_link, url_encode, Contact, Method, Reel, ReelComment},
    avatar,
    i18n::{err_text, tr},
    login::Icon,
    look::VerifiedBadge,
    social::{open_chat, upload_value_big, Overlay, ICON_BACK, ICON_PLUS},
    Ctx,
};
use dioxus::prelude::*;
use serde_json::json;
use std::collections::HashSet;

const ICON_HEART: &str = "M12 21s-7-4.6-9.3-9.1C1 8.5 3 5 6.4 5c2 0 3.6 1.1 4.6 2.7C12 6.1 13.6 5 15.6 5 19 5 21 8.5 19.3 11.9 17 16.4 12 21 12 21z";
const ICON_COMMENT: &str = "M21 12a8 8 0 0 1-11.5 7.2L4 20l1-4.6A8 8 0 1 1 21 12z";
const ICON_REPOST: &str = "M17 2l4 4-4 4M3 11V9a3 3 0 0 1 3-3h15M7 22l-4-4 4-4M21 13v2a3 3 0 0 1-3 3H3";
const ICON_SHARE: &str = "M4 12v7a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-7M16 6l-4-4-4 4M12 2v13";
const ICON_TRASH: &str = "M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3";

/// Loads one page of reels. `before` is the cursor of the last reel already shown.
async fn fetch_page(token: Option<String>, following: bool, user: Option<String>, before: Option<i64>) -> Vec<Reel> {
    let mut q: Vec<String> = Vec::new();
    if let Some(b) = before {
        q.push(format!("before={b}"));
    }
    if let Some(u) = user {
        q.push(format!("user={u}"));
    }
    if following {
        q.push("following=true".to_string());
    }
    let path = format!("/reels?{}", q.join("&"));
    match call(Method::GET, &path, None, token).await {
        Ok(v) => serde_json::from_value(v).unwrap_or_default(),
        Err(_) => Vec::new(),
    }
}

/// Plays the reel that is on screen and pauses the others. Tapping a video turns the sound on or off.
const OBSERVE_JS: &str = r#"
(function () {
  if (window.__reelObs) window.__reelObs.disconnect();
  const o = new IntersectionObserver((es) => es.forEach((e) => {
    const v = e.target.querySelector('video');
    if (!v) return;
    if (e.isIntersecting && e.intersectionRatio > 0.6) { v.muted = !window.__reelSound; v.play().catch(() => {}); }
    else { v.pause(); }
  }), { threshold: [0, 0.6, 1] });
  document.querySelectorAll('.reel').forEach((r) => o.observe(r));
  window.__reelObs = o;
  if (!window.__reelTap) {
    window.__reelTap = true;
    document.addEventListener('click', (e) => {
      const v = e.target.closest && e.target.closest('.reel-vid');
      if (v) { window.__reelSound = !window.__reelSound; v.muted = !window.__reelSound; }
    });
  }
})();
"#;

fn copy_or_share(url: &str, share: bool) {
    let u = serde_json::to_string(url).unwrap_or_default();
    let js = if share {
        format!("if (navigator.share) {{ navigator.share({{ url: {u} }}).catch(()=>{{}}); }} else {{ navigator.clipboard && navigator.clipboard.writeText({u}); }}")
    } else {
        format!("navigator.clipboard && navigator.clipboard.writeText({u});")
    };
    let _ = js_sys::eval(&js);
}

/// The Reels tab: everyone's videos, or only the people I follow.
#[component]
pub fn ReelsTab(overlay: Signal<Overlay>) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let mut following = use_signal(|| false);
    let mut composer = use_signal(|| false);
    let mut refresh = use_signal(|| 0u32);
    let mut caption = use_signal(String::new);
    let mut busy = use_signal(|| false);
    let mut note = use_signal(String::new);
    let mut chosen = use_signal(|| false);

    let post = move |_| {
        spawn(async move {
            if !chosen() {
                note.set(err_text(&lang(), "empty_file"));
                return;
            }
            busy.set(true);
            note.set(String::new());
            let path = format!("/reels?caption={}", url_encode(&caption()));
            match upload_value_big("pick-reel", &path, 0, true, 50, token()).await {
                Ok(_) => {
                    caption.set(String::new());
                    chosen.set(false);
                    composer.set(false);
                    following.set(false);
                    refresh.set(refresh() + 1);
                }
                Err(e) => note.set(err_text(&lang(), &e)),
            }
            busy.set(false);
        });
    };
    let caption_ph = tr(&lang(), "caption_ph");
    let feed_key = format!("{}-{}", following(), refresh());

    rsx! {
        header { class: "top reels-top",
            h1 { class: "display", {tr(&lang(), "reels")} }
            button { class: "icon-btn", r#type: "button", "aria-label": tr(&lang(), "new_reel"), onclick: move |_| composer.set(!composer()), Icon { d: ICON_PLUS } }
        }
        div { class: "seg reels-seg",
            button { r#type: "button", class: if !following() { "on" } else { "" }, onclick: move |_| following.set(false), {tr(&lang(), "for_you")} }
            button { r#type: "button", class: if following() { "on" } else { "" }, onclick: move |_| following.set(true), {tr(&lang(), "following")} }
        }
        if composer() {
            section { class: "card reel-composer",
                label { class: "chip-btn file-btn",
                    {tr(&lang(), "choose_video")}
                    input {
                        id: "pick-reel", r#type: "file", accept: "video/mp4,video/webm", hidden: true,
                        onchange: move |_| chosen.set(true),
                    }
                }
                if chosen() { small { class: "hint", "✓ " {tr(&lang(), "video_ready")} } }
                input { class: "plain", r#type: "text", maxlength: "300", placeholder: "{caption_ph}", value: "{caption}", oninput: move |e| caption.set(e.value()) }
                button { class: "silver small", r#type: "button", disabled: busy(), onclick: post,
                    if busy() { {tr(&lang(), "uploading")} } else { {tr(&lang(), "post_reel")} }
                }
                if !note().is_empty() { p { class: "note err", role: "status", "{note}" } }
            }
        }
        ReelsFeed { key: "{feed_key}", following: following(), user: None::<String>, single: None::<String>, overlay }
    }
}

/// A full-screen page with someone's reels, or one reel opened from a link or notification.
#[component]
pub fn ReelsPage(user: Option<String>, single: Option<String>, overlay: Signal<Overlay>) -> Element {
    let lang = use_context::<Ctx>().lang;
    rsx! {
        header { class: "bar",
            button { class: "icon-btn", r#type: "button", "aria-label": tr(&lang(), "back"), onclick: move |_| overlay.set(Overlay::None), Icon { d: ICON_BACK } }
            h2 { class: "bar-title", {tr(&lang(), "reels")} }
        }
        ReelsFeed { following: false, user, single, overlay }
    }
}

#[component]
fn ReelsFeed(following: bool, user: Option<String>, single: Option<String>, overlay: Signal<Overlay>) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let mut reels = use_signal(Vec::<Reel>::new);
    let mut loading = use_signal(|| true);
    let mut done = use_signal(|| false);
    // 0 = nothing, 1 = comments, 2 = share; and which reel it is for
    let mut sheet = use_signal(|| (0u8, String::new()));

    let (u0, s0) = (user.clone(), single.clone());
    use_hook(move || {
        spawn(async move {
            if let Some(id) = s0 {
                if let Ok(v) = call(Method::GET, &format!("/reels/{id}"), None, token()).await {
                    if let Ok(r) = serde_json::from_value::<Reel>(v) {
                        reels.set(vec![r]);
                    }
                }
                done.set(true);
            } else {
                let mut first = fetch_page(token(), following, u0.clone(), None).await;
                done.set(first.len() < 20);
                // A shared link opens that reel first.
                if u0.is_none() && !following {
                    if let Some(id) = reel_from_url() {
                        if let Ok(v) = call(Method::GET, &format!("/reels/{id}"), None, token()).await {
                            if let Ok(r) = serde_json::from_value::<Reel>(v) {
                                first.retain(|x| x.id != r.id);
                                first.insert(0, r);
                            }
                        }
                    }
                }
                reels.set(first);
            }
            loading.set(false);
        });
    });

    let more_user = user.clone();
    let more = move |_| {
        let u = more_user.clone();
        spawn(async move {
            let before = reels().last().map(|r| r.cur);
            loading.set(true);
            let page = fetch_page(token(), following, u, before).await;
            if page.len() < 20 {
                done.set(true);
            }
            reels.write().extend(page);
            loading.set(false);
        });
    };

    // Start the playback rules whenever the list changes.
    use_effect(move || {
        let _ = reels().len();
        let _ = js_sys::eval(OBSERVE_JS);
    });

    let (kind, sheet_id) = sheet();
    let list = reels();
    let empty = !loading() && list.is_empty();

    rsx! {
        div { class: "reels-wrap",
            div { class: "reels",
                for r in list.iter() {
                    ReelItem {
                        key: "{r.id}", reel: r.clone(), overlay,
                        on_deleted: move |id: String| reels.write().retain(|x| x.id != id),
                        on_sheet: move |v: (u8, String)| sheet.set(v),
                    }
                }
                if empty { p { class: "hint center-text reels-empty", {tr(&lang(), if following { "no_following_reels" } else { "no_reels" })} } }
                if loading() { p { class: "hint center-text", {tr(&lang(), "loading")} } }
                if !loading() && !done() && !list.is_empty() {
                    button { class: "chip-btn reels-more", r#type: "button", onclick: more, {tr(&lang(), "load_more")} }
                }
            }
            if kind == 1 {
                CommentsSheet { key: "c-{sheet_id}", reel_id: sheet_id.clone(), on_close: move |_| sheet.set((0, String::new())) }
            }
            if kind == 2 {
                ShareSheet { key: "s-{sheet_id}", reel_id: sheet_id.clone(), on_close: move |_| sheet.set((0, String::new())) }
            }
        }
    }
}

#[component]
fn ReelItem(reel: Reel, mut overlay: Signal<Overlay>, on_deleted: EventHandler<String>, on_sheet: EventHandler<(u8, String)>) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let mut r = use_signal(|| reel.clone());
    let mut toast = use_signal(String::new);
    let me_id = ctx.user.read().as_ref().map(|u| u.id.clone()).unwrap_or_default();

    let cur = r();
    let mine = cur.user_id == me_id;
    let src = file_url(&cur.media_url);
    let preload = if get_bool("m_datasaver", false) { "none" } else { "metadata" };
    let (likes, comments, reposts) = (fmt_count(cur.likes), fmt_count(cur.comments), fmt_count(cur.reposts));
    let uid = cur.user_id.clone();
    let rid = cur.id.clone();

    let like = move |_| {
        spawn(async move {
            let c = r();
            let method = if c.liked { Method::DELETE } else { Method::POST };
            {
                let mut w = r.write();
                w.liked = !c.liked;
                w.likes += if c.liked { -1 } else { 1 };
            }
            if let Ok(v) = call(method, &format!("/reels/{}/like", c.id), None, token()).await {
                let mut w = r.write();
                w.likes = v["likes"].as_i64().unwrap_or(w.likes);
                w.liked = v["liked"].as_bool().unwrap_or(w.liked);
            }
        });
    };
    let follow_uid = uid.clone();
    let follow = move |_| {
        let id = follow_uid.clone();
        spawn(async move {
            let c = r();
            let method = if c.i_follow || c.requested { Method::DELETE } else { Method::POST };
            if let Ok(v) = call(method, &format!("/users/{id}/follow"), None, token()).await {
                let mut w = r.write();
                w.i_follow = v["i_follow"].as_bool().unwrap_or(false);
                w.requested = v["requested"].as_bool().unwrap_or(false);
            }
        });
    };
    let repost_id = rid.clone();
    let repost = move |_| {
        let id = repost_id.clone();
        spawn(async move {
            match call(Method::POST, &format!("/reels/{id}/repost"), None, token()).await {
                Ok(_) => {
                    r.write().reposts += 1;
                    toast.set(tr(&lang(), "reposted"));
                }
                Err(e) => toast.set(err_text(&lang(), &e)),
            }
        });
    };
    let del_id = rid.clone();
    let delete = move |_| {
        let id = del_id.clone();
        spawn(async move {
            if call(Method::DELETE, &format!("/reels/{id}"), None, token()).await.is_ok() {
                on_deleted.call(id);
            }
        });
    };
    let c_id = rid.clone();
    let s_id = rid.clone();
    let open_uid = uid.clone();

    rsx! {
        article { class: "reel",
            video {
                class: "reel-vid", src: "{src}", preload: "{preload}",
                "loop": "true", muted: true, "playsinline": "true",
            }
            div { class: "reel-info",
                if !cur.repost_name.is_empty() {
                    small { class: "reel-from", "↻ " {tr(&lang(), "reposted_from")} " " "{cur.repost_name}" }
                }
                div { class: "reel-author",
                    button { class: "reel-who", r#type: "button", onclick: move |_| overlay.set(Overlay::Profile(open_uid.clone())),
                        img { class: "avatar sm", src: "{avatar::user_uri(&cur.avatar_kind, &cur.avatar_value)}", alt: "" }
                        strong { "{cur.name}" }
                        if cur.verified { VerifiedBadge { size: 18 } }
                    }
                    if !mine {
                        button { class: if cur.i_follow || cur.requested { "chip-btn follow-mini on" } else { "chip-btn follow-mini" }, r#type: "button", onclick: follow,
                            if cur.i_follow { {tr(&lang(), "unfollow")} } else if cur.requested { {tr(&lang(), "requested")} } else { {tr(&lang(), "follow")} }
                        }
                    }
                }
                if !cur.caption.is_empty() { p { class: "reel-cap", "{cur.caption}" } }
                if !toast().is_empty() { p { class: "reel-toast", "{toast}" } }
            }
            div { class: "reel-actions",
                button { class: if cur.liked { "ra on" } else { "ra" }, r#type: "button", "aria-label": tr(&lang(), "like"), onclick: like,
                    Icon { d: ICON_HEART } span { "{likes}" }
                }
                button { class: "ra", r#type: "button", "aria-label": tr(&lang(), "comments"), onclick: move |_| on_sheet.call((1, c_id.clone())),
                    Icon { d: ICON_COMMENT } span { "{comments}" }
                }
                if !mine {
                    button { class: "ra", r#type: "button", "aria-label": tr(&lang(), "repost_reel"), onclick: repost,
                        Icon { d: ICON_REPOST } span { "{reposts}" }
                    }
                }
                button { class: "ra", r#type: "button", "aria-label": tr(&lang(), "share"), onclick: move |_| on_sheet.call((2, s_id.clone())),
                    Icon { d: ICON_SHARE } span { {tr(&lang(), "share")} }
                }
                if mine {
                    button { class: "ra", r#type: "button", "aria-label": tr(&lang(), "delete"), onclick: delete, Icon { d: ICON_TRASH } }
                }
            }
        }
    }
}

#[component]
fn CommentsSheet(reel_id: String, on_close: EventHandler<()>) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let mut items = use_signal(Vec::<ReelComment>::new);
    let mut text = use_signal(String::new);
    let mut busy = use_signal(|| false);
    let mut note = use_signal(String::new);

    let load_id = reel_id.clone();
    let load = move || {
        let id = load_id.clone();
        spawn(async move {
            if let Ok(v) = call(Method::GET, &format!("/reels/{id}/comments"), None, token()).await {
                items.set(serde_json::from_value(v).unwrap_or_default());
            }
        });
    };
    use_hook(move || load());

    let send_id = reel_id.clone();
    let send = move |_| {
        let id = send_id.clone();
        spawn(async move {
            let body = text().trim().to_string();
            if body.is_empty() {
                return;
            }
            busy.set(true);
            match call(Method::POST, &format!("/reels/{id}/comments"), Some(json!({ "body": body })), token()).await {
                Ok(_) => {
                    text.set(String::new());
                    note.set(String::new());
                    if let Ok(v) = call(Method::GET, &format!("/reels/{id}/comments"), None, token()).await {
                        items.set(serde_json::from_value(v).unwrap_or_default());
                    }
                }
                Err(e) => note.set(err_text(&lang(), &e)),
            }
            busy.set(false);
        });
    };
    let ph = tr(&lang(), "comment_ph");

    rsx! {
        div { class: "sheet-back", onclick: move |_| on_close.call(()) }
        div { class: "sheet",
            h3 { class: "section-title", {tr(&lang(), "comments")} }
            div { class: "sheet-list",
                if items().is_empty() { p { class: "hint center-text", {tr(&lang(), "no_comments")} } }
                for c in items().iter() {
                    div { key: "{c.id}", class: "comment-row",
                        img { class: "avatar sm", src: "{avatar::user_uri(&c.avatar_kind, &c.avatar_value)}", alt: "" }
                        div { class: "grow",
                            strong { "{c.name}" }
                            p { class: "comment-body", "{c.body}" }
                        }
                    }
                }
            }
            if !note().is_empty() { p { class: "note err", role: "status", "{note}" } }
            div { class: "composer",
                input { class: "plain", r#type: "text", maxlength: "500", placeholder: "{ph}", value: "{text}", oninput: move |e| text.set(e.value()) }
                button { class: "silver small", r#type: "button", disabled: busy(), onclick: send, {tr(&lang(), "send")} }
            }
        }
    }
}

#[component]
fn ShareSheet(reel_id: String, on_close: EventHandler<()>) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let mut friends = use_signal(Vec::<Contact>::new);
    let mut sent = use_signal(HashSet::<String>::new);
    let link = reel_link(&reel_id);

    use_hook(move || {
        spawn(async move {
            if let Ok(v) = call(Method::GET, "/me/contacts", None, token()).await {
                friends.set(serde_json::from_value(v).unwrap_or_default());
            }
        });
    });

    let send_link = link.clone();
    let send_to = move |peer: String| {
        let link = send_link.clone();
        spawn(async move {
            if let Some(chat) = open_chat(token(), peer.clone()).await {
                let ok = call(Method::POST, &format!("/chats/{chat}/messages"), Some(json!({ "body": link })), token()).await.is_ok();
                if ok {
                    sent.write().insert(peer);
                }
            }
        });
    };
    let out_link = link.clone();
    let copy_link = link.clone();

    rsx! {
        div { class: "sheet-back", onclick: move |_| on_close.call(()) }
        div { class: "sheet",
            h3 { class: "section-title", {tr(&lang(), "share")} }
            div { class: "share-actions",
                button { class: "chip-btn", r#type: "button", onclick: move |_| copy_or_share(&out_link, true), {tr(&lang(), "share_outside")} }
                button { class: "chip-btn", r#type: "button", onclick: move |_| copy_or_share(&copy_link, false), {tr(&lang(), "copy_link")} }
            }
            p { class: "hint", {tr(&lang(), "share_friends")} }
            div { class: "sheet-list",
                for f in friends().iter() {
                    {
                        let id = f.id.clone();
                        let done = sent().contains(&f.id);
                        let send_to = send_to.clone();
                        rsx! {
                            div { key: "{f.id}", class: "comment-row",
                                img { class: "avatar sm", src: "{avatar::user_uri(&f.avatar_kind, &f.avatar_value)}", alt: "" }
                                strong { class: "grow", "{f.name}" }
                                button { class: if done { "chip-btn on" } else { "chip-btn" }, r#type: "button", disabled: done, onclick: move |_| send_to(id.clone()),
                                    if done { "✓" } else { {tr(&lang(), "send")} }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
