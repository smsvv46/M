//! The bell: likes, comments, mentions, tags, reposts, follow requests, follows and follow backs.

use crate::{
    api::{call, Method, Notif},
    avatar,
    i18n::tr,
    login::Icon,
    social::{Overlay, ICON_BACK},
    Ctx,
};
use dioxus::prelude::*;

fn when(ts: i64) -> String {
    let now = (js_sys::Date::now() / 1000.0) as i64;
    let d = (now - ts).max(0);
    if d < 60 {
        "now".to_string()
    } else if d < 3600 {
        format!("{}m", d / 60)
    } else if d < 86_400 {
        format!("{}h", d / 3600)
    } else {
        format!("{}d", d / 86_400)
    }
}

#[component]
pub fn NotificationsScreen(mut overlay: Signal<Overlay>) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let mut unread = ctx.unread;
    let mut items = use_signal(Vec::<Notif>::new);
    let mut loading = use_signal(|| true);

    use_hook(move || {
        spawn(async move {
            if let Ok(v) = call(Method::GET, "/notifications", None, token()).await {
                items.set(serde_json::from_value(v["items"].clone()).unwrap_or_default());
            }
            loading.set(false);
            // Opening the list marks everything as seen.
            if call(Method::POST, "/notifications/read", None, token()).await.is_ok() {
                unread.set(0);
            }
        });
    });

    // Accept or decline a follow request, or follow someone back, right from the list.
    let act = move |(kind, actor, nid): (&'static str, String, i64)| {
        spawn(async move {
            let path = match kind {
                "accept" => format!("/follow-requests/{actor}/accept"),
                "decline" => format!("/follow-requests/{actor}/decline"),
                _ => format!("/users/{actor}/follow"),
            };
            if call(Method::POST, &path, None, token()).await.is_ok() {
                match kind {
                    "back" => {
                        for n in items.write().iter_mut().filter(|n| n.actor_id.as_deref() == Some(actor.as_str())) {
                            n.i_follow_actor = true;
                        }
                    }
                    _ => items.write().retain(|n| n.id != nid),
                }
            }
        });
    };

    let list = items();
    rsx! {
        header { class: "bar",
            button { class: "icon-btn", r#type: "button", "aria-label": tr(&lang(), "back"), onclick: move |_| overlay.set(Overlay::None), Icon { d: ICON_BACK } }
            h2 { class: "bar-title", {tr(&lang(), "notifications")} }
        }
        div { class: "notif-list",
            if !loading() && list.is_empty() { p { class: "hint center-text", {tr(&lang(), "no_notifications")} } }
            for n in list.iter() {
                {
                    let actor = n.actor_id.clone().unwrap_or_default();
                    let name = n.actor_name.clone().unwrap_or_default();
                    let sentence = match n.kind.as_str() {
                        "like" => tr(&lang(), "n_like"),
                        "comment" => tr(&lang(), "n_comment"),
                        "mention" => tr(&lang(), "n_mention"),
                        "tag" => tr(&lang(), "n_tag"),
                        "repost" => tr(&lang(), "n_repost"),
                        "follow_request" => tr(&lang(), "n_follow_request"),
                        "follow" => tr(&lang(), "n_follow"),
                        "follow_back" => tr(&lang(), "n_follow_back"),
                        "follow_accept" => tr(&lang(), "n_follow_accept"),
                        _ => String::new(),
                    };
                    let kind = n.kind.clone();
                    let nid = n.id;
                    let reel = n.reel_id.clone();
                    let (a1, a2, a3, a4) = (actor.clone(), actor.clone(), actor.clone(), actor.clone());
                    let pending = n.request_pending;
                    let follows_already = n.i_follow_actor;
                    let open_kind = kind.clone();
                    let av = avatar::user_uri(n.avatar_kind.as_deref().unwrap_or("preset"), n.avatar_value.as_deref().unwrap_or("0"));
                    rsx! {
                        div { key: "{n.id}", class: if n.read { "notif" } else { "notif new" },
                            button {
                                class: "notif-main", r#type: "button",
                                onclick: move |_| {
                                    match (open_kind.as_str(), reel.clone()) {
                                        ("like" | "comment" | "mention" | "tag" | "repost", Some(r)) => overlay.set(Overlay::OneReel(r)),
                                        _ => overlay.set(Overlay::Profile(a1.clone())),
                                    }
                                },
                                img { class: "avatar md", src: "{av}", alt: "" }
                                div { class: "grow",
                                    p { class: "notif-text", strong { "{name}" } " {sentence}" }
                                    if !n.text.is_empty() && (kind == "comment" || kind == "mention" || kind == "tag") {
                                        small { class: "notif-quote", "{n.text}" }
                                    }
                                }
                                small { class: "notif-time", "{when(n.ts)}" }
                            }
                            if kind == "follow_request" && pending {
                                div { class: "notif-btns",
                                    button { class: "silver small", r#type: "button", onclick: move |_| act(("accept", a2.clone(), nid)), {tr(&lang(), "accept")} }
                                    button { class: "chip-btn", r#type: "button", onclick: move |_| act(("decline", a3.clone(), nid)), {tr(&lang(), "decline")} }
                                }
                            }
                            if kind == "follow" && !follows_already {
                                div { class: "notif-btns",
                                    button { class: "silver small", r#type: "button", onclick: move |_| act(("back", a4.clone(), nid)), {tr(&lang(), "follow_back")} }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
