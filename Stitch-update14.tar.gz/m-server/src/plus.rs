//! Followers, the Trusted verification badge (celebrities, 400k followers, or paid) and LIXO coins.

use axum::{
    extract::{Path, Query, State},
    http::{HeaderMap, StatusCode},
    Json,
};
use hmac::{Hmac, Mac};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sha2::Sha512;
use sqlx::FromRow;
use std::collections::HashMap;
use uuid::Uuid;

use crate::{auth::AuthUser, error::AppError, AppState};

type Res<T> = Result<T, AppError>;

/// Followers needed for the badge to appear on its own.
pub const POPULAR_FOLLOWERS: i64 = 400_000;

/// (plan id, months, price in EGP). The server decides the price, never the app.
const PLANS: [(&str, i32, i64); 2] = [("m3", 3, 500), ("y1", 12, 1500)];

#[derive(FromRow)]
struct StatsRow {
    followers: i64,
    following: i64,
    posts: i64,
    coins: i64,
    verified_until: Option<i64>,
    manual: bool,
    paid: bool,
    i_follow: bool,
    private: bool,
    requested: bool,
}

#[derive(Serialize)]
pub struct Stats {
    followers: i64,
    following: i64,
    posts: i64,
    verified: bool,
    /// "celebrity", "popular" (400k followers) or "paid"
    verified_kind: Option<String>,
    verified_until: Option<i64>,
    coins: Option<i64>,
    i_follow: bool,
    /// True only on my own profile, when I am the owner of the app.
    owner: bool,
    /// the account is private
    private: bool,
    /// private, and I am not allowed to see it yet
    locked: bool,
    /// I asked to follow and am waiting for an answer
    requested: bool,
}

/// The owner is the account that signed in with an email or phone listed in OWNER_EMAIL / OWNER_PHONE
/// (comma separated). Those sign-ins are confirmed by a code or by Google, so nobody can fake them.
pub fn owner_lists() -> (Vec<String>, Vec<String>) {
    let list = |k: &str| -> Vec<String> {
        env(k).unwrap_or_default().split(',').map(|x| x.trim().to_lowercase()).filter(|x| !x.is_empty()).collect()
    };
    (list("OWNER_EMAIL"), list("OWNER_PHONE"))
}

pub async fn is_owner(db: &sqlx::PgPool, id: Uuid) -> Res<bool> {
    let (email, phone): (Option<String>, Option<String>) = sqlx::query_as("SELECT email, phone FROM users WHERE id = $1")
        .bind(id)
        .fetch_one(db)
        .await?;
    let (emails, phones) = owner_lists();
    Ok(email.map_or(false, |e| emails.contains(&e.to_lowercase())) || phone.map_or(false, |p| phones.contains(&p)))
}

async fn stats_for(db: &sqlx::PgPool, target: Uuid, viewer: Uuid) -> Res<Stats> {
    let r = sqlx::query_as::<_, StatsRow>(
        "SELECT
           (SELECT COUNT(*) FROM follows WHERE followee = u.id) AS followers,
           (SELECT COUNT(*) FROM follows WHERE follower = u.id) AS following,
           u.posts_count::bigint AS posts,
           u.coins AS coins,
           EXTRACT(EPOCH FROM u.verified_until)::bigint AS verified_until,
           u.verified_manual AS manual,
           COALESCE(u.verified_until > now(), FALSE) AS paid,
           EXISTS (SELECT 1 FROM follows WHERE follower = $2 AND followee = u.id) AS i_follow,
           COALESCE((SELECT account_private FROM user_settings WHERE user_id = u.id), FALSE) AS private,
           EXISTS (SELECT 1 FROM follow_requests WHERE requester = $2 AND target = u.id) AS requested
         FROM users u WHERE u.id = $1",
    )
    .bind(target)
    .bind(viewer)
    .fetch_optional(db)
    .await?
    .ok_or(AppError::NotFound)?;
    let own = target == viewer;
    let owner = own && is_owner(db, target).await?;
    let kind = if owner {
        Some("owner")
    } else if r.manual {
        Some("celebrity")
    } else if r.followers >= POPULAR_FOLLOWERS {
        Some("popular")
    } else if r.paid {
        Some("paid")
    } else {
        None
    };
    Ok(Stats {
        followers: r.followers,
        following: r.following,
        posts: r.posts,
        verified: kind.is_some(),
        verified_kind: kind.map(|k| k.to_string()),
        verified_until: if r.paid && own { r.verified_until } else { None },
        coins: if own { Some(r.coins) } else { None },
        i_follow: r.i_follow,
        owner,
        private: r.private,
        locked: r.private && !own && !r.i_follow,
        requested: r.requested,
    })
}

pub async fn my_stats(State(s): State<AppState>, AuthUser(me): AuthUser) -> Res<Json<Stats>> {
    Ok(Json(stats_for(&s.db, me, me).await?))
}

pub async fn follows(db: &sqlx::PgPool, a: Uuid, b: Uuid) -> Res<bool> {
    if a == b {
        return Ok(true);
    }
    Ok(sqlx::query_scalar("SELECT EXISTS (SELECT 1 FROM follows WHERE follower = $1 AND followee = $2)")
        .bind(a)
        .bind(b)
        .fetch_one(db)
        .await?)
}

pub async fn user_stats(State(s): State<AppState>, AuthUser(me): AuthUser, Path(id): Path<Uuid>) -> Res<Json<Stats>> {
    Ok(Json(stats_for(&s.db, id, me).await?))
}

/// Makes `from` follow `to` and tells `to`. "follow_back" when `to` already followed `from`.
async fn do_follow(db: &sqlx::PgPool, from: Uuid, to: Uuid) -> Res<()> {
    let added = sqlx::query("INSERT INTO follows (follower, followee) VALUES ($1, $2) ON CONFLICT DO NOTHING")
        .bind(from)
        .bind(to)
        .execute(db)
        .await?
        .rows_affected();
    sqlx::query("DELETE FROM follow_requests WHERE requester = $1 AND target = $2")
        .bind(from)
        .bind(to)
        .execute(db)
        .await?;
    if added > 0 {
        let back = follows(db, to, from).await?;
        crate::reels::push(db, to, if back { "follow_back" } else { "follow" }, from, None, "").await;
    }
    Ok(())
}

pub async fn follow(State(s): State<AppState>, AuthUser(me): AuthUser, Path(id): Path<Uuid>) -> Res<Json<Stats>> {
    if me == id {
        return Err(AppError::NotFound);
    }
    let private: bool = sqlx::query_scalar("SELECT account_private FROM user_settings WHERE user_id = $1")
        .bind(id)
        .fetch_optional(&s.db)
        .await?
        .ok_or(AppError::NotFound)?;
    if private {
        if !follows(&s.db, me, id).await? {
            let added = sqlx::query("INSERT INTO follow_requests (requester, target) VALUES ($1, $2) ON CONFLICT DO NOTHING")
                .bind(me)
                .bind(id)
                .execute(&s.db)
                .await?
                .rows_affected();
            if added > 0 {
                crate::reels::push(&s.db, id, "follow_request", me, None, "").await;
            }
        }
    } else {
        do_follow(&s.db, me, id).await?;
    }
    Ok(Json(stats_for(&s.db, id, me).await?))
}

/// Unfollow, or cancel a request that is still waiting.
pub async fn unfollow(State(s): State<AppState>, AuthUser(me): AuthUser, Path(id): Path<Uuid>) -> Res<Json<Stats>> {
    sqlx::query("DELETE FROM follows WHERE follower = $1 AND followee = $2")
        .bind(me)
        .bind(id)
        .execute(&s.db)
        .await?;
    sqlx::query("DELETE FROM follow_requests WHERE requester = $1 AND target = $2")
        .bind(me)
        .bind(id)
        .execute(&s.db)
        .await?;
    sqlx::query("DELETE FROM notifications WHERE user_id = $2 AND actor_id = $1 AND kind = 'follow_request'")
        .bind(me)
        .bind(id)
        .execute(&s.db)
        .await?;
    Ok(Json(stats_for(&s.db, id, me).await?))
}

/// I accept `requester`'s request: they now follow me.
pub async fn accept_request(State(s): State<AppState>, AuthUser(me): AuthUser, Path(requester): Path<Uuid>) -> Res<StatusCode> {
    let had = sqlx::query("DELETE FROM follow_requests WHERE requester = $1 AND target = $2")
        .bind(requester)
        .bind(me)
        .execute(&s.db)
        .await?
        .rows_affected();
    if had > 0 {
        sqlx::query("INSERT INTO follows (follower, followee) VALUES ($1, $2) ON CONFLICT DO NOTHING")
            .bind(requester)
            .bind(me)
            .execute(&s.db)
            .await?;
        crate::reels::push(&s.db, requester, "follow_accept", me, None, "").await;
        // The same person now follows me, so tell me too (with a follow-back button) like a normal follow.
        let back = follows(&s.db, me, requester).await?;
        crate::reels::push(&s.db, me, if back { "follow_back" } else { "follow" }, requester, None, "").await;
    }
    sqlx::query("DELETE FROM notifications WHERE user_id = $1 AND actor_id = $2 AND kind = 'follow_request'")
        .bind(me)
        .bind(requester)
        .execute(&s.db)
        .await?;
    Ok(StatusCode::NO_CONTENT)
}

pub async fn decline_request(State(s): State<AppState>, AuthUser(me): AuthUser, Path(requester): Path<Uuid>) -> Res<StatusCode> {
    sqlx::query("DELETE FROM follow_requests WHERE requester = $1 AND target = $2")
        .bind(requester)
        .bind(me)
        .execute(&s.db)
        .await?;
    sqlx::query("DELETE FROM notifications WHERE user_id = $1 AND actor_id = $2 AND kind = 'follow_request'")
        .bind(me)
        .bind(requester)
        .execute(&s.db)
        .await?;
    Ok(StatusCode::NO_CONTENT)
}

/// When an account becomes public, everyone waiting becomes a follower.
pub async fn accept_all_requests(db: &sqlx::PgPool, me: Uuid) -> Res<()> {
    let waiting: Vec<Uuid> = sqlx::query_scalar("DELETE FROM follow_requests WHERE target = $1 RETURNING requester")
        .bind(me)
        .fetch_all(db)
        .await?;
    for r in waiting {
        sqlx::query("INSERT INTO follows (follower, followee) VALUES ($1, $2) ON CONFLICT DO NOTHING")
            .bind(r)
            .bind(me)
            .execute(db)
            .await?;
        crate::reels::push(db, r, "follow_accept", me, None, "").await;
    }
    sqlx::query("DELETE FROM notifications WHERE user_id = $1 AND kind = 'follow_request'")
        .bind(me)
        .execute(db)
        .await?;
    Ok(())
}

// ---------------------------------------------------------------- admin: celebrities

#[derive(Deserialize)]
pub struct AdminVerify {
    username: String,
    on: bool,
}

/// Gives or removes the badge for a celebrity. Needs the header `x-admin-key: <ADMIN_KEY>`.
pub async fn admin_verify(State(s): State<AppState>, headers: HeaderMap, Json(b): Json<AdminVerify>) -> Res<Json<Value>> {
    let key = std::env::var("ADMIN_KEY").ok().filter(|k| k.len() >= 16);
    let given = headers.get("x-admin-key").and_then(|v| v.to_str().ok()).unwrap_or("");
    match key {
        Some(k) if k == given => {}
        _ => return Err(AppError::Forbidden("forbidden")),
    }
    let n = sqlx::query("UPDATE users SET verified_manual = $2 WHERE lower(username) = $1")
        .bind(b.username.trim().trim_start_matches('@').to_lowercase())
        .bind(b.on)
        .execute(&s.db)
        .await?
        .rows_affected();
    if n == 0 {
        return Err(AppError::NotFound);
    }
    Ok(Json(json!({ "ok": true })))
}

// ---------------------------------------------------------------- paying for the badge (Paymob: Visa / Mastercard / bank cards in Egypt)

fn env(k: &str) -> Option<String> {
    std::env::var(k).ok().filter(|v| !v.is_empty())
}

async fn post_json(http: &reqwest::Client, url: &str, body: Value) -> Res<Value> {
    let res = http.post(url).json(&body).send().await.map_err(|e| {
        tracing::error!("paymob request failed: {e}");
        AppError::BadRequest("payment_failed")
    })?;
    if !res.status().is_success() {
        tracing::error!("paymob answered {} for {url}", res.status());
        return Err(AppError::BadRequest("payment_failed"));
    }
    res.json::<Value>().await.map_err(|_| AppError::BadRequest("payment_failed"))
}

#[derive(Deserialize)]
pub struct Checkout {
    plan: String,
}

/// Starts a payment: returns the secure card page address. The badge is only given after the bank confirms.
pub async fn checkout(State(s): State<AppState>, AuthUser(me): AuthUser, Json(b): Json<Checkout>) -> Res<Json<Value>> {
    let (plan, _months, egp) = PLANS.iter().find(|p| p.0 == b.plan).copied().ok_or(AppError::BadRequest("invalid_plan"))?;
    let (Some(api_key), Some(integration), Some(iframe)) =
        (env("PAYMOB_API_KEY"), env("PAYMOB_INTEGRATION_ID"), env("PAYMOB_IFRAME_ID"))
    else {
        return Err(AppError::BadRequest("payments_not_configured"));
    };
    let integration: i64 = integration.parse().map_err(|_| AppError::BadRequest("payments_not_configured"))?;
    let amount_cents = egp * 100;
    let pay_id = Uuid::new_v4();

    let (email, name): (Option<String>, String) = sqlx::query_as("SELECT email, name FROM users WHERE id = $1")
        .bind(me)
        .fetch_one(&s.db)
        .await?;

    let auth = post_json(&s.http, "https://accept.paymob.com/api/auth/tokens", json!({ "api_key": api_key })).await?;
    let auth_token = auth["token"].as_str().ok_or(AppError::BadRequest("payment_failed"))?.to_string();
    let order = post_json(
        &s.http,
        "https://accept.paymob.com/api/ecommerce/orders",
        json!({
            "auth_token": auth_token, "delivery_needed": false, "amount_cents": amount_cents,
            "currency": "EGP", "merchant_order_id": pay_id.to_string(), "items": [],
        }),
    )
    .await?;
    let order_id = order["id"].as_i64().ok_or(AppError::BadRequest("payment_failed"))?;
    let key = post_json(
        &s.http,
        "https://accept.paymob.com/api/acceptance/payment_keys",
        json!({
            "auth_token": auth_token, "amount_cents": amount_cents, "expiration": 3600, "order_id": order_id,
            "currency": "EGP", "integration_id": integration,
            "billing_data": {
                "apartment": "NA", "email": email.unwrap_or_else(|| "noreply@stitch.app".to_string()), "floor": "NA",
                "first_name": name, "street": "NA", "building": "NA", "phone_number": "+201000000000",
                "shipping_method": "NA", "postal_code": "NA", "city": "NA", "country": "EG", "last_name": "NA", "state": "NA",
            },
        }),
    )
    .await?;
    let pay_token = key["token"].as_str().ok_or(AppError::BadRequest("payment_failed"))?;

    sqlx::query("INSERT INTO payments (id, user_id, plan, amount_cents, provider_order) VALUES ($1, $2, $3, $4, $5)")
        .bind(pay_id)
        .bind(me)
        .bind(plan)
        .bind(amount_cents)
        .bind(order_id)
        .execute(&s.db)
        .await?;

    Ok(Json(json!({
        "url": format!("https://accept.paymob.com/api/acceptance/iframes/{iframe}?payment_token={pay_token}")
    })))
}

/// Reads "a.b.c" from the transaction the way Paymob builds its signature: text, numbers and true/false.
fn sig_field(v: &Value, path: &str) -> String {
    let mut cur = v;
    for part in path.split('.') {
        cur = &cur[part];
    }
    match cur {
        Value::String(x) => x.clone(),
        Value::Bool(x) => x.to_string(),
        Value::Number(x) => x.to_string(),
        _ => String::new(),
    }
}

const SIG_FIELDS: [&str; 20] = [
    "amount_cents", "created_at", "currency", "error_occured", "has_parent_transaction", "id", "integration_id",
    "is_3d_secure", "is_auth", "is_capture", "is_refunded", "is_standalone_payment", "is_voided", "order.id", "owner",
    "pending", "source_data.pan", "source_data.sub_type", "source_data.type", "success",
];

/// Paymob calls this after every payment. We check its signature, then check that the money really arrived
/// (success, not pending, not voided or refunded, same amount) before giving the badge.
pub async fn paymob_callback(
    State(s): State<AppState>,
    Query(q): Query<HashMap<String, String>>,
    Json(body): Json<Value>,
) -> Res<StatusCode> {
    let secret = env("PAYMOB_HMAC").ok_or(AppError::Forbidden("forbidden"))?;
    let given = q.get("hmac").and_then(|h| hex::decode(h).ok()).ok_or(AppError::Forbidden("forbidden"))?;
    let obj = &body["obj"];
    let text: String = SIG_FIELDS.iter().map(|f| sig_field(obj, f)).collect();
    let mut mac = Hmac::<Sha512>::new_from_slice(secret.as_bytes()).map_err(|_| AppError::Internal)?;
    mac.update(text.as_bytes());
    mac.verify_slice(&given).map_err(|_| AppError::Forbidden("forbidden"))?;

    let paid = obj["success"].as_bool() == Some(true)
        && obj["pending"].as_bool() == Some(false)
        && obj["is_voided"].as_bool() != Some(true)
        && obj["is_refunded"].as_bool() != Some(true);
    if !paid {
        return Ok(StatusCode::OK);
    }
    let order_id = obj["order"]["id"].as_i64().ok_or(AppError::BadRequest("bad_callback"))?;
    let amount = obj["amount_cents"].as_i64().unwrap_or(-1);
    let txn = obj["id"].as_i64();

    let mut tx = s.db.begin().await?;
    // Only a pending payment with exactly the expected amount can be completed, and only once.
    let row: Option<(Uuid, String)> = sqlx::query_as(
        "UPDATE payments SET status = 'paid', paid_at = now(), provider_txn = $3
         WHERE provider_order = $1 AND status = 'pending' AND amount_cents = $2
         RETURNING user_id, plan",
    )
    .bind(order_id)
    .bind(amount)
    .bind(txn)
    .fetch_optional(&mut *tx)
    .await?;
    if let Some((user_id, plan)) = row {
        if let Some((_, months, _)) = PLANS.iter().find(|p| p.0 == plan) {
            sqlx::query(
                "UPDATE users SET verified_until = GREATEST(COALESCE(verified_until, now()), now()) + ($2::int * interval '1 month')
                 WHERE id = $1",
            )
            .bind(user_id)
            .bind(*months)
            .execute(&mut *tx)
            .await?;
        }
    }
    tx.commit().await?;
    Ok(StatusCode::OK)
}

// ---------------------------------------------------------------- owner: everything free, and gifts for others

#[derive(Deserialize)]
pub struct Grant {
    username: String,
    /// true = give the badge, false = take it away, missing = leave as is
    verified: Option<bool>,
    /// with verified = true: badge for this many days instead of forever
    verified_days: Option<i32>,
    /// coins to add (negative to remove)
    coins: Option<i64>,
}

/// Only the owner can use this. Gives a person the Trusted badge and/or LIXO coins for free.
pub async fn owner_grant(State(s): State<AppState>, AuthUser(me): AuthUser, Json(b): Json<Grant>) -> Res<Json<Value>> {
    if !is_owner(&s.db, me).await? {
        return Err(AppError::Forbidden("forbidden"));
    }
    let target: Uuid = sqlx::query_scalar("SELECT id FROM users WHERE lower(username) = $1")
        .bind(b.username.trim().trim_start_matches('@').to_lowercase())
        .fetch_optional(&s.db)
        .await?
        .ok_or(AppError::NotFound)?;
    if let Some(on) = b.verified {
        if !on {
            sqlx::query("UPDATE users SET verified_manual = FALSE, verified_until = NULL WHERE id = $1")
                .bind(target)
                .execute(&s.db)
                .await?;
        } else if let Some(days) = b.verified_days.filter(|d| (1..=36500).contains(d)) {
            sqlx::query(
                "UPDATE users SET verified_until = GREATEST(COALESCE(verified_until, now()), now()) + ($2::int * interval '1 day')
                 WHERE id = $1",
            )
            .bind(target)
            .bind(days)
            .execute(&s.db)
            .await?;
        } else {
            sqlx::query("UPDATE users SET verified_manual = TRUE WHERE id = $1")
                .bind(target)
                .execute(&s.db)
                .await?;
        }
    }
    if let Some(c) = b.coins {
        if c.abs() > 1_000_000_000 {
            return Err(AppError::BadRequest("invalid_amount"));
        }
        sqlx::query("UPDATE users SET coins = GREATEST(0, coins + $2) WHERE id = $1")
            .bind(target)
            .bind(c)
            .execute(&s.db)
            .await?;
    }
    let name: String = sqlx::query_scalar("SELECT name FROM users WHERE id = $1").bind(target).fetch_one(&s.db).await?;
    let st = stats_for(&s.db, target, me).await?;
    Ok(Json(json!({ "name": name, "verified": st.verified })))
}
