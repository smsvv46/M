//! Reels (short videos everyone can watch), likes, comments, reposts, and the notification list.

use axum::{
    body::Bytes,
    extract::{Path, Query, State},
    http::HeaderMap,
    Json,
};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sqlx::FromRow;
use uuid::Uuid;

use crate::{
    auth::AuthUser,
    error::AppError,
    plus::owner_lists,
    routes::{remove_file, store_file, upload_ext},
    AppState,
};

type Res<T> = Result<T, AppError>;

// ---------------------------------------------------------------- notifications

/// Adds a notification for `to` (never for yourself). Errors are ignored: a missed bell must not break an action.
pub async fn push(db: &sqlx::PgPool, to: Uuid, kind: &str, actor: Uuid, reel: Option<Uuid>, text: &str) {
    if to == actor {
        return;
    }
    let r = sqlx::query("INSERT INTO notifications (user_id, kind, actor_id, reel_id, text) VALUES ($1, $2, $3, $4, $5)")
        .bind(to)
        .bind(kind)
        .bind(actor)
        .bind(reel)
        .bind(text.chars().take(120).collect::<String>())
        .execute(db)
        .await;
    if let Err(e) = r {
        tracing::warn!("notification not saved: {e}");
    }
}

/// "@name" words in a text, lower-case, at most 10.
fn mentions(text: &str) -> Vec<String> {
    let mut out: Vec<String> = Vec::new();
    for w in text.split_whitespace() {
        if let Some(rest) = w.strip_prefix('@') {
            let n: String = rest
                .chars()
                .take_while(|c| c.is_ascii_alphanumeric() || *c == '_' || *c == '.')
                .collect::<String>()
                .trim_end_matches('.')
                .to_lowercase();
            if n.len() >= 3 && !out.contains(&n) {
                out.push(n);
            }
        }
    }
    out.truncate(10);
    out
}

async fn notify_mentions(db: &sqlx::PgPool, actor: Uuid, reel: Uuid, kind: &str, text: &str, skip: Option<Uuid>) {
    for n in mentions(text) {
        let found: Result<Option<Uuid>, _> = sqlx::query_scalar("SELECT id FROM users WHERE lower(username) = $1")
            .bind(&n)
            .fetch_optional(db)
            .await;
        if let Ok(Some(id)) = found {
            if Some(id) != skip {
                push(db, id, kind, actor, Some(reel), text).await;
            }
        }
    }
}

#[derive(Serialize, FromRow)]
struct NotifOut {
    id: i64,
    kind: String,
    actor_id: Option<Uuid>,
    actor_name: Option<String>,
    avatar_kind: Option<String>,
    avatar_value: Option<String>,
    reel_id: Option<Uuid>,
    text: String,
    read: bool,
    ts: i64,
    i_follow_actor: bool,
    request_pending: bool,
}

pub async fn list_notifications(State(s): State<AppState>, AuthUser(me): AuthUser) -> Res<Json<Value>> {
    let items = sqlx::query_as::<_, NotifOut>(
        "SELECT n.id, n.kind, n.actor_id, u.name AS actor_name,
                CASE WHEN st.photo_vis = 'nobody' THEN 'preset' ELSE u.avatar_kind END AS avatar_kind,
                CASE WHEN st.photo_vis = 'nobody' THEN '0' ELSE u.avatar_value END AS avatar_value,
                n.reel_id, n.text, n.read, EXTRACT(EPOCH FROM n.created_at)::bigint AS ts,
                EXISTS (SELECT 1 FROM follows f WHERE f.follower = $1 AND f.followee = n.actor_id) AS i_follow_actor,
                EXISTS (SELECT 1 FROM follow_requests q WHERE q.requester = n.actor_id AND q.target = $1) AS request_pending
         FROM notifications n
         LEFT JOIN users u ON u.id = n.actor_id
         LEFT JOIN user_settings st ON st.user_id = u.id
         WHERE n.user_id = $1
         ORDER BY n.id DESC LIMIT 80",
    )
    .bind(me)
    .fetch_all(&s.db)
    .await?;
    let unread = items.iter().filter(|n| !n.read).count();
    Ok(Json(json!({ "unread": unread, "items": items })))
}

pub async fn notification_count(State(s): State<AppState>, AuthUser(me): AuthUser) -> Res<Json<Value>> {
    let n: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM notifications WHERE user_id = $1 AND NOT read")
        .bind(me)
        .fetch_one(&s.db)
        .await?;
    Ok(Json(json!({ "unread": n })))
}

pub async fn mark_notifications_read(State(s): State<AppState>, AuthUser(me): AuthUser) -> Res<Json<Value>> {
    sqlx::query("UPDATE notifications SET read = TRUE WHERE user_id = $1 AND NOT read")
        .bind(me)
        .execute(&s.db)
        .await?;
    Ok(Json(json!({ "ok": true })))
}

// ---------------------------------------------------------------- reading reels

#[derive(Serialize, FromRow)]
pub struct ReelOut {
    id: Uuid,
    user_id: Uuid,
    name: String,
    avatar_kind: String,
    avatar_value: String,
    media_url: String,
    caption: String,
    repost_name: String,
    ts: i64,
    cur: i64,
    likes: i64,
    comments: i64,
    reposts: i64,
    liked: bool,
    i_follow: bool,
    requested: bool,
    verified: bool,
    private: bool,
}

/// A reel can be seen when its owner is public, when it is mine, or when I follow the (private) owner.
const VISIBLE: &str = "(r.user_id = $1 OR NOT s.account_private
                        OR EXISTS (SELECT 1 FROM follows f WHERE f.follower = $1 AND f.followee = r.user_id))";

async fn fetch_reels(
    db: &sqlx::PgPool,
    me: Uuid,
    before: Option<i64>,
    user: Option<Uuid>,
    following_only: bool,
    one: Option<Uuid>,
) -> Res<Vec<ReelOut>> {
    let (emails, phones) = owner_lists();
    let sql = format!(
        "SELECT r.id, r.user_id, u.name,
                CASE WHEN s.photo_vis = 'nobody' AND r.user_id <> $1 THEN 'preset' ELSE u.avatar_kind END AS avatar_kind,
                CASE WHEN s.photo_vis = 'nobody' AND r.user_id <> $1 THEN '0' ELSE u.avatar_value END AS avatar_value,
                r.media_url, r.caption, r.repost_name,
                EXTRACT(EPOCH FROM r.created_at)::bigint AS ts,
                (EXTRACT(EPOCH FROM r.created_at) * 1000000)::bigint AS cur,
                (SELECT COUNT(*) FROM reel_likes l WHERE l.reel_id = r.id) AS likes,
                (SELECT COUNT(*) FROM reel_comments c WHERE c.reel_id = r.id) AS comments,
                (SELECT COUNT(*) FROM reels x WHERE x.repost_of = r.id) AS reposts,
                EXISTS (SELECT 1 FROM reel_likes l WHERE l.reel_id = r.id AND l.user_id = $1) AS liked,
                EXISTS (SELECT 1 FROM follows f WHERE f.follower = $1 AND f.followee = r.user_id) AS i_follow,
                EXISTS (SELECT 1 FROM follow_requests q WHERE q.requester = $1 AND q.target = r.user_id) AS requested,
                COALESCE(u.verified_manual
                         OR COALESCE(u.verified_until > now(), FALSE)
                         OR (SELECT COUNT(*) FROM follows WHERE followee = u.id) >= 400000
                         OR u.email = ANY($2) OR u.phone = ANY($3), FALSE) AS verified,
                s.account_private AS private
         FROM reels r
         JOIN users u ON u.id = r.user_id
         JOIN user_settings s ON s.user_id = u.id
         WHERE {VISIBLE}
           AND ($4::bigint IS NULL OR r.created_at < to_timestamp($4::double precision / 1000000))
           AND ($5::uuid IS NULL OR r.user_id = $5)
           AND (NOT $6 OR EXISTS (SELECT 1 FROM follows f WHERE f.follower = $1 AND f.followee = r.user_id))
           AND ($7::uuid IS NULL OR r.id = $7)
         ORDER BY r.created_at DESC
         LIMIT 20"
    );
    Ok(sqlx::query_as::<_, ReelOut>(&sql)
        .bind(me)
        .bind(&emails)
        .bind(&phones)
        .bind(before)
        .bind(user)
        .bind(following_only)
        .bind(one)
        .fetch_all(db)
        .await?)
}

#[derive(Deserialize)]
pub struct FeedQuery {
    before: Option<i64>,
    user: Option<Uuid>,
    following: Option<bool>,
}

pub async fn feed(State(s): State<AppState>, AuthUser(me): AuthUser, Query(q): Query<FeedQuery>) -> Res<Json<Vec<ReelOut>>> {
    Ok(Json(fetch_reels(&s.db, me, q.before, q.user, q.following.unwrap_or(false), None).await?))
}

pub async fn get_reel(State(s): State<AppState>, AuthUser(me): AuthUser, Path(id): Path<Uuid>) -> Res<Json<ReelOut>> {
    let mut v = fetch_reels(&s.db, me, None, None, false, Some(id)).await?;
    Ok(Json(v.pop().ok_or(AppError::NotFound)?))
}

/// (owner id, owner is private) of a reel I am allowed to see.
async fn visible_owner(db: &sqlx::PgPool, me: Uuid, reel: Uuid) -> Res<(Uuid, bool)> {
    let row: Option<(Uuid, bool)> = sqlx::query_as(
        "SELECT r.user_id, s.account_private FROM reels r JOIN user_settings s ON s.user_id = r.user_id
         WHERE r.id = $1 AND (r.user_id = $2 OR NOT s.account_private
                              OR EXISTS (SELECT 1 FROM follows f WHERE f.follower = $2 AND f.followee = r.user_id))",
    )
    .bind(reel)
    .bind(me)
    .fetch_optional(db)
    .await?;
    row.ok_or(AppError::NotFound)
}

// ---------------------------------------------------------------- posting

#[derive(Deserialize)]
pub struct CaptionQuery {
    caption: Option<String>,
}

/// A new reel: the video file is the request body; the caption goes in the query string.
pub async fn create(
    State(s): State<AppState>,
    AuthUser(me): AuthUser,
    headers: HeaderMap,
    Query(q): Query<CaptionQuery>,
    body: Bytes,
) -> Res<Json<Value>> {
    let ext = upload_ext(&headers, true)?;
    if ext != "mp4" && ext != "webm" {
        return Err(AppError::BadRequest("unsupported_file"));
    }
    if body.is_empty() {
        return Err(AppError::BadRequest("empty_file"));
    }
    if body.len() > 50_000_000 {
        return Err(AppError::BadRequest("file_too_large"));
    }
    let caption = q.caption.unwrap_or_default().trim().to_string();
    if caption.chars().count() > 300 {
        return Err(AppError::BadRequest("caption_too_long"));
    }
    let url = store_file(&s, ext, &body).await?;
    let id = Uuid::new_v4();
    sqlx::query("INSERT INTO reels (id, user_id, media_url, caption) VALUES ($1, $2, $3, $4)")
        .bind(id)
        .bind(me)
        .bind(&url)
        .bind(&caption)
        .execute(&s.db)
        .await?;
    notify_mentions(&s.db, me, id, "tag", &caption, None).await;
    Ok(Json(json!({ "id": id })))
}

pub async fn delete(State(s): State<AppState>, AuthUser(me): AuthUser, Path(id): Path<Uuid>) -> Res<Json<Value>> {
    let url: Option<String> = sqlx::query_scalar("DELETE FROM reels WHERE id = $1 AND user_id = $2 RETURNING media_url")
        .bind(id)
        .bind(me)
        .fetch_optional(&s.db)
        .await?;
    let url = url.ok_or(AppError::NotFound)?;
    // A repost shares the file, so it is only removed when nobody uses it any more.
    let left: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM reels WHERE media_url = $1")
        .bind(&url)
        .fetch_one(&s.db)
        .await?;
    if left == 0 {
        remove_file(&s, &url).await;
    }
    Ok(Json(json!({ "ok": true })))
}

// ---------------------------------------------------------------- likes, comments, reposts

pub async fn like(State(s): State<AppState>, AuthUser(me): AuthUser, Path(id): Path<Uuid>) -> Res<Json<Value>> {
    let (owner, _) = visible_owner(&s.db, me, id).await?;
    let added = sqlx::query("INSERT INTO reel_likes (reel_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING")
        .bind(id)
        .bind(me)
        .execute(&s.db)
        .await?
        .rows_affected();
    if added > 0 {
        push(&s.db, owner, "like", me, Some(id), "").await;
    }
    like_state(&s.db, id, true).await
}

pub async fn unlike(State(s): State<AppState>, AuthUser(me): AuthUser, Path(id): Path<Uuid>) -> Res<Json<Value>> {
    visible_owner(&s.db, me, id).await?;
    sqlx::query("DELETE FROM reel_likes WHERE reel_id = $1 AND user_id = $2")
        .bind(id)
        .bind(me)
        .execute(&s.db)
        .await?;
    like_state(&s.db, id, false).await
}

async fn like_state(db: &sqlx::PgPool, id: Uuid, liked: bool) -> Res<Json<Value>> {
    let n: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM reel_likes WHERE reel_id = $1")
        .bind(id)
        .fetch_one(db)
        .await?;
    Ok(Json(json!({ "likes": n, "liked": liked })))
}

#[derive(Serialize, FromRow)]
struct CommentOut {
    id: i64,
    user_id: Uuid,
    name: String,
    avatar_kind: String,
    avatar_value: String,
    body: String,
    ts: i64,
}

pub async fn comments(State(s): State<AppState>, AuthUser(me): AuthUser, Path(id): Path<Uuid>) -> Res<Json<Vec<CommentOut>>> {
    visible_owner(&s.db, me, id).await?;
    let rows = sqlx::query_as::<_, CommentOut>(
        "SELECT c.id, c.user_id, u.name,
                CASE WHEN st.photo_vis = 'nobody' AND c.user_id <> $2 THEN 'preset' ELSE u.avatar_kind END AS avatar_kind,
                CASE WHEN st.photo_vis = 'nobody' AND c.user_id <> $2 THEN '0' ELSE u.avatar_value END AS avatar_value,
                c.body, EXTRACT(EPOCH FROM c.created_at)::bigint AS ts
         FROM reel_comments c
         JOIN users u ON u.id = c.user_id
         JOIN user_settings st ON st.user_id = u.id
         WHERE c.reel_id = $1
         ORDER BY c.id DESC LIMIT 100",
    )
    .bind(id)
    .bind(me)
    .fetch_all(&s.db)
    .await?;
    Ok(Json(rows))
}

#[derive(Deserialize)]
pub struct NewComment {
    body: String,
}

pub async fn add_comment(
    State(s): State<AppState>,
    AuthUser(me): AuthUser,
    Path(id): Path<Uuid>,
    Json(b): Json<NewComment>,
) -> Res<Json<Value>> {
    let (owner, _) = visible_owner(&s.db, me, id).await?;
    let body = b.body.trim().to_string();
    if body.is_empty() || body.chars().count() > 500 {
        return Err(AppError::BadRequest("invalid_comment"));
    }
    sqlx::query("INSERT INTO reel_comments (reel_id, user_id, body) VALUES ($1, $2, $3)")
        .bind(id)
        .bind(me)
        .bind(&body)
        .execute(&s.db)
        .await?;
    push(&s.db, owner, "comment", me, Some(id), &body).await;
    // Mentioned people get their own "mention" (the reel owner already got the comment notice).
    notify_mentions(&s.db, me, id, "mention", &body, Some(owner)).await;
    Ok(Json(json!({ "ok": true })))
}

/// Puts someone else's reel on my profile ("reposted from ...").
pub async fn repost(State(s): State<AppState>, AuthUser(me): AuthUser, Path(id): Path<Uuid>) -> Res<Json<Value>> {
    let (owner, private) = visible_owner(&s.db, me, id).await?;
    if owner == me {
        return Err(AppError::BadRequest("cannot_repost_own"));
    }
    if private {
        return Err(AppError::Forbidden("private_account"));
    }
    let (media, caption, root, from_name): (String, String, Uuid, String) = sqlx::query_as(
        "SELECT r.media_url, r.caption, COALESCE(r.repost_of, r.id),
                CASE WHEN r.repost_name <> '' THEN r.repost_name ELSE u.name END
         FROM reels r JOIN users u ON u.id = r.user_id WHERE r.id = $1",
    )
    .bind(id)
    .fetch_one(&s.db)
    .await?;
    let already: bool = sqlx::query_scalar("SELECT EXISTS (SELECT 1 FROM reels WHERE user_id = $1 AND repost_of = $2)")
        .bind(me)
        .bind(root)
        .fetch_one(&s.db)
        .await?;
    if already {
        return Err(AppError::BadRequest("already_reposted"));
    }
    let new_id = Uuid::new_v4();
    sqlx::query("INSERT INTO reels (id, user_id, media_url, caption, repost_of, repost_name) VALUES ($1, $2, $3, $4, $5, $6)")
        .bind(new_id)
        .bind(me)
        .bind(&media)
        .bind(&caption)
        .bind(root)
        .bind(&from_name)
        .execute(&s.db)
        .await?;
    push(&s.db, owner, "repost", me, Some(id), "").await;
    Ok(Json(json!({ "id": new_id })))
}
