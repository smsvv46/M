use axum::{
    extract::{Path, Query, State},
    http::StatusCode,
    Json,
};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sqlx::FromRow;
use uuid::Uuid;

use crate::{auth::AuthUser, error::AppError, AppState};

type Res<T> = Result<T, AppError>;

async fn require_member(db: &sqlx::PgPool, conv: Uuid, me: Uuid) -> Res<()> {
    let ok: bool = sqlx::query_scalar(
        "SELECT EXISTS (SELECT 1 FROM conversation_members WHERE conversation_id = $1 AND user_id = $2)",
    )
    .bind(conv)
    .bind(me)
    .fetch_one(db)
    .await?;
    if ok {
        Ok(())
    } else {
        Err(AppError::NotFound)
    }
}

async fn touch_active(db: &sqlx::PgPool, me: Uuid) {
    let _ = sqlx::query("UPDATE users SET last_active_at = now() WHERE id = $1")
        .bind(me)
        .execute(db)
        .await;
}

// ---------- start or find a conversation ----------

#[derive(Deserialize)]
pub struct OpenChat {
    user_id: Uuid,
}

/// Returns the one-to-one conversation with a connected person, creating it on first use.
pub async fn open_chat(State(s): State<AppState>, AuthUser(me): AuthUser, Json(b): Json<OpenChat>) -> Res<Json<Value>> {
    if b.user_id == me {
        return Err(AppError::BadRequest("cannot_chat_self"));
    }
    let linked: bool = sqlx::query_scalar(
        "SELECT EXISTS (SELECT 1 FROM contacts
                        WHERE (user_id = $1 AND contact_id = $2) OR (user_id = $2 AND contact_id = $1))",
    )
    .bind(me)
    .bind(b.user_id)
    .fetch_one(&s.db)
    .await?;
    if !linked {
        return Err(AppError::NotFound);
    }

    let existing: Option<Uuid> = sqlx::query_scalar(
        "SELECT c.id FROM conversations c
         JOIN conversation_members a ON a.conversation_id = c.id AND a.user_id = $1
         JOIN conversation_members b ON b.conversation_id = c.id AND b.user_id = $2
         WHERE c.kind = 'direct' LIMIT 1",
    )
    .bind(me)
    .bind(b.user_id)
    .fetch_optional(&s.db)
    .await?;

    let id = match existing {
        Some(id) => id,
        None => {
            let id = Uuid::new_v4();
            let mut tx = s.db.begin().await?;
            sqlx::query("INSERT INTO conversations (id, kind) VALUES ($1, 'direct')")
                .bind(id)
                .execute(&mut *tx)
                .await?;
            sqlx::query("INSERT INTO conversation_members (conversation_id, user_id) VALUES ($1, $2), ($1, $3)")
                .bind(id)
                .bind(me)
                .bind(b.user_id)
                .execute(&mut *tx)
                .await?;
            tx.commit().await?;
            id
        }
    };
    Ok(Json(json!({ "id": id })))
}

// ---------- the chat list ----------

#[derive(Serialize, FromRow)]
pub struct ChatItem {
    id: Uuid,
    peer_id: Uuid,
    name: String,
    avatar_kind: String,
    avatar_value: String,
    last_body: Option<String>,
    last_ts: Option<i64>,
    unread: i64,
}

/// Conversations that have at least one message, newest first.
pub async fn list_chats(State(s): State<AppState>, AuthUser(me): AuthUser) -> Res<Json<Vec<ChatItem>>> {
    touch_active(&s.db, me).await;
    let rows = sqlx::query_as::<_, ChatItem>(
        "SELECT c.id, u.id AS peer_id, u.name,
                CASE WHEN s.photo_vis = 'nobody' THEN 'preset' ELSE u.avatar_kind END AS avatar_kind,
                CASE WHEN s.photo_vis = 'nobody' THEN '0' ELSE u.avatar_value END AS avatar_value,
                lm.body AS last_body,
                EXTRACT(EPOCH FROM lm.created_at)::bigint AS last_ts,
                (SELECT COUNT(*) FROM messages m
                  WHERE m.conversation_id = c.id AND m.sender_id <> $1 AND m.id > mine.last_read_message_id) AS unread
         FROM conversations c
         JOIN conversation_members mine ON mine.conversation_id = c.id AND mine.user_id = $1
         JOIN conversation_members pm ON pm.conversation_id = c.id AND pm.user_id <> $1
         JOIN users u ON u.id = pm.user_id
         JOIN user_settings s ON s.user_id = u.id
         JOIN LATERAL (SELECT body, created_at FROM messages WHERE conversation_id = c.id ORDER BY id DESC LIMIT 1) lm ON TRUE
         WHERE c.kind = 'direct'
         ORDER BY lm.created_at DESC",
    )
    .bind(me)
    .fetch_all(&s.db)
    .await?;
    Ok(Json(rows))
}

// ---------- one conversation ----------

#[derive(Deserialize)]
pub struct After {
    after: Option<i64>,
}

#[derive(Serialize, FromRow)]
pub struct Msg {
    id: i64,
    sender_id: Uuid,
    body: String,
    ts: i64,
}

#[derive(Serialize, FromRow)]
pub struct Peer {
    id: Uuid,
    name: String,
    avatar_kind: String,
    avatar_value: String,
    online: bool,
    /// When the person was last active, unless they hide it (then null).
    last_seen: Option<i64>,
}

#[derive(FromRow)]
struct PeerRow {
    id: Uuid,
    name: String,
    avatar_kind: String,
    avatar_value: String,
    online: bool,
    last_seen: Option<i64>,
    receipt_message_id: i64,
}

#[derive(Serialize)]
pub struct Thread {
    peer: Peer,
    messages: Vec<Msg>,
    /// Messages up to this number were read by the other person (0 if they hide read receipts).
    peer_receipt: i64,
}

/// Messages after `after` (or the latest 100 when it is 0), plus the other person's status.
/// The app calls this every couple of seconds while a chat is open.
pub async fn get_messages(
    State(s): State<AppState>,
    AuthUser(me): AuthUser,
    Path(conv): Path<Uuid>,
    Query(q): Query<After>,
) -> Res<Json<Thread>> {
    require_member(&s.db, conv, me).await?;
    touch_active(&s.db, me).await;

    let p = sqlx::query_as::<_, PeerRow>(
        "SELECT u.id, u.name,
                CASE WHEN s.photo_vis = 'nobody' THEN 'preset' ELSE u.avatar_kind END AS avatar_kind,
                CASE WHEN s.photo_vis = 'nobody' THEN '0' ELSE u.avatar_value END AS avatar_value,
                COALESCE(s.show_online AND u.last_active_at > now() - interval '25 seconds', FALSE) AS online,
                CASE WHEN s.last_seen = 'nobody' THEN NULL
                     ELSE EXTRACT(EPOCH FROM u.last_active_at)::bigint END AS last_seen,
                pm.receipt_message_id
         FROM conversation_members pm
         JOIN users u ON u.id = pm.user_id
         JOIN user_settings s ON s.user_id = u.id
         WHERE pm.conversation_id = $1 AND pm.user_id <> $2
         LIMIT 1",
    )
    .bind(conv)
    .bind(me)
    .fetch_optional(&s.db)
    .await?
    .ok_or(AppError::NotFound)?;

    let messages = sqlx::query_as::<_, Msg>(
        "SELECT id, sender_id, body, ts FROM (
             SELECT id, sender_id, body, EXTRACT(EPOCH FROM created_at)::bigint AS ts
             FROM messages WHERE conversation_id = $1 AND id > $2
             ORDER BY id DESC LIMIT 100
         ) t ORDER BY id ASC",
    )
    .bind(conv)
    .bind(q.after.unwrap_or(0))
    .fetch_all(&s.db)
    .await?;

    Ok(Json(Thread {
        peer: Peer {
            id: p.id,
            name: p.name,
            avatar_kind: p.avatar_kind,
            avatar_value: p.avatar_value,
            online: p.online,
            last_seen: p.last_seen,
        },
        messages,
        peer_receipt: p.receipt_message_id,
    }))
}

#[derive(Deserialize)]
pub struct SendMsg {
    body: String,
}

pub async fn send_message(
    State(s): State<AppState>,
    AuthUser(me): AuthUser,
    Path(conv): Path<Uuid>,
    Json(b): Json<SendMsg>,
) -> Res<Json<Msg>> {
    require_member(&s.db, conv, me).await?;
    let body = b.body.trim().to_string();
    if body.is_empty() {
        return Err(AppError::BadRequest("empty_message"));
    }
    if body.chars().count() > 4000 {
        return Err(AppError::BadRequest("message_too_long"));
    }
    let msg = sqlx::query_as::<_, Msg>(
        "INSERT INTO messages (conversation_id, sender_id, body) VALUES ($1, $2, $3)
         RETURNING id, sender_id, body, EXTRACT(EPOCH FROM created_at)::bigint AS ts",
    )
    .bind(conv)
    .bind(me)
    .bind(&body)
    .fetch_one(&s.db)
    .await?;
    touch_active(&s.db, me).await;
    Ok(Json(msg))
}

/// Marks everything in the conversation as read. The other person only sees it if read receipts are on.
pub async fn mark_read(State(s): State<AppState>, AuthUser(me): AuthUser, Path(conv): Path<Uuid>) -> Res<StatusCode> {
    require_member(&s.db, conv, me).await?;
    sqlx::query(
        "UPDATE conversation_members SET
           last_read_message_id = COALESCE((SELECT MAX(id) FROM messages WHERE conversation_id = $1), 0),
           receipt_message_id = CASE
             WHEN (SELECT read_receipts FROM user_settings WHERE user_id = $2)
             THEN COALESCE((SELECT MAX(id) FROM messages WHERE conversation_id = $1), 0)
             ELSE receipt_message_id END
         WHERE conversation_id = $1 AND user_id = $2",
    )
    .bind(conv)
    .bind(me)
    .execute(&s.db)
    .await?;
    Ok(StatusCode::NO_CONTENT)
}
