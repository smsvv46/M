use serde::{Deserialize, Serialize};
use serde_json::Value;

pub use reqwest::Method;

/// Server address. Override at build time: M_API=https://api.example.com dx build
pub const API: &str = match option_env!("M_API") {
    Some(v) => v,
    None => "http://localhost:8080",
};

#[derive(Clone, PartialEq, Deserialize, Serialize, Debug)]
pub struct User {
    pub id: String,
    pub email: Option<String>,
    pub phone: Option<String>,
    pub name: String,
    pub bio: String,
    pub avatar_kind: String,
    pub avatar_value: String,
    pub banner: i16,
    pub invite_code: String,
}

impl User {
    /// Placeholder used while the real profile is not available (for example right after sign-out).
    pub fn blank() -> Self {
        User {
            id: String::new(),
            email: None,
            phone: None,
            name: String::new(),
            bio: String::new(),
            avatar_kind: "preset".into(),
            avatar_value: "0".into(),
            banner: 0,
            invite_code: String::new(),
        }
    }
}

#[derive(Clone, PartialEq, Deserialize, Serialize, Debug)]
pub struct Settings {
    pub read_receipts: bool,
    pub show_online: bool,
    pub last_seen: String,
    pub photo_vis: String,
    pub story_vis: String,
    pub add_by_phone: String,
    pub calls: String,
    pub language: String,
}

impl Settings {
    pub fn text(&self, key: &str) -> String {
        match key {
            "last_seen" => self.last_seen.clone(),
            "photo_vis" => self.photo_vis.clone(),
            "story_vis" => self.story_vis.clone(),
            "add_by_phone" => self.add_by_phone.clone(),
            "calls" => self.calls.clone(),
            _ => String::new(),
        }
    }
    pub fn flag(&self, key: &str) -> bool {
        match key {
            "read_receipts" => self.read_receipts,
            "show_online" => self.show_online,
            _ => false,
        }
    }
}

#[derive(Clone, PartialEq, Deserialize, Debug)]
pub struct Contact {
    pub id: String,
    pub name: String,
    pub avatar_kind: String,
    pub avatar_value: String,
}

/// One request to the server. Returns the JSON body (Null when empty) or the server's error code.
pub async fn call(method: Method, path: &str, body: Option<Value>, token: Option<String>) -> Result<Value, String> {
    let client = reqwest::Client::new();
    let mut req = client.request(method, format!("{API}{path}"));
    if let Some(t) = token {
        req = req.bearer_auth(t);
    }
    if let Some(b) = body {
        req = req.json(&b);
    }
    let res = req.send().await.map_err(|_| "network".to_string())?;
    let ok = res.status().is_success();
    let text = res.text().await.map_err(|_| "network".to_string())?;
    let value: Value = if text.is_empty() { Value::Null } else { serde_json::from_str(&text).unwrap_or(Value::Null) };
    if ok {
        Ok(value)
    } else {
        Err(value["error"].as_str().unwrap_or("generic").to_string())
    }
}

/// `?invite=CODE` from the page address, if present.
pub fn invite_from_url() -> Option<String> {
    let search = web_sys::window()?.location().search().ok()?;
    search
        .trim_start_matches('?')
        .split('&')
        .find_map(|p| p.strip_prefix("invite=").map(|s| s.to_string()))
        .filter(|s| !s.is_empty())
}

/// The address people should share, for example https://m.app/?invite=abc123xy
pub fn invite_link(code: &str) -> String {
    let origin = web_sys::window()
        .and_then(|w| w.location().origin().ok())
        .unwrap_or_default();
    format!("{origin}/?invite={code}")
}
