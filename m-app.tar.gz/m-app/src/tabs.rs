use crate::{
    api::{call, invite_link, Contact, Method, Settings, User},
    avatar,
    i18n::{err_text, tr, LANGUAGES},
    login::Icon,
    Ctx,
};
use dioxus::prelude::*;
use gloo_storage::{LocalStorage, Storage};
use serde_json::{json, Value};

const ICON_CHAT: &str = "M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8v.5z";
const ICON_USER: &str = "M12 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM4 21v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1";
const ICON_SLIDERS: &str = "M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0M16 4v4M10 10v4M18 16v4";

#[derive(Clone, Copy, PartialEq)]
enum Tab {
    Chats,
    Profile,
    Settings,
}

#[component]
pub fn Shell() -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let mut tab = use_signal(|| Tab::Chats);

    // The profile loads right after sign-in. Show the app only once it is here.
    if ctx.user.read().is_none() {
        return rsx! { div { class: "screen center", {tr(&lang(), "loading")} } };
    }

    let item = move |t: Tab, label: &'static str, icon: &'static str| {
        let cls = if tab() == t { "nav-item on" } else { "nav-item" };
        rsx! {
            button { class: "{cls}", r#type: "button", onclick: move |_| tab.set(t),
                Icon { d: icon }
                span { {tr(&lang(), label)} }
            }
        }
    };

    rsx! {
        div { class: "screen",
            div { class: "screen-body",
                match tab() {
                    Tab::Chats => rsx! { ChatsTab {} },
                    Tab::Profile => rsx! { ProfileTab {} },
                    Tab::Settings => rsx! { SettingsTab {} },
                }
            }
            nav { class: "nav",
                {item(Tab::Chats, "chats", ICON_CHAT)}
                {item(Tab::Profile, "profile", ICON_USER)}
                {item(Tab::Settings, "settings", ICON_SLIDERS)}
            }
        }
    }
}

// ---------------------------------------------------------------- chats

#[component]
fn ChatsTab() -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let user = ctx.user;

    let mut contacts = use_signal(Vec::<Contact>::new);
    let mut phone = use_signal(String::new);
    let mut note = use_signal(String::new);
    let mut failed = use_signal(|| false);

    let mut reload = move || {
        spawn(async move {
            if let Ok(v) = call(Method::GET, "/me/contacts", None, token()).await {
                contacts.set(serde_json::from_value(v).unwrap_or_default());
            }
        });
    };
    use_hook(move || reload());

    let link = user().map(|u| invite_link(&u.invite_code)).unwrap_or_default();
    let copy_link = {
        let link = link.clone();
        move |_| {
            // Link characters are limited to letters, digits and URL punctuation, so it is safe in a JS string.
            let _ = document::eval(&format!("navigator.clipboard.writeText('{link}')"));
            failed.set(false);
            note.set(tr(&lang(), "copied"));
        }
    };

    let add_phone = move |_| {
        spawn(async move {
            match call(Method::POST, "/me/contacts", Some(json!({ "phone": phone() })), token()).await {
                Ok(_) => {
                    failed.set(false);
                    note.set(tr(&lang(), "added"));
                    phone.set(String::new());
                    if let Ok(v) = call(Method::GET, "/me/contacts", None, token()).await {
                        contacts.set(serde_json::from_value(v).unwrap_or_default());
                    }
                }
                Err(e) => {
                    failed.set(true);
                    note.set(if e == "not_found" { tr(&lang(), "not_found") } else { err_text(&lang(), &e) });
                }
            }
        });
    };

    rsx! {
        header { class: "top", h1 { class: "display", {tr(&lang(), "chats")} } }

        section { class: "card",
            h2 { {tr(&lang(), "invite_title")} }
            p { class: "hint", {tr(&lang(), "invite_sub")} }
            div { class: "link", "{link}" }
            button { class: "silver small", r#type: "button", onclick: copy_link, {tr(&lang(), "copy")} }
        }

        section { class: "card",
            h2 { {tr(&lang(), "add_phone")} }
            div { class: "row",
                input {
                    class: "plain", r#type: "tel", inputmode: "tel", placeholder: "+20 101 234 5678",
                    value: "{phone}", oninput: move |e| phone.set(e.value()),
                }
                button { class: "silver small", r#type: "button", onclick: add_phone, {tr(&lang(), "add")} }
            }
            if !note().is_empty() {
                p { class: if failed() { "note err" } else { "note ok" }, role: "status", "{note}" }
            }
        }

        section { class: "card",
            h2 { {tr(&lang(), "contacts")} }
            if contacts().is_empty() {
                p { class: "hint", {tr(&lang(), "no_contacts")} }
            }
            for c in contacts() {
                div { class: "contact", key: "{c.id}",
                    img { class: "avatar sm", src: "{avatar::user_uri(&c.avatar_kind, &c.avatar_value)}", alt: "" }
                    span { "{c.name}" }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- profile

async fn patch_me(token: Option<String>, mut user: Signal<Option<User>>, body: Value) -> Result<(), String> {
    let v = call(Method::PATCH, "/me", Some(body), token).await?;
    user.set(serde_json::from_value(v).ok());
    Ok(())
}

#[component]
fn ProfileTab() -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let mut token_out = ctx.token;
    let user = ctx.user;

    let u = user().unwrap_or_else(User::blank);
    let mut name = use_signal(|| u.name.clone());
    let mut bio = use_signal(|| u.bio.clone());
    let mut cur_pw = use_signal(String::new);
    let mut new_pw = use_signal(String::new);
    let mut note = use_signal(String::new);
    let mut failed = use_signal(|| false);

    let save = move |_| {
        spawn(async move {
            match patch_me(token(), user, json!({ "name": name(), "bio": bio() })).await {
                Ok(_) => {
                    failed.set(false);
                    note.set(tr(&lang(), "saved"));
                }
                Err(e) => {
                    failed.set(true);
                    note.set(err_text(&lang(), &e));
                }
            }
        });
    };

    let change_pw = move |_| {
        spawn(async move {
            let current = cur_pw();
            let body = json!({
                "current": if current.is_empty() { Value::Null } else { Value::String(current) },
                "new": new_pw(),
            });
            match call(Method::POST, "/me/password", Some(body), token()).await {
                Ok(_) => {
                    failed.set(false);
                    note.set(tr(&lang(), "pw_done"));
                    cur_pw.set(String::new());
                    new_pw.set(String::new());
                }
                Err(e) => {
                    failed.set(true);
                    note.set(err_text(&lang(), &e));
                }
            }
        });
    };

    let logout = move |_| {
        LocalStorage::delete("m_token");
        token_out.set(None);
    };

    let cur_ph = tr(&lang(), "cur_pw");
    let new_ph = tr(&lang(), "new_pw");
    let current = user().unwrap_or(u);
    let banner_cls = format!("banner b{}", current.banner);
    let picture = avatar::of(&current);

    rsx! {
        section { class: "card profile",
            div { class: "{banner_cls}" }
            div { class: "profile-body",
                img { class: "avatar lg", src: "{picture}", alt: "" }
                h2 { class: "display name", "{current.name}" }
                p { class: "hint", "{current.bio}" }
            }
        }

        section { class: "card",
            label { class: "stack", span { {tr(&lang(), "name")} }
                input { class: "plain", r#type: "text", maxlength: "30", value: "{name}", oninput: move |e| name.set(e.value()) }
            }
            label { class: "stack", span { {tr(&lang(), "bio")} }
                textarea { class: "plain", maxlength: "120", value: "{bio}", oninput: move |e| bio.set(e.value()) }
            }
            button { class: "silver small", r#type: "button", onclick: save, {tr(&lang(), "save")} }
        }

        section { class: "card",
            h2 { {tr(&lang(), "avatar")} }
            div { class: "grid6",
                for i in 0..avatar::PRESET_COUNT {
                    button {
                        key: "{i}", r#type: "button",
                        class: if current.avatar_kind == "preset" && current.avatar_value == i.to_string() { "pick on round" } else { "pick round" },
                        "aria-label": "avatar {i}",
                        onclick: move |_| {
                            spawn(async move {
                                let _ = patch_me(token(), user, json!({ "avatar_kind": "preset", "avatar_value": i.to_string() })).await;
                            });
                        },
                        img { src: "{avatar::preset_uri(i)}", alt: "" }
                    }
                }
            }
        }

        section { class: "card",
            h2 { {tr(&lang(), "banner")} }
            div { class: "grid6",
                for i in 0..6i16 {
                    button {
                        key: "{i}", r#type: "button",
                        class: if current.banner == i { "pick on wide" } else { "pick wide" },
                        "aria-label": "banner {i}",
                        onclick: move |_| {
                            spawn(async move {
                                let _ = patch_me(token(), user, json!({ "banner": i })).await;
                            });
                        },
                        span { class: "banner b{i}" }
                    }
                }
            }
        }

        section { class: "card",
            h2 { {tr(&lang(), "change_pw")} }
            input { class: "plain", r#type: "password", autocomplete: "current-password", placeholder: "{cur_ph}", value: "{cur_pw}", oninput: move |e| cur_pw.set(e.value()) }
            input { class: "plain", r#type: "password", autocomplete: "new-password", placeholder: "{new_ph}", value: "{new_pw}", oninput: move |e| new_pw.set(e.value()) }
            button { class: "silver small", r#type: "button", onclick: change_pw, {tr(&lang(), "change_pw")} }
        }

        if !note().is_empty() {
            p { class: if failed() { "note err" } else { "note ok" }, role: "status", "{note}" }
        }
        button { class: "danger", r#type: "button", onclick: logout, {tr(&lang(), "logout")} }
    }
}

// ---------------------------------------------------------------- settings

/// `{ field: value }` with the field name taken from a variable.
fn one(field: &str, value: Value) -> Value {
    let mut m = serde_json::Map::new();
    m.insert(field.to_string(), value);
    Value::Object(m)
}

async fn patch_settings(token: Option<String>, mut settings: Signal<Option<Settings>>, body: Value) {
    if let Ok(v) = call(Method::PATCH, "/me/settings", Some(body), token).await {
        settings.set(serde_json::from_value(v).ok());
    }
}

#[component]
fn ToggleRow(label: &'static str, hint: &'static str, field: &'static str, settings: Signal<Option<Settings>>) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let on = settings().map(|s| s.flag(field)).unwrap_or(true);
    let label_text = tr(&lang(), label);
    rsx! {
        div { class: "row-setting",
            div { class: "grow",
                strong { {tr(&lang(), label)} }
                small { {tr(&lang(), hint)} }
            }
            button {
                class: if on { "switch on" } else { "switch" },
                r#type: "button", role: "switch", "aria-checked": "{on}", "aria-label": "{label_text}",
                onclick: move |_| {
                    spawn(async move { patch_settings(token(), settings, one(field, json!(!on))).await });
                },
                span { class: "knob" }
            }
        }
    }
}

#[component]
fn VisRow(label: &'static str, field: &'static str, settings: Signal<Option<Settings>>) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let value = settings().map(|s| s.text(field)).unwrap_or_default();
    let label_text = tr(&lang(), label);
    rsx! {
        div { class: "row-setting",
            strong { class: "grow", {tr(&lang(), label)} }
            select {
                class: "plain compact", "aria-label": "{label_text}",
                onchange: move |e| {
                    let v = e.value();
                    spawn(async move { patch_settings(token(), settings, one(field, json!(v))).await });
                },
                for (val, key) in [("all", "all"), ("contacts", "contacts_only"), ("nobody", "nobody")] {
                    option { key: "{val}", value: "{val}", selected: value == val, {tr(&lang(), key)} }
                }
            }
        }
    }
}

#[component]
fn SettingsTab() -> Element {
    let ctx = use_context::<Ctx>();
    let mut lang = ctx.lang;
    let token = ctx.token;

    let language_label = tr(&lang(), "language");
    let mut settings = use_signal(|| None::<Settings>);
    use_hook(move || {
        spawn(async move {
            if let Ok(v) = call(Method::GET, "/me/settings", None, token()).await {
                settings.set(serde_json::from_value(v).ok());
            }
        });
    });

    rsx! {
        header { class: "top", h1 { class: "display", {tr(&lang(), "settings")} } }

        section { class: "card",
            div { class: "row-setting",
                strong { class: "grow", {tr(&lang(), "language")} }
                select {
                    class: "plain compact", "aria-label": "{language_label}",
                    onchange: move |e| {
                        let v = e.value();
                        let _ = LocalStorage::set("m_lang", v.clone());
                        lang.set(v.clone());
                        spawn(async move { patch_settings(token(), settings, json!({ "language": v })).await });
                    },
                    for (code, label) in LANGUAGES.iter() {
                        option { key: "{code}", value: "{code}", selected: lang() == *code, "{label}" }
                    }
                }
            }
        }

        section { class: "card",
            h2 { {tr(&lang(), "privacy")} }
            ToggleRow { label: "read_receipts", hint: "read_receipts_hint", field: "read_receipts", settings }
            ToggleRow { label: "show_online", hint: "show_online_hint", field: "show_online", settings }
            VisRow { label: "last_seen", field: "last_seen", settings }
            VisRow { label: "photo_vis", field: "photo_vis", settings }
            VisRow { label: "story_vis", field: "story_vis", settings }
            VisRow { label: "add_by_phone", field: "add_by_phone", settings }
            VisRow { label: "calls", field: "calls", settings }
        }
    }
}
