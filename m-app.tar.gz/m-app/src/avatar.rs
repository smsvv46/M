use crate::api::User;

pub const PRESET_COUNT: usize = 12;

const BG: [&str; 6] = ["#9a9aa3", "#d8d8de", "#5e5e68", "#b9b9c2", "#3a3a44", "#8d8d96"];
const SKIN: [&str; 4] = ["#f1c9a5", "#d9a074", "#a8714a", "#ffe0c2"];
const HAIR: [&str; 4] = ["#2b2118", "#5a3a22", "#1c1c28", "#b5532a"];

/// A generated cartoon avatar as an image address. `i` picks the combination.
pub fn preset_uri(i: usize) -> String {
    let bg = BG[i % 6];
    let skin = SKIN[i % 4];
    let hair = HAIR[(i + 1) % 4];
    let shirt = HAIR[(i + 2) % 4];
    let eyes = match i % 3 {
        0 => "<circle cx='26' cy='36' r='2.3' fill='%23222'/><circle cx='38' cy='36' r='2.3' fill='%23222'/>",
        1 => "<rect x='23.5' y='35' width='5' height='2.4' rx='1.2' fill='%23222'/><rect x='35.5' y='35' width='5' height='2.4' rx='1.2' fill='%23222'/>",
        _ => "<path d='M23 37q3-4 6 0M35 37q3-4 6 0' stroke='%23222' stroke-width='2' fill='none' stroke-linecap='round'/>",
    };
    let mouth = match (i + 1) % 3 {
        0 => "<path d='M27 43q5 5 10 0' stroke='%23222' stroke-width='2' fill='none' stroke-linecap='round'/>",
        1 => "<rect x='28' y='43' width='8' height='3' rx='1.5' fill='%23222'/>",
        _ => "<path d='M28 44h8' stroke='%23222' stroke-width='2' stroke-linecap='round'/>",
    };
    let hair_shape = if i % 2 == 1 {
        format!("<path d='M14 34c0-14 9-20 18-20s18 6 18 20c-4-8-10-11-18-11s-14 3-18 11z' fill='{hair}'/>")
    } else {
        format!("<path d='M15 32c2-12 9-16 17-16s15 4 17 16c-6-5-11-6-17-6s-11 1-17 6z' fill='{hair}'/>")
    };
    let svg = format!(
        "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'><rect width='64' height='64' fill='{bg}'/><ellipse cx='32' cy='66' rx='22' ry='14' fill='{shirt}'/><circle cx='32' cy='37' r='16' fill='{skin}'/>{hair_shape}{eyes}{mouth}</svg>"
    )
    .replace('#', "%23"); // '#' must be escaped inside an image address
    format!("data:image/svg+xml;utf8,{svg}")
}

/// The picture to show for a user: their uploaded photo or the chosen preset.
pub fn user_uri(avatar_kind: &str, avatar_value: &str) -> String {
    if avatar_kind == "photo" {
        avatar_value.to_string()
    } else {
        preset_uri(avatar_value.parse::<usize>().unwrap_or(0) % PRESET_COUNT)
    }
}

pub fn of(u: &User) -> String {
    user_uri(&u.avatar_kind, &u.avatar_value)
}
