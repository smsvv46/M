mod auth;
mod chat;
mod error;
mod notify;
mod routes;
mod stories;
mod translate;

use std::{net::SocketAddr, sync::Arc};

use axum::{
    extract::DefaultBodyLimit,
    routing::{get, post},
    Router,
};
use sqlx::postgres::PgPoolOptions;
use tower_http::{cors::CorsLayer, services::ServeDir, trace::TraceLayer};

#[derive(Clone)]
pub struct AppState {
    pub db: sqlx::PgPool,
    pub jwt_secret: String,
    pub notifier: Arc<notify::Notifier>,
    pub upload_dir: String,
    pub http: reqwest::Client,
    pub translate_key: Option<String>,
    pub translate_model: String,
}

#[tokio::main]
async fn main() {
    dotenvy::dotenv().ok();
    tracing_subscriber::fmt()
        .with_env_filter(std::env::var("RUST_LOG").unwrap_or_else(|_| "info".into()))
        .init();

    let database_url = std::env::var("DATABASE_URL").expect("DATABASE_URL is required");
    let jwt_secret = std::env::var("JWT_SECRET").expect("JWT_SECRET is required");
    assert!(jwt_secret.len() >= 32, "JWT_SECRET must be at least 32 characters");

    let db = PgPoolOptions::new()
        .max_connections(10)
        .connect(&database_url)
        .await
        .expect("cannot connect to the database");
    sqlx::migrate!().run(&db).await.expect("migration failed");

    // Remove expired verification codes every 10 minutes.
    let cleanup_db = db.clone();
    tokio::spawn(async move {
        let mut tick = tokio::time::interval(std::time::Duration::from_secs(600));
        loop {
            tick.tick().await;
            let _ = sqlx::query("DELETE FROM otp_codes WHERE expires_at < now() - interval '1 day'")
                .execute(&cleanup_db)
                .await;
        }
    });

    // Uploaded photos and banners live here. Use a persistent disk or object storage in production.
    let upload_dir = std::env::var("UPLOAD_DIR").unwrap_or_else(|_| "uploads".into());
    std::fs::create_dir_all(&upload_dir).expect("cannot create the uploads folder");

    // Delete stories 24 hours after posting, together with their files.
    let story_db = db.clone();
    let story_dir = std::env::var("UPLOAD_DIR").unwrap_or_else(|_| "uploads".into());
    tokio::spawn(async move {
        let mut tick = tokio::time::interval(std::time::Duration::from_secs(300));
        loop {
            tick.tick().await;
            let urls: Vec<String> = sqlx::query_scalar("DELETE FROM stories WHERE expires_at < now() RETURNING media_url")
                .fetch_all(&story_db)
                .await
                .unwrap_or_default();
            for u in urls {
                if let Some(name) = u.strip_prefix("/files/") {
                    if !name.is_empty() && !name.contains('/') && !name.contains('\\') && !name.contains("..") {
                        let _ = tokio::fs::remove_file(format!("{story_dir}/{name}")).await;
                    }
                }
            }
        }
    });

    let state = AppState {
        db,
        jwt_secret,
        notifier: Arc::new(notify::Notifier::from_env()),
        upload_dir: upload_dir.clone(),
        http: reqwest::Client::new(),
        translate_key: std::env::var("ANTHROPIC_API_KEY").ok().filter(|k| !k.is_empty()),
        translate_model: std::env::var("TRANSLATE_MODEL").unwrap_or_else(|_| "claude-haiku-5-5".into()),
    };

    let app = Router::new()
        .route("/health", get(|| async { "ok" }))
        .route("/auth/request-code", post(routes::request_code))
        .route("/auth/verify", post(routes::verify_code))
        .route("/me", get(routes::get_me).patch(routes::patch_me))
        .route("/me/password", post(routes::set_password))
        .route("/me/settings", get(routes::get_settings).patch(routes::patch_settings))
        .route("/me/contacts", get(routes::list_contacts).post(routes::add_contact_by_phone))
        .route("/me/avatar", post(routes::upload_avatar).layer(DefaultBodyLimit::max(6 * 1024 * 1024)))
        .route("/me/banner", post(routes::upload_banner).layer(DefaultBodyLimit::max(25 * 1024 * 1024)))
        .route("/users/:id", get(routes::get_user))
        .route("/contacts/match", post(routes::match_contacts))
        .route("/chats", get(chat::list_chats))
        .route("/chats/open", post(chat::open_chat))
        .route("/chats/:id/messages", get(chat::get_messages).post(chat::send_message))
        .route("/chats/:id/read", post(chat::mark_read))
        .route("/stories", get(stories::feed))
        .route("/stories/media", post(stories::create_media).layer(DefaultBodyLimit::max(25 * 1024 * 1024)))
        .route("/stories/text", post(stories::create_text))
        .route("/stories/:id", axum::routing::delete(stories::delete_story))
        .route("/stories/:id/view", post(stories::mark_viewed))
        .route("/stories/:id/like", post(stories::toggle_like))
        .route("/stories/:id/repost", post(stories::repost))
        .route("/stories/:id/comments", get(stories::list_comments).post(stories::add_comment))
        .route("/stories/:id/viewers", get(stories::viewers))
        .route("/i18n/translate", post(translate::translate))
        .route("/invite/:code", post(routes::accept_invite))
        .nest_service("/files", ServeDir::new(upload_dir))
        .layer(CorsLayer::permissive()) // development only: restrict origins before launch
        .layer(TraceLayer::new_for_http())
        .with_state(state);

    let port: u16 = std::env::var("PORT").ok().and_then(|p| p.parse().ok()).unwrap_or(8080);
    let addr = SocketAddr::from(([0, 0, 0, 0], port));
    tracing::info!("Stitch server listening on {addr}");
    let listener = tokio::net::TcpListener::bind(addr).await.unwrap();
    axum::serve(listener, app).await.unwrap();
}
