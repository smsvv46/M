use crate::{
    api::{call, get_bool, set_bool, Method, Settings, User},
    i18n::{err_text, load_language, tr, LANGUAGES},
    login::{Icon, ICON_LOCK},
    social::ICON_BACK,
    tabs::{patch_settings, ThemePicker, ToggleRow, VisRow},
    Ctx,
};
use dioxus::prelude::*;
use gloo_storage::{LocalStorage, Storage};
use serde_json::{json, Value};

const ICON_KEY: &str = "M21 2l-2 2m-7.6 7.6a5.5 5.5 0 1 1-7.8 7.8 5.5 5.5 0 0 1 7.8-7.8zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4";
const ICON_LIST: &str = "M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01";
const ICON_CHATS: &str = "M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8v.5z";
const ICON_PALETTE: &str = "M12 3a9 9 0 1 0 0 18c1.5 0 2-1 1.5-2.2-.5-1.2.2-2.3 1.6-2.3H17a4 4 0 0 0 4-4c0-5-4-9.5-9-9.5z";
const ICON_BELL: &str = "M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0";
const ICON_DATA: &str = "M12 3v12M7 10l5 5 5-5M5 21h14";
const ICON_ACCESS: &str = "M12 4a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM5 9l7 1 7-1M12 10v5M9 21l3-6 3 6";
const ICON_GLOBE: &str = "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM3 12h18M12 3a14 14 0 0 1 0 18 14 14 0 0 1 0-18";
const ICON_HELP: &str = "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6M12 17h.01";

#[derive(Clone, Copy, PartialEq)]
enum Page {
    Menu,
    Account,
    Privacy,
    Lists,
    Chats,
    Appearance,
    Notifications,
    Storage,
    Accessibility,
    Language,
    Help,
}

/// (page, icon, title text key, subtitle text key)
const MENU: &[(Page, &str, &str, &str)] = &[
    (Page::Account, ICON_KEY, "acc_title", "acc_sub"),
    (Page::Privacy, ICON_LOCK, "privacy", "priv_sub"),
    (Page::Lists, ICON_LIST, "lists", "lists_sub"),
    (Page::Chats, ICON_CHATS, "chats", "chats_sub"),
    (Page::Appearance, ICON_PALETTE, "appearance", "appearance_sub"),
    (Page::Notifications, ICON_BELL, "notifications", "notif_sub"),
    (Page::Storage, ICON_DATA, "storage", "storage_sub"),
    (Page::Accessibility, ICON_ACCESS, "accessibility", "access_sub"),
    (Page::Language, ICON_GLOBE, "language", "lang_sub"),
    (Page::Help, ICON_HELP, "help", "help_sub"),
];

#[component]
pub fn SettingsTab() -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let mut page = use_signal(|| Page::Menu);
    let mut settings = use_signal(|| None::<Settings>);
    use_hook(move || {
        spawn(async move {
            if let Ok(v) = call(Method::GET, "/me/settings", None, token()).await {
                settings.set(serde_json::from_value(v).ok());
            }
        });
    });

    let back_label = tr(&lang(), "back");
    let current = page();

    if current == Page::Menu {
        return rsx! {
            header { class: "top", h1 { class: "display", {tr(&lang(), "settings")} } }
            div { class: "menu",
                for (p, icon, title, sub) in MENU.iter() {
                    button {
                        key: "{title}", class: "menu-row", r#type: "button",
                        onclick: {
                            let p = *p;
                            move |_| page.set(p)
                        },
                        span { class: "menu-ic", Icon { d: *icon } }
                        span { class: "menu-tx",
                            strong { {tr(&lang(), title)} }
                            small { {tr(&lang(), sub)} }
                        }
                    }
                }
            }
        };
    }

    let title_key = MENU.iter().find(|m| m.0 == current).map(|m| m.2).unwrap_or("settings");
    rsx! {
        header { class: "bar",
            button {
                class: "icon-btn", r#type: "button", "aria-label": "{back_label}",
                onclick: move |_| page.set(Page::Menu),
                Icon { d: ICON_BACK }
            }
            h2 { class: "bar-title", {tr(&lang(), title_key)} }
        }
        match current {
            Page::Account => rsx! { AccountPage {} },
            Page::Privacy => rsx! { PrivacyPage { settings } },
            Page::Lists => rsx! { ListsPage {} },
            Page::Chats => rsx! { ChatsPage { settings } },
            Page::Appearance => rsx! { AppearancePage {} },
            Page::Notifications => rsx! { NotificationsPage {} },
            Page::Storage => rsx! { StoragePage {} },
            Page::Accessibility => rsx! { AccessibilityPage {} },
            Page::Language => rsx! { LanguagePage { settings } },
            Page::Help => rsx! { HelpPage {} },
            Page::Menu => rsx! {},
        }
    }
}

/// An on/off switch kept on this phone only.
#[component]
fn LocalToggle(label: &'static str, hint: &'static str, pref: &'static str, default: bool) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let mut rev = ctx.rev;
    let mut on = use_signal(|| get_bool(pref, default));
    let label_text = tr(&lang(), label);
    rsx! {
        div { class: "row-setting",
            div { class: "grow",
                strong { {tr(&lang(), label)} }
                small { {tr(&lang(), hint)} }
            }
            button {
                class: if on() { "switch on" } else { "switch" },
                r#type: "button", role: "switch", "aria-checked": "{on()}", "aria-label": "{label_text}",
                onclick: move |_| {
                    let v = !on();
                    on.set(v);
                    set_bool(pref, v);
                    rev.set(rev() + 1);
                },
                span { class: "knob" }
            }
        }
    }
}

#[component]
fn AccountPage() -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let mut token_out = ctx.token;
    let user = ctx.user;
    let mut cur_pw = use_signal(String::new);
    let mut new_pw = use_signal(String::new);
    let mut note = use_signal(String::new);
    let mut failed = use_signal(|| false);

    let u = user().unwrap_or_else(User::blank);
    let email = u.email.clone().unwrap_or_else(|| "-".to_string());
    let phone = u.phone.clone().unwrap_or_else(|| "-".to_string());

    let change_pw = move |_| {
        spawn(async move {
            let current = cur_pw();
            let body = json!({
                "current": if current.is_empty() { Value::Null } else { Value::String(current) },
                "new": new_pw(),
            });
            match call(Method::POST, "/me/password", Some(body), token()).await {
                Ok(_) => {
                    failed.set(false);
                    note.set(tr(&lang(), "pw_done"));
                    cur_pw.set(String::new());
                    new_pw.set(String::new());
                }
                Err(e) => {
                    failed.set(true);
                    note.set(err_text(&lang(), &e));
                }
            }
        });
    };
    let logout = move |_| {
        LocalStorage::delete("m_token");
        token_out.set(None);
    };

    let cur_ph = tr(&lang(), "cur_pw");
    let new_ph = tr(&lang(), "new_pw");

    rsx! {
        section { class: "card",
            div { class: "row-setting",
                strong { class: "grow", {tr(&lang(), "email_label")} }
                span { class: "hint", "{email}" }
            }
            div { class: "row-setting",
                strong { class: "grow", {tr(&lang(), "phone_label")} }
                span { class: "hint", "{phone}" }
            }
        }
        section { class: "card",
            h2 { {tr(&lang(), "change_pw")} }
            input { class: "plain", r#type: "password", autocomplete: "current-password", placeholder: "{cur_ph}", value: "{cur_pw}", oninput: move |e| cur_pw.set(e.value()) }
            input { class: "plain", r#type: "password", autocomplete: "new-password", placeholder: "{new_ph}", value: "{new_pw}", oninput: move |e| new_pw.set(e.value()) }
            button { class: "silver small", r#type: "button", onclick: change_pw, {tr(&lang(), "change_pw")} }
        }
        if !note().is_empty() {
            p { class: if failed() { "note err" } else { "note ok" }, role: "status", "{note}" }
        }
        button { class: "danger", r#type: "button", onclick: logout, {tr(&lang(), "logout")} }
    }
}

#[component]
fn PrivacyPage(settings: Signal<Option<Settings>>) -> Element {
    rsx! {
        section { class: "card",
            ToggleRow { label: "read_receipts", hint: "read_receipts_hint", field: "read_receipts", settings }
            ToggleRow { label: "show_online", hint: "show_online_hint", field: "show_online", settings }
            VisRow { label: "last_seen", field: "last_seen", settings }
            VisRow { label: "photo_vis", field: "photo_vis", settings }
            VisRow { label: "story_vis", field: "story_vis", settings }
            VisRow { label: "add_by_phone", field: "add_by_phone", settings }
        }
    }
}

#[component]
fn ListsPage() -> Element {
    let lang = use_context::<Ctx>().lang;
    let mut lists = use_signal(|| LocalStorage::get::<Vec<String>>("m_lists").unwrap_or_default());
    let mut name = use_signal(String::new);

    let add = move |_| {
        let n = name().trim().to_string();
        if n.is_empty() || n.chars().count() > 20 {
            return;
        }
        let mut l = lists();
        if !l.contains(&n) {
            l.push(n);
            let _ = LocalStorage::set("m_lists", l.clone());
            lists.set(l);
        }
        name.set(String::new());
    };
    let ph = tr(&lang(), "list_name_ph");

    rsx! {
        section { class: "card",
            div { class: "row",
                input { class: "plain", r#type: "text", maxlength: "20", placeholder: "{ph}", value: "{name}", oninput: move |e| name.set(e.value()) }
                button { class: "silver small", r#type: "button", onclick: add, {tr(&lang(), "create")} }
            }
            if lists().is_empty() { p { class: "hint", {tr(&lang(), "no_lists")} } }
            for l in lists() {
                div { key: "{l}", class: "row-setting",
                    strong { class: "grow", "{l}" }
                    button {
                        class: "add-btn", r#type: "button",
                        onclick: {
                            let l = l.clone();
                            move |_| {
                                let kept: Vec<String> = lists().into_iter().filter(|x| *x != l).collect();
                                let _ = LocalStorage::set("m_lists", kept.clone());
                                lists.set(kept);
                            }
                        },
                        {tr(&lang(), "delete")}
                    }
                }
            }
        }
    }
}

#[component]
fn ChatsPage(settings: Signal<Option<Settings>>) -> Element {
    rsx! {
        section { class: "card",
            LocalToggle { label: "keep_arch", hint: "keep_arch_hint", pref: "m_keep_archived", default: true }
            ToggleRow { label: "read_receipts", hint: "read_receipts_hint", field: "read_receipts", settings }
        }
    }
}

#[component]
fn AppearancePage() -> Element {
    let lang = use_context::<Ctx>().lang;
    rsx! {
        section { class: "card",
            h2 { {tr(&lang(), "theme_bg")} }
            ThemePicker {}
        }
    }
}

fn notif_permission() -> String {
    js_sys::eval("('Notification' in window)?Notification.permission:'unsupported'")
        .ok()
        .and_then(|v| v.as_string())
        .unwrap_or_else(|| "unsupported".to_string())
}

#[component]
fn NotificationsPage() -> Element {
    let lang = use_context::<Ctx>().lang;
    let mut perm = use_signal(notif_permission);
    let ask = move |_| {
        let _ = js_sys::eval("Notification.requestPermission()");
        spawn(async move {
            for _ in 0..40 {
                gloo_timers::future::TimeoutFuture::new(500).await;
                let p = notif_permission();
                let done = p != "default";
                perm.set(p);
                if done {
                    break;
                }
            }
        });
    };
    let test = move |_| {
        let _ = js_sys::eval("try{new Notification('Stitch',{body:'OK'});}catch(e){}");
    };
    let p = perm();
    rsx! {
        section { class: "card",
            LocalToggle { label: "notif_toggle", hint: "notif_toggle_hint", pref: "m_notify", default: true }
            LocalToggle { label: "sound", hint: "sound_hint", pref: "m_sound", default: true }
            LocalToggle { label: "vibrate", hint: "vibrate_hint", pref: "m_vibrate", default: true }
        }
        section { class: "card",
            if p == "granted" {
                p { class: "note ok", {tr(&lang(), "notif_granted")} }
                button { class: "silver small", r#type: "button", onclick: test, {tr(&lang(), "test_notif")} }
            } else if p == "denied" {
                p { class: "note err", {tr(&lang(), "notif_denied")} }
            } else if p == "unsupported" {
                p { class: "hint", {tr(&lang(), "notif_unsupported")} }
            } else {
                button { class: "silver small", r#type: "button", onclick: ask, {tr(&lang(), "notif_enable")} }
            }
        }
    }
}

#[component]
fn StoragePage() -> Element {
    let lang = use_context::<Ctx>().lang;
    let mut note = use_signal(String::new);
    let clear = move |_| {
        let _ = document::eval(
            "Object.keys(localStorage).filter(function(k){return k.indexOf('m_i18n_')===0||k==='m_phonebook';}).forEach(function(k){localStorage.removeItem(k);});",
        );
        note.set(tr(&lang(), "cache_cleared"));
    };
    rsx! {
        section { class: "card",
            LocalToggle { label: "datasaver", hint: "datasaver_hint", pref: "m_datasaver", default: false }
            button { class: "silver small", r#type: "button", onclick: clear, {tr(&lang(), "clear_cache")} }
            if !note().is_empty() { p { class: "note ok", role: "status", "{note}" } }
        }
    }
}

#[component]
fn AccessibilityPage() -> Element {
    rsx! {
        section { class: "card",
            LocalToggle { label: "hc", hint: "hc_hint", pref: "m_hc", default: false }
            LocalToggle { label: "nomotion", hint: "nomotion_hint", pref: "m_nomotion", default: false }
            LocalToggle { label: "bigtext", hint: "bigtext_hint", pref: "m_big", default: false }
        }
    }
}

#[component]
fn LanguagePage(settings: Signal<Option<Settings>>) -> Element {
    let ctx = use_context::<Ctx>();
    let mut lang = ctx.lang;
    let token = ctx.token;
    let language_label = tr(&lang(), "language");
    let mut translating = use_signal(|| false);
    let mut translate_failed = use_signal(|| false);
    rsx! {
        section { class: "card",
            div { class: "row-setting stack",
                strong { {tr(&lang(), "language")} }
                select {
                    class: "plain compact", "aria-label": "{language_label}",
                    onchange: move |e| {
                        let v = e.value();
                        let _ = LocalStorage::set("m_lang", v.clone());
                        let code = v.clone();
                        spawn(async move {
                            translating.set(true);
                            translate_failed.set(false);
                            let ok = load_language(&code, token()).await;
                            translate_failed.set(!ok);
                            lang.set(code.clone());
                            translating.set(false);
                            patch_settings(token(), settings, json!({ "language": code })).await;
                        });
                    },
                    for (code, label, _english) in LANGUAGES.iter() {
                        option { key: "{code}", value: "{code}", selected: lang() == *code, "{label}" }
                    }
                }
            }
            if translating() { p { class: "hint", {tr(&lang(), "translating")} } }
            if translate_failed() { p { class: "note err", {tr(&lang(), "translation_unavailable")} } }
        }
    }
}

#[component]
fn HelpPage() -> Element {
    let lang = use_context::<Ctx>().lang;
    rsx! {
        section { class: "card",
            h2 { "Stitch" }
            p { class: "hint", {tr(&lang(), "about")} }
            p { class: "hint", {tr(&lang(), "help_tip")} }
            p { class: "hint", "Stitch v10" }
        }
    }
}
