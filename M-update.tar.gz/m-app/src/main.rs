mod api;
mod avatar;
mod i18n;
mod login;
mod social;
mod tabs;

use api::{call, invite_from_url, Method, User};
use dioxus::prelude::*;
use gloo_storage::{LocalStorage, Storage};

const CSS: Asset = asset!("/assets/main.css");

/// Shared app state: who is signed in and which language is on.
#[derive(Clone, Copy)]
pub struct Ctx {
    pub token: Signal<Option<String>>,
    pub user: Signal<Option<User>>,
    pub lang: Signal<String>,
}

fn main() {
    dioxus::launch(App);
}

#[component]
fn App() -> Element {
    let mut token = use_signal(|| LocalStorage::get::<String>("m_token").ok());
    let mut user = use_signal(|| None::<User>);
    let lang = use_signal(|| LocalStorage::get::<String>("m_lang").unwrap_or_else(|_| "en".to_string()));
    use_context_provider(|| Ctx { token, user, lang });

    // Whenever the token changes, load the profile. An invalid token signs the person out.
    use_effect(move || {
        if let Some(t) = token() {
            spawn(async move {
                match call(Method::GET, "/me", None, Some(t.clone())).await {
                    Ok(v) => {
                        user.set(serde_json::from_value(v).ok());
                        if let Some(code) = invite_from_url() {
                            let _ = call(Method::POST, &format!("/invite/{code}"), None, Some(t)).await;
                        }
                    }
                    Err(e) => {
                        if e == "unauthorized" {
                            LocalStorage::delete("m_token");
                            token.set(None);
                        }
                    }
                }
            });
        } else {
            user.set(None);
        }
    });

    let dir = if lang() == "ar" { "rtl" } else { "ltr" };
    rsx! {
        document::Stylesheet { href: CSS }
        div { class: "app", dir: "{dir}", lang: "{lang}",
            if token().is_some() {
                tabs::Shell {}
            } else {
                login::Login {}
            }
        }
    }
}
