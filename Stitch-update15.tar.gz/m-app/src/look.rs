//! Profile customisation: name style, avatar decoration, profile effect, profile frame,
//! nameplate, search frame and the app icon. All of them are pure CSS looks picked by number.

use crate::{
    api::{fmt_count, Stats},
    avatar,
    i18n::tr,
    social::BannerView,
    Ctx,
};
use dioxus::prelude::*;
use gloo_storage::{LocalStorage, Storage};

pub const NAME_STYLES: usize = 8;
pub const DECOS: usize = 8;
pub const EFFECTS: usize = 6;
pub const FRAMES: usize = 8;
pub const PLATES: usize = 7;
pub const SEARCH_FRAMES: usize = 6;
pub const ICONS: usize = 6;

/// The five looks other people see on my profile. Sent to the server as "n.a.e.f.p".
#[derive(Clone, Copy, PartialEq, Default, Debug)]
pub struct Look {
    pub name: usize,
    pub deco: usize,
    pub effect: usize,
    pub frame: usize,
    pub plate: usize,
}

impl Look {
    pub fn parse(s: &str) -> Look {
        let v: Vec<usize> = s.split('.').filter_map(|x| x.parse().ok()).collect();
        let get = |i: usize, max: usize| v.get(i).copied().unwrap_or(0).min(max - 1);
        Look {
            name: get(0, NAME_STYLES),
            deco: get(1, DECOS),
            effect: get(2, EFFECTS),
            frame: get(3, FRAMES),
            plate: get(4, PLATES),
        }
    }

    pub fn encode(&self) -> String {
        format!("{}.{}.{}.{}.{}", self.name, self.deco, self.effect, self.frame, self.plate)
    }

    pub fn with(mut self, field: &str, value: usize) -> Look {
        match field {
            "name" => self.name = value,
            "deco" => self.deco = value,
            "effect" => self.effect = value,
            "frame" => self.frame = value,
            _ => self.plate = value,
        }
        self
    }
}

// ---------------------------------------------------------------- app icon

const ICON_COLORS: [(&str, &str, &str); ICONS] = [
    ("e9e9ee", "8b8b96", "111111"),
    ("22222c", "000000", "ffffff"),
    ("a96bff", "3a0a7a", "ffffff"),
    ("ff4fa3", "5a0a38", "ffffff"),
    ("f5c46b", "7a4a05", "1a1203"),
    ("2fe0a0", "03402a", "031a12"),
];

pub fn icon_uri(i: usize) -> String {
    let (a, b, fg) = ICON_COLORS[i.min(ICONS - 1)];
    format!(
        "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='%23{a}'/><stop offset='1' stop-color='%23{b}'/></linearGradient></defs><rect width='64' height='64' rx='16' fill='url(%23g)'/><text x='32' y='47' font-size='42' text-anchor='middle' font-family='serif' font-weight='700' fill='%23{fg}'>S</text></svg>"
    )
}

/// Puts the chosen icon on the browser tab / home-screen shortcut.
pub fn apply_icon(i: usize) {
    let uri = serde_json::to_string(&icon_uri(i)).unwrap_or_default();
    let js = format!(
        "(function(u){{var l=document.querySelector(\"link[rel~='icon']\");if(!l){{l=document.createElement('link');l.rel='icon';document.head.appendChild(l);}}l.href=u;var a=document.querySelector(\"link[rel='apple-touch-icon']\");if(!a){{a=document.createElement('link');a.rel='apple-touch-icon';document.head.appendChild(a);}}a.href=u;}})({uri});"
    );
    let _ = document::eval(&js);
}

pub fn apply_saved_icon() {
    if let Ok(i) = LocalStorage::get::<usize>("m_app_icon") {
        apply_icon(i);
    }
}

// ---------------------------------------------------------------- profile header

/// Banner, avatar, name and bio with the person's chosen decoration, effect, frame and nameplate.
#[component]
pub fn ProfileHeader(
    look: String,
    banner_kind: String,
    banner: i16,
    banner_url: String,
    picture: String,
    name: String,
    sub: String,
    #[props(default)] stats: Option<Stats>,
    #[props(default)] note: String,
) -> Element {
    let lang = use_context::<Ctx>().lang;
    let l = Look::parse(&look);
    let wrap = format!("pf fr{} pe{}", l.frame, l.effect);
    let nm = format!("pf-name ns{}", l.name);
    let plate = format!("pf-plate np{}", l.plate);
    let counts = stats.as_ref().map(|st| [fmt_count(st.posts), fmt_count(st.followers), fmt_count(st.following)]);
    rsx! {
        div { class: "{wrap}",
            div { class: "pf-banner",
                BannerView { kind: banner_kind, preset: banner, url: banner_url }
                if l.frame > 0 { span { class: "fr-layer" } }
            }
            if !note.is_empty() { div { class: "pf-note", span { "{note}" } } }
            AvatarDeco { deco: l.deco, src: picture }
            div { class: "{plate}",
                div { class: "pf-namerow",
                    h2 { class: "{nm}", "{name}" }
                    if stats.as_ref().map(|s| s.verified).unwrap_or(false) { VerifiedBadge {} }
                }
                if let Some(c) = counts {
                    div { class: "pf-counts",
                        span { strong { {c[0].clone()} } small { {tr(&lang(), "posts")} } }
                        span { strong { {c[1].clone()} } small { {tr(&lang(), "followers")} } }
                        span { strong { {c[2].clone()} } small { {tr(&lang(), "following")} } }
                    }
                }
                p { class: "pf-sub", "{sub}" }
            }
        }
    }
}

/// The Trusted verification seal.
#[component]
pub fn VerifiedBadge(#[props(default = 26)] size: u32) -> Element {
    rsx! {
        svg { class: "vbadge", width: "{size}", height: "{size}", view_box: "0 0 24 24", "aria-label": "Trusted",
            defs {
                linearGradient { id: "vbg", x1: "0", y1: "0", x2: "1", y2: "1",
                    stop { offset: "0", stop_color: "#7cc4ff" }
                    stop { offset: "1", stop_color: "#2b6cff" }
                }
            }
            path { d: "M12 1.5l2.6 1.9 3.2-.2 1 3.1 2.6 1.9-1 3.1 1 3.1-2.6 1.9-1 3.1-3.2-.2L12 22.5l-2.6-1.9-3.2.2-1-3.1L2.6 15.8l1-3.1-1-3.1 2.6-1.9 1-3.1 3.2.2z", fill: "url(#vbg)" }
            path { d: "M7.8 12.3l3 3 5.6-5.8", stroke: "#fff", fill: "none", stroke_width: "2.3", stroke_linecap: "round", stroke_linejoin: "round" }
        }
    }
}

// ---------------------------------------------------------------- 3D avatar decoration

/// The avatar with a decoration that really moves in 3D: layers sit at different depths and
/// the whole thing tilts with the pointer / phone motion (see `install_tilt`) and sways on its own.
#[component]
pub fn AvatarDeco(deco: usize, src: String) -> Element {
    rsx! {
        div { class: "av-wrap ad{deco}",
            div { class: "d-sway",
                div { class: "d-tilt",
                    span { class: "d-back" }
                    img { class: "avatar lg pf-avatar", src: "{src}", alt: "" }
                    span { class: "d-front" }
                    span { class: "d-orb o1" }
                    span { class: "d-orb o2" }
                    span { class: "d-orb o3" }
                }
            }
        }
    }
}

/// Feeds pointer position and phone tilt into CSS variables that the 3D layers read.
pub fn install_tilt() {
    let _ = document::eval(
        "(function(){if(window.__stitchTilt)return;window.__stitchTilt=1;var r=document.documentElement;\
function set(x,y){r.style.setProperty('--ry',(x*26)+'deg');r.style.setProperty('--rx',(-y*20)+'deg');}\
addEventListener('pointermove',function(e){set(e.clientX/innerWidth*2-1,e.clientY/innerHeight*2-1);},{passive:true});\
addEventListener('deviceorientation',function(e){if(e.gamma==null)return;set(Math.max(-1,Math.min(1,e.gamma/35)),Math.max(-1,Math.min(1,((e.beta||45)-45)/35)));},{passive:true});})();",
    );
}

// ---------------------------------------------------------------- picker

fn opt_class(kind: &str, on: bool) -> String {
    format!("opt k-{kind}{}", if on { " on" } else { "" })
}

fn preview(kind: &str, i: usize) -> Element {
    match kind {
        "ad" => rsx! { AvatarDeco { deco: i, src: avatar::preset_uri(3) } },
        "fr" => rsx! { span { class: "pv fr{i}", if i > 0 { span { class: "fr-layer" } } } },
        "pe" => rsx! { span { class: "pv pe{i}" } },
        "ic" => rsx! { img { class: "icon-prev", src: "{icon_uri(i)}", alt: "" } },
        "ns" => rsx! { span { class: "ns{i}", "Aa" } },
        "sf" => rsx! { span { class: "pv sf{i}" } },
        "np" => rsx! { span { class: "pv np{i}", "S" } },
        _ => rsx! { span {} },
    }
}

/// A row of small previews; tapping one picks it.
#[component]
pub fn Picker(title: String, kind: &'static str, count: usize, current: usize, onpick: EventHandler<usize>) -> Element {
    rsx! {
        div { class: "pk",
            h3 { class: "section-title", "{title}" }
            div { class: "pk-row",
                for i in 0..count {
                    button {
                        key: "{i}", r#type: "button",
                        class: opt_class(kind, current == i),
                        "aria-label": "{title} {i + 1}",
                        onclick: move |_| onpick.call(i),
                        {preview(kind, i)}
                    }
                }
            }
        }
    }
}
