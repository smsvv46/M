use crate::{
    api::{call, Method, Msg, Peer, Thread},
    avatar,
    i18n::{err_text, tr},
    login::Icon,
    social::{Overlay, ICON_BACK},
    Ctx,
};
use dioxus::prelude::*;
use gloo_storage::{LocalStorage, Storage};
use gloo_timers::future::TimeoutFuture;
use serde_json::json;

const SCROLL_JS: &str = "const e=document.getElementById('msgs');if(e){e.scrollTop=e.scrollHeight;}";
/// Short beep (and optional buzz) for a new incoming message.
fn alert_js() -> String {
    let mut js = String::new();
    if crate::api::get_bool("m_sound", true) {
        js.push_str("try{var a=new (window.AudioContext||window.webkitAudioContext)();var o=a.createOscillator();var g=a.createGain();o.type='sine';o.frequency.value=880;g.gain.value=0.05;o.connect(g);g.connect(a.destination);o.start();setTimeout(function(){o.stop();a.close();},120);}catch(e){}");
    }
    if crate::api::get_bool("m_vibrate", true) {
        js.push_str("try{if(navigator.vibrate)navigator.vibrate(60);}catch(e){}");
    }
    js
}

const ICON_SEND: &str = "M22 2L11 13M22 2l-7 20-4-9-9-4z";

/// "14:05" for today, "21/11" for older messages. Uses the phone's own time zone.
pub fn fmt_time(ts: i64) -> String {
    let d = js_sys::Date::new_0();
    d.set_time(ts as f64 * 1000.0);
    let now = js_sys::Date::new_0();
    let same_day = d.get_full_year() == now.get_full_year() && d.get_month() == now.get_month() && d.get_date() == now.get_date();
    if same_day {
        format!("{:02}:{:02}", d.get_hours(), d.get_minutes())
    } else {
        format!("{}/{}", d.get_date(), d.get_month() + 1)
    }
}

#[component]
fn Bubble(m: Msg, mine: bool, read: bool) -> Element {
    let time = fmt_time(m.ts);
    rsx! {
        div { class: if mine { "bubble mine" } else { "bubble" },
            span { class: "bubble-text", "{m.body}" }
            span { class: "bubble-meta",
                "{time}"
                if mine {
                    span { class: if read { "tick read" } else { "tick" },
                        if read { "✓✓" } else { "✓" }
                    }
                }
            }
        }
    }
}

/// One-to-one conversation. New messages arrive by asking the server every two seconds.
#[component]
pub fn ChatScreen(id: String, mut overlay: Signal<Overlay>) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let user = ctx.user;
    let me = user().map(|u| u.id).unwrap_or_default();

    let mut peer = use_signal(|| None::<Peer>);
    let mut msgs = use_signal(Vec::<Msg>::new);
    let mut receipt = use_signal(|| 0i64);
    let mut last_id = use_signal(|| 0i64);
    let mut draft = use_signal(String::new);
    let mut note = use_signal(String::new);
    let theme = LocalStorage::get::<usize>("m_chat_theme").unwrap_or(0);

    let poll_id = id.clone();
    let poll_me = me.clone();
    use_hook(move || {
        spawn(async move {
            loop {
                let path = format!("/chats/{poll_id}/messages?after={}", last_id());
                if let Ok(v) = call(Method::GET, &path, None, token()).await {
                    if let Ok(t) = serde_json::from_value::<Thread>(v) {
                        peer.set(Some(t.peer));
                        receipt.set(t.peer_receipt);
                        if !t.messages.is_empty() {
                            let incoming = t.messages.iter().any(|m| m.sender_id != poll_me);
                            let newest = t.messages.iter().map(|m| m.id).max().unwrap_or(0);
                            let first_load = last_id() == 0;
                            let mut fresh: Vec<Msg> = Vec::new();
                            {
                                let have = msgs.read();
                                for m in t.messages {
                                    if !have.iter().any(|x| x.id == m.id) {
                                        fresh.push(m);
                                    }
                                }
                            }
                            msgs.write().extend(fresh);
                            if newest > last_id() {
                                last_id.set(newest);
                            }
                            if incoming && !first_load {
                                let js = alert_js();
                                if !js.is_empty() {
                                    let _ = document::eval(&js);
                                }
                            }
                            if incoming {
                                let _ = call(Method::POST, &format!("/chats/{poll_id}/read"), None, token()).await;
                            }
                        }
                    }
                }
                TimeoutFuture::new(crate::api::poll_ms(3000)).await;
            }
        });
    });

    use_effect(move || {
        let _ = msgs.read().len();
        let _ = document::eval(SCROLL_JS);
    });

    let send_conv = id.clone();
    let on_submit = move |e: FormEvent| {
        e.prevent_default();
        let text = draft().trim().to_string();
        if text.is_empty() {
            return;
        }
        draft.set(String::new());
        let c = send_conv.clone();
        spawn(async move {
            match call(Method::POST, &format!("/chats/{c}/messages"), Some(json!({ "body": text.clone() })), token()).await {
                Ok(v) => {
                    if let Ok(m) = serde_json::from_value::<Msg>(v) {
                        let known = msgs.read().iter().any(|x| x.id == m.id);
                        if !known {
                            msgs.write().push(m);
                        }
                    }
                    note.set(String::new());
                }
                Err(e) => {
                    note.set(err_text(&lang(), &e));
                    draft.set(text);
                }
            }
        });
    };

    let back_label = tr(&lang(), "back");
    let ph = tr(&lang(), "type_message");
    let send_label = tr(&lang(), "send");

    rsx! {
        div { class: "chat-screen ct{theme}",
            header { class: "chat-head",
                button {
                    class: "icon-btn", r#type: "button", "aria-label": "{back_label}",
                    onclick: move |_| overlay.set(Overlay::None),
                    Icon { d: ICON_BACK }
                }
                match peer() {
                    Some(p) => {
                        let pid = p.id.clone();
                        let seen_text = p.last_seen.map(|ts| format!("{} {}", tr(&lang(), "last_seen_at"), fmt_time(ts)));
                        rsx! {
                            button {
                                class: "chat-peer", r#type: "button",
                                onclick: move |_| overlay.set(Overlay::Profile(pid.clone())),
                                img { class: "avatar sm", src: "{avatar::user_uri(&p.avatar_kind, &p.avatar_value)}", alt: "" }
                                div { class: "chat-main",
                                    div { class: "chat-name", "{p.name}" if p.verified { crate::look::VerifiedBadge { size: 16 } } }
                                    if p.online {
                                        div { class: "chat-sub online", {tr(&lang(), "online")} }
                                    } else if let Some(seen_text) = seen_text.clone() {
                                        div { class: "chat-sub", "{seen_text}" }
                                    }
                                }
                            }
                        }
                    },
                    None => rsx! { div { class: "chat-peer" } },
                }
            }

            div { id: "msgs", class: "msgs",
                if msgs().is_empty() {
                    p { class: "hint center-text", {tr(&lang(), "no_messages")} }
                }
                for m in msgs() {
                    Bubble { key: "{m.id}", m: m.clone(), mine: m.sender_id == me, read: m.id <= receipt() }
                }
            }

            if !note().is_empty() {
                p { class: "note err center-text", role: "status", "{note}" }
            }
            form { class: "composer", onsubmit: on_submit,
                input {
                    class: "composer-input", r#type: "text", autocomplete: "off", placeholder: "{ph}",
                    value: "{draft}", oninput: move |e| draft.set(e.value()),
                }
                button { class: "send-btn", r#type: "submit", "aria-label": "{send_label}", Icon { d: ICON_SEND } }
            }
        }
    }
}
