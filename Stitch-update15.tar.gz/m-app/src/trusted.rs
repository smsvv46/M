//! Trusted verification: who gets the badge, and buying it with a card.

use crate::{
    api::{call, Method, Stats},
    i18n::{err_text, tr},
    login::Icon,
    look::VerifiedBadge,
    social::ICON_BACK,
    Ctx,
};
use dioxus::prelude::*;
use serde_json::json;

fn date_of(ts: i64) -> String {
    js_sys::eval(&format!("new Date({ts}*1000).toLocaleDateString()"))
        .ok()
        .and_then(|v| v.as_string())
        .unwrap_or_default()
}

/// A simple page for features that are not open yet (Nitro, Shop).
#[component]
pub fn SoonPage(title: &'static str, back: EventHandler<()>) -> Element {
    let lang = use_context::<Ctx>().lang;
    rsx! {
        header { class: "bar",
            button { class: "icon-btn", r#type: "button", "aria-label": tr(&lang(), "back"), onclick: move |_| back.call(()), Icon { d: ICON_BACK } }
            h2 { class: "bar-title", {tr(&lang(), title)} }
        }
        section { class: "card",
            p { class: "hint center-text", {tr(&lang(), "soon")} }
        }
    }
}

#[component]
pub fn TrustedPage(stats: Signal<Option<Stats>>, back: EventHandler<()>) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let mut stats = stats;
    let mut busy = use_signal(|| false);
    let mut note = use_signal(String::new);

    // While this page is open, look for the bank's confirmation every few seconds.
    use_hook(move || {
        spawn(async move {
            loop {
                gloo_timers::future::TimeoutFuture::new(5_000).await;
                if let Ok(v) = call(Method::GET, "/me/stats", None, token()).await {
                    stats.set(serde_json::from_value(v).ok());
                }
            }
        });
    });

    let pay = move |plan: &'static str| {
        spawn(async move {
            busy.set(true);
            note.set(String::new());
            match call(Method::POST, "/verify/checkout", Some(json!({ "plan": plan })), token()).await {
                Ok(v) => {
                    if let Some(url) = v["url"].as_str() {
                        let u = serde_json::to_string(url).unwrap_or_default();
                        let _ = js_sys::eval(&format!("window.location.assign({u})"));
                    }
                }
                Err(e) => note.set(err_text(&lang(), &e)),
            }
            busy.set(false);
        });
    };
    let check = move |_| {
        spawn(async move {
            if let Ok(v) = call(Method::GET, "/me/stats", None, token()).await {
                stats.set(serde_json::from_value(v).ok());
            }
        });
    };

    let st = stats().unwrap_or_default();
    let status = match (st.verified, st.verified_kind.as_deref()) {
        (true, Some("celebrity")) => tr(&lang(), "trusted_celebrity"),
        (true, Some("popular")) => tr(&lang(), "trusted_popular"),
        (true, _) => {
            let until = st.verified_until.map(date_of).unwrap_or_default();
            format!("{} {until}", tr(&lang(), "trusted_until"))
        }
        _ => tr(&lang(), "trusted_none"),
    };
    let plans = [("m3", "plan_3m", "500"), ("y1", "plan_1y", "1500")];

    rsx! {
        header { class: "bar",
            button { class: "icon-btn", r#type: "button", "aria-label": tr(&lang(), "back"), onclick: move |_| back.call(()), Icon { d: ICON_BACK } }
            h2 { class: "bar-title", {tr(&lang(), "trusted_title")} }
        }
        section { class: "card tr-hero",
            VerifiedBadge { size: 64 }
            p { class: "tr-status", "{status}" }
            p { class: "hint", {tr(&lang(), "trusted_sub")} }
            p { class: "hint", {tr(&lang(), "trusted_who")} }
        }
        for (id, label, price) in plans {
            section { key: "{id}", class: "card tr-plan",
                div { class: "grow",
                    strong { {tr(&lang(), label)} }
                    small { "{price} " {tr(&lang(), "egp")} }
                }
                button { class: "silver small", r#type: "button", disabled: busy(), onclick: move |_| pay(id), {tr(&lang(), "pay_card")} }
            }
        }
        p { class: "hint", {tr(&lang(), "pay_note")} }
        if !note().is_empty() { p { class: "note err", role: "status", "{note}" } }
        button { class: "chip-btn tr-check", r#type: "button", onclick: check, {tr(&lang(), "check_status")} }
    }
}
