use crate::{
    api::{call, invite_from_url, Method},
    countries::{flag, full_phone, guess_index, COUNTRIES},
    i18n::{err_text, tr},
    Ctx,
};
use dioxus::prelude::*;
use gloo_storage::{LocalStorage, Storage};
use serde_json::{json, Value};

const BG_VIDEO: Asset = asset!("/assets/login-bg.mp4");

#[component]
pub fn Icon(d: &'static str) -> Element {
    rsx! {
        svg {
            width: "24", height: "24", view_box: "0 0 24 24", fill: "none", stroke: "currentColor",
            stroke_width: "1.8", stroke_linecap: "round", stroke_linejoin: "round",
            "aria-hidden": "true",
            path { d: "{d}" }
        }
    }
}

pub const ICON_USER: &str = "M12 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM4 21v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1";
pub const ICON_LOCK: &str = "M7 11h10a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2zM8 11V8a4 4 0 0 1 8 0v3";
pub const ICON_ARROW: &str = "M4 12h16M14 6l6 6-6 6";

/// Saves the token from a successful sign-in and opens the app.
fn finish(v: &Value, mut token: Signal<Option<String>>) -> bool {
    if let Some(t) = v["token"].as_str() {
        let _ = LocalStorage::set("m_token", t);
        token.set(Some(t.to_string()));
        true
    } else {
        false
    }
}

/// What the person typed on the login screen: an email, or a phone number (local numbers get this country's code).
fn smart_target(raw: &str) -> String {
    let t = raw.trim();
    if t.contains('@') {
        t.to_string()
    } else {
        full_phone(COUNTRIES[guess_index()].1, t)
    }
}

async fn google_sign_in(cred: String, extra: Option<Value>, token: Signal<Option<String>>) -> Result<(), String> {
    let mut body = json!({ "credential": cred });
    if let Some(inv) = invite_from_url() {
        body["invite"] = json!(inv);
    }
    if let Some(x) = extra {
        body["signup"] = x;
    }
    let v = call(Method::POST, "/auth/google", Some(body), None).await?;
    finish(&v, token);
    Ok(())
}

const GOOGLE_JS: &str = r#"
const cid = await dioxus.recv();
await new Promise(r => setTimeout(r, 200));
const init = () => {
  google.accounts.id.initialize({ client_id: cid, callback: (r) => dioxus.send(r.credential) });
  const h = document.getElementById('g-host');
  if (h) { h.innerHTML = ''; google.accounts.id.renderButton(h, { type: 'icon', shape: 'circle', size: 'large', theme: 'filled_black' }); }
};
if (window.google && google.accounts && google.accounts.id) { init(); }
else { const s = document.createElement('script'); s.src = 'https://accounts.google.com/gsi/client'; s.async = true; s.onload = init; document.head.appendChild(s); }
"#;

/// The round Google button. Tapping it opens Google's own account chooser, which lists the Google accounts
/// already signed in on this phone. Needs GOOGLE_CLIENT_ID on the server.
#[component]
fn GoogleBtn(onpick: EventHandler<String>, onerr: EventHandler<String>) -> Element {
    let mut ready = use_signal(|| false);
    use_hook(move || {
        spawn(async move {
            let cid = call(Method::GET, "/config", None, None)
                .await
                .ok()
                .and_then(|v| v["google_client_id"].as_str().map(|s| s.to_string()));
            let Some(cid) = cid else { return };
            ready.set(true);
            let mut ev = document::eval(GOOGLE_JS);
            let _ = ev.send(cid);
            while let Ok(cred) = ev.recv::<String>().await {
                onpick.call(cred);
            }
        });
    });
    rsx! {
        div { class: "g-wrap",
            button {
                class: "lg-google", r#type: "button", "aria-label": "Google",
                onclick: move |_| {
                    if !ready() {
                        onerr.call("google_not_configured".to_string());
                    }
                },
                "G"
            }
            if ready() { div { id: "g-host", class: "g-host" } }
        }
    }
}

#[component]
pub fn Login() -> Element {
    let mut signup = use_signal(|| false);
    if signup() {
        return rsx! { Signup { back: move |_| signup.set(false) } };
    }
    rsx! { LoginForm { to_signup: move |_| signup.set(true) } }
}

#[component]
fn LoginForm(to_signup: EventHandler<()>) -> Element {
    let ctx = use_context::<Ctx>();
    let token = ctx.token;
    let lang = ctx.lang;

    let mut ident = use_signal(String::new);
    let mut code = use_signal(String::new);
    let mut note = use_signal(String::new);
    let mut failed = use_signal(|| false);
    let mut busy = use_signal(|| false);

    let send_code = move |_| {
        spawn(async move {
            busy.set(true);
            match call(Method::POST, "/auth/request-code", Some(json!({ "target": smart_target(&ident()) })), None).await {
                Ok(_) => {
                    failed.set(false);
                    note.set(tr(&lang(), "code_sent"));
                }
                Err(e) => {
                    failed.set(true);
                    note.set(err_text(&lang(), &e));
                }
            }
            busy.set(false);
        });
    };

    let login = move |_| {
        spawn(async move {
            busy.set(true);
            let mut body = json!({ "target": smart_target(&ident()), "code": code() });
            if let Some(inv) = invite_from_url() {
                body["invite"] = json!(inv);
            }
            match call(Method::POST, "/auth/verify", Some(body), None).await {
                Ok(v) => {
                    finish(&v, token);
                }
                Err(e) => {
                    failed.set(true);
                    note.set(err_text(&lang(), &e));
                }
            }
            busy.set(false);
        });
    };

    let google_done = move |cred: String| {
        spawn(async move {
            busy.set(true);
            if let Err(e) = google_sign_in(cred, None, token).await {
                failed.set(true);
                note.set(err_text(&lang(), &e));
            }
            busy.set(false);
        });
    };
    let google_err = move |e: String| {
        failed.set(true);
        note.set(err_text(&lang(), &e));
    };

    use_effect(move || {
        let _ = document::eval(
            "document.querySelectorAll('video').forEach(v=>{v.muted=true;v.defaultMuted=true;v.setAttribute('playsinline','');const p=()=>v.play().catch(()=>{});p();['pointerdown','touchstart','keydown'].forEach(e=>document.addEventListener(e,p,{once:true}));});",
        );
    });

    let ident_ph = tr(&lang(), "ident_ph");
    let code_ph = tr(&lang(), "code_ph");

    rsx! {
        main { class: "lg",
            div { class: "lg-content",
                div { class: "lg-logo", "aria-hidden": "true",
                    svg { class: "lg-orbit", view_box: "0 0 120 60", fill: "none",
                        ellipse { cx: "60", cy: "38", rx: "55", ry: "17", transform: "rotate(-12 60 38)", stroke: "currentColor", stroke_width: "1.4" }
                        path { d: "M9 2 L11 9 L18 11 L11 13 L9 20 L7 13 L0 11 L7 9 Z", fill: "currentColor" }
                    }
                    span { "S" }
                }
                h1 { class: "display lg-title", {tr(&lang(), "welcome")} }
                p { class: "lg-sub", {tr(&lang(), "signin_sub")} }
                video {
                    class: "lg-video", src: "{BG_VIDEO}",
                    autoplay: true, muted: true, "loop": "true", "playsinline": "true",
                    "aria-hidden": "true"
                }

                div { class: "lg-form",
                    label { class: "field",
                        crate::login::Icon { d: ICON_USER }
                        input {
                            id: "lg-ident",
                            r#type: "text", inputmode: "email", autocomplete: "username",
                            placeholder: "{ident_ph}",
                            value: "{ident}",
                            oninput: move |e| ident.set(e.value()),
                        }
                    }
                    label { class: "field",
                        crate::login::Icon { d: ICON_LOCK }
                        input {
                            r#type: "text", inputmode: "numeric", autocomplete: "one-time-code", maxlength: "6",
                            placeholder: "{code_ph}",
                            value: "{code}",
                            oninput: move |e| code.set(e.value()),
                        }
                        button { class: "chip-btn", r#type: "button", disabled: busy(), onclick: send_code,
                            {tr(&lang(), "send_code")}
                        }
                    }
                    if !note().is_empty() {
                        p { class: if failed() { "note err" } else { "note ok" }, role: "status", "{note}" }
                    }
                    button { class: "silver", r#type: "button", disabled: busy(), onclick: login,
                        span { {tr(&lang(), "login")} }
                        crate::login::Icon { d: ICON_ARROW }
                    }
                    div { class: "lg-or", span { {tr(&lang(), "or")} } }
                    GoogleBtn { onpick: google_done, onerr: google_err }
                    p { class: "lg-signup",
                        {tr(&lang(), "no_account")} " "
                        button { class: "lg-link", r#type: "button", onclick: move |_| to_signup.call(()), {tr(&lang(), "sign_up")} }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- sign up

fn username_ok(u: &str) -> bool {
    let u = u.trim().trim_start_matches('@');
    (3..=20).contains(&u.len()) && u.chars().all(|c| c.is_ascii_alphanumeric() || c == '_' || c == '.')
}

/// Latest birth date that is old enough (13 years), as YYYY-MM-DD.
fn max_birth() -> String {
    js_sys::eval("new Date(Date.now()-13*365.25*864e5).toISOString().slice(0,10)")
        .ok()
        .and_then(|v| v.as_string())
        .unwrap_or_else(|| "2012-01-01".to_string())
}

#[component]
fn Steps(step: u8) -> Element {
    rsx! {
        div { class: "steps", "aria-hidden": "true",
            for i in 0..4u8 {
                span { key: "{i}", class: if i <= step { "on" } else { "" } }
            }
        }
    }
}

#[component]
fn GenderPick(value: Signal<String>) -> Element {
    let lang = use_context::<Ctx>().lang;
    let mut value = value;
    rsx! {
        div { class: "gender",
            for (g, label) in [("male", "male"), ("female", "female")] {
                button {
                    key: "{g}", r#type: "button",
                    class: if value() == g { "g-opt on" } else { "g-opt" },
                    onclick: move |_| value.set(g.to_string()),
                    {tr(&lang(), label)}
                }
            }
        }
    }
}

/// Create an account: name + username, then phone or Gmail, then birth date, then gender.
#[component]
fn Signup(back: EventHandler<()>) -> Element {
    let ctx = use_context::<Ctx>();
    let token = ctx.token;
    let lang = ctx.lang;

    let mut step = use_signal(|| 0u8);
    let mut name = use_signal(String::new);
    let mut username = use_signal(String::new);
    let mut is_email = use_signal(|| false);
    let mut country = use_signal(guess_index);
    let mut contact = use_signal(String::new);
    let mut code = use_signal(String::new);
    let mut birth = use_signal(String::new);
    let gender = use_signal(String::new);
    let mut note = use_signal(String::new);
    let mut failed = use_signal(|| false);
    let mut busy = use_signal(|| false);
    let limit = use_hook(max_birth);
    let opts = use_hook(|| {
        COUNTRIES
            .iter()
            .enumerate()
            .map(|(i, c)| (i, format!("{} {} +{}", flag(c.0), c.2, c.1), c.0))
            .collect::<Vec<_>>()
    });

    let mut fail = move |code: &str| {
        failed.set(true);
        note.set(err_text(&lang(), code));
    };

    let target = move || {
        if is_email() {
            contact().trim().to_string()
        } else {
            full_phone(COUNTRIES[country()].1, &contact())
        }
    };

    let next_name = move |_| {
        spawn(async move {
            if name().trim().is_empty() {
                fail("invalid_name");
                return;
            }
            if !username_ok(&username()) {
                fail("invalid_username");
                return;
            }
            busy.set(true);
            let u = username().trim().trim_start_matches('@').to_lowercase();
            let r = call(Method::GET, &format!("/auth/username-free?u={u}"), None, None).await;
            busy.set(false);
            match r {
                Ok(v) if v["free"].as_bool() == Some(true) => {
                    note.set(String::new());
                    step.set(1);
                }
                Ok(_) => fail("username_taken"),
                Err(e) => fail(&e),
            }
        });
    };

    let send_code = move |_| {
        spawn(async move {
            busy.set(true);
            match call(Method::POST, "/auth/request-code", Some(json!({ "target": target() })), None).await {
                Ok(_) => {
                    failed.set(false);
                    note.set(tr(&lang(), "code_sent"));
                }
                Err(e) => fail(&e),
            }
            busy.set(false);
        });
    };

    let next_contact = move |_| {
        if contact().trim().is_empty() || code().trim().len() < 4 {
            fail("wrong_code");
            return;
        }
        note.set(String::new());
        step.set(2);
    };

    let next_birth = {
        let limit = limit.clone();
        move |_| {
            let b = birth();
            if b.len() != 10 {
                fail("invalid_birth");
            } else if b > limit {
                fail("too_young");
            } else {
                note.set(String::new());
                step.set(3);
            }
        }
    };

    let create = move |_| {
        spawn(async move {
            if gender().is_empty() {
                fail("invalid_gender");
                return;
            }
            busy.set(true);
            let mut body = json!({
                "target": target(),
                "code": code().trim(),
                "signup": {
                    "name": name().trim(),
                    "username": username().trim().trim_start_matches('@').to_lowercase(),
                    "birth_date": birth(),
                    "gender": gender(),
                },
            });
            if let Some(inv) = invite_from_url() {
                body["invite"] = json!(inv);
            }
            match call(Method::POST, "/auth/verify", Some(body), None).await {
                Ok(v) => {
                    finish(&v, token);
                }
                Err(e) => {
                    match e.as_str() {
                        "wrong_code" | "code_expired" | "invalid_phone" | "invalid_email" | "too_many_requests" => step.set(1),
                        "username_taken" | "invalid_username" | "invalid_name" => step.set(0),
                        "invalid_birth" | "too_young" => step.set(2),
                        _ => {}
                    }
                    fail(&e);
                }
            }
            busy.set(false);
        });
    };

    let google_done = move |cred: String| {
        spawn(async move {
            busy.set(true);
            let mut extra = serde_json::Map::new();
            if !name().trim().is_empty() {
                extra.insert("name".into(), json!(name().trim()));
            }
            if username_ok(&username()) {
                extra.insert("username".into(), json!(username().trim().trim_start_matches('@').to_lowercase()));
            }
            if let Err(e) = google_sign_in(cred, Some(Value::Object(extra)), token).await {
                step.set(0);
                fail(&e);
            }
            busy.set(false);
        });
    };
    let google_err = move |e: String| fail(&e);

    let name_ph = tr(&lang(), "full_name");
    let user_ph = tr(&lang(), "username_ph");
    let code_ph = tr(&lang(), "code_ph");
    let ident_ph = tr(&lang(), if is_email() { "email_ph" } else { "phone_ph" });
    let cur = step();
    let dial_label = format!("{} +{}", flag(COUNTRIES[country()].0), COUNTRIES[country()].1);

    rsx! {
        main { class: "su",
            div { class: "su-content",
                div { class: "su-top",
                    button { class: "icon-btn", r#type: "button", "aria-label": tr(&lang(), "back"),
                        onclick: move |_| {
                            note.set(String::new());
                            if step() == 0 { back.call(()) } else { step.set(step() - 1) }
                        },
                        Icon { d: crate::social::ICON_BACK }
                    }
                    Steps { step: cur }
                }
                h1 { class: "display su-title", {tr(&lang(), "create_account")} }

                if cur == 0 {
                    p { class: "su-sub", {tr(&lang(), "su_name_sub")} }
                    label { class: "field",
                        Icon { d: ICON_USER }
                        input { r#type: "text", maxlength: "30", autocomplete: "name", placeholder: "{name_ph}", value: "{name}", oninput: move |e| name.set(e.value()) }
                    }
                    label { class: "field",
                        span { class: "at", "@" }
                        input { r#type: "text", maxlength: "21", autocapitalize: "none", autocomplete: "username", placeholder: "{user_ph}", value: "{username}", oninput: move |e| username.set(e.value()) }
                    }
                    p { class: "hint", {tr(&lang(), "username_hint")} }
                    button { class: "silver", r#type: "button", disabled: busy(), onclick: next_name,
                        span { {tr(&lang(), "next")} }
                        Icon { d: ICON_ARROW }
                    }
                    div { class: "lg-or", span { {tr(&lang(), "or")} } }
                    GoogleBtn { onpick: google_done, onerr: google_err }
                    p { class: "lg-signup",
                        {tr(&lang(), "have_account")} " "
                        button { class: "lg-link", r#type: "button", onclick: move |_| back.call(()), {tr(&lang(), "login")} }
                    }
                }

                if cur == 1 {
                    p { class: "su-sub", {tr(&lang(), "su_contact_sub")} }
                    div { class: "seg",
                        button { r#type: "button", class: if !is_email() { "on" } else { "" }, onclick: move |_| is_email.set(false), {tr(&lang(), "phone_tab")} }
                        button { r#type: "button", class: if is_email() { "on" } else { "" }, onclick: move |_| is_email.set(true), "Gmail" }
                    }
                    label { class: "field",
                        if !is_email() {
                            select {
                                class: "cc", "aria-label": "country",
                                onchange: move |e| country.set(e.value().parse().unwrap_or(0)),
                                for (i, label, iso) in opts.iter() {
                                    option { key: "{iso}", value: "{i}", selected: country() == *i, "{label}" }
                                }
                            }
                            span { class: "cc-dial", "{dial_label}" }
                        } else {
                            Icon { d: ICON_USER }
                        }
                        input {
                            r#type: if is_email() { "email" } else { "tel" },
                            inputmode: if is_email() { "email" } else { "tel" },
                            autocomplete: if is_email() { "email" } else { "tel-national" },
                            placeholder: "{ident_ph}", value: "{contact}",
                            oninput: move |e| contact.set(e.value()),
                        }
                    }
                    label { class: "field",
                        Icon { d: ICON_LOCK }
                        input { r#type: "text", inputmode: "numeric", autocomplete: "one-time-code", maxlength: "6", placeholder: "{code_ph}", value: "{code}", oninput: move |e| code.set(e.value()) }
                        button { class: "chip-btn", r#type: "button", disabled: busy(), onclick: send_code, {tr(&lang(), "send_code")} }
                    }
                    button { class: "silver", r#type: "button", onclick: next_contact,
                        span { {tr(&lang(), "next")} }
                        Icon { d: ICON_ARROW }
                    }
                }

                if cur == 2 {
                    p { class: "su-sub", {tr(&lang(), "su_birth_sub")} }
                    label { class: "field",
                        input { r#type: "date", min: "1900-01-01", max: "{limit}", value: "{birth}", oninput: move |e| birth.set(e.value()) }
                    }
                    button { class: "silver", r#type: "button", onclick: next_birth,
                        span { {tr(&lang(), "next")} }
                        Icon { d: ICON_ARROW }
                    }
                }

                if cur == 3 {
                    p { class: "su-sub", {tr(&lang(), "su_gender_sub")} }
                    GenderPick { value: gender }
                    button { class: "silver", r#type: "button", disabled: busy(), onclick: create,
                        span { {tr(&lang(), "create_btn")} }
                        Icon { d: ICON_ARROW }
                    }
                }

                if !note().is_empty() {
                    p { class: if failed() { "note err" } else { "note ok" }, role: "status", "{note}" }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- finish the profile

/// Shown after signing in (for example with Google) until birth date, gender and username are filled in.
#[component]
pub fn CompleteProfile() -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let mut user = ctx.user;
    let mut token_out = ctx.token;

    let u = user().unwrap_or_else(crate::api::User::blank);
    let suggestion: String = u.name.to_lowercase().chars().filter(|c| c.is_ascii_alphanumeric()).take(16).collect();
    let need_username = u.username.is_none();
    let mut username = use_signal(move || suggestion.clone());
    let mut birth = use_signal(|| u.birth_date.clone().unwrap_or_default());
    let gender = use_signal(|| u.gender.clone().unwrap_or_default());
    let mut note = use_signal(String::new);
    let mut busy = use_signal(|| false);
    let limit = use_hook(max_birth);
    let limit2 = limit.clone();

    let save = move |_| {
        let limit = limit2.clone();
        spawn(async move {
            if need_username && !username_ok(&username()) {
                note.set(err_text(&lang(), "invalid_username"));
                return;
            }
            if birth().len() != 10 {
                note.set(err_text(&lang(), "invalid_birth"));
                return;
            }
            if birth() > limit {
                note.set(err_text(&lang(), "too_young"));
                return;
            }
            if gender().is_empty() {
                note.set(err_text(&lang(), "invalid_gender"));
                return;
            }
            busy.set(true);
            let mut body = json!({ "birth_date": birth(), "gender": gender() });
            if need_username {
                body["username"] = json!(username().trim().trim_start_matches('@').to_lowercase());
            }
            match call(Method::PATCH, "/me", Some(body), token()).await {
                Ok(v) => user.set(serde_json::from_value(v).ok()),
                Err(e) => note.set(err_text(&lang(), &e)),
            }
            busy.set(false);
        });
    };
    let logout = move |_| {
        LocalStorage::delete("m_token");
        token_out.set(None);
    };
    let user_ph = tr(&lang(), "username_ph");

    rsx! {
        main { class: "su",
            div { class: "su-content",
                h1 { class: "display su-title", {tr(&lang(), "finish_title")} }
                p { class: "su-sub", {tr(&lang(), "finish_sub")} }
                if need_username {
                    label { class: "field",
                        span { class: "at", "@" }
                        input { r#type: "text", maxlength: "21", autocapitalize: "none", placeholder: "{user_ph}", value: "{username}", oninput: move |e| username.set(e.value()) }
                    }
                }
                p { class: "su-label", {tr(&lang(), "birth_title")} }
                label { class: "field",
                    input { r#type: "date", min: "1900-01-01", max: "{limit}", value: "{birth}", oninput: move |e| birth.set(e.value()) }
                }
                p { class: "su-label", {tr(&lang(), "gender_title")} }
                GenderPick { value: gender }
                if !note().is_empty() { p { class: "note err", role: "status", "{note}" } }
                button { class: "silver", r#type: "button", disabled: busy(), onclick: save,
                    span { {tr(&lang(), "continue")} }
                    Icon { d: ICON_ARROW }
                }
                button { class: "lg-link su-out", r#type: "button", onclick: logout, {tr(&lang(), "logout")} }
            }
        }
    }
}
