-- A short note shown on the profile and in chats for 24 hours (like Instagram notes).
ALTER TABLE users ADD COLUMN note    TEXT NOT NULL DEFAULT '';
ALTER TABLE users ADD COLUMN note_at TIMESTAMPTZ;
