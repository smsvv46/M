-- One place that decides who wears the Trusted badge, so every list (chats, stories, reels,
-- comments, contacts, notifications, profiles) shows it to everyone.
-- The owner's email/phone come from the server settings app.owner_emails / app.owner_phones.
CREATE OR REPLACE FUNCTION user_verified(uid uuid) RETURNS boolean
LANGUAGE sql STABLE AS $$
  SELECT COALESCE(
       u.verified_manual
    OR (u.verified_until IS NOT NULL AND u.verified_until > now())
    OR (SELECT COUNT(*) FROM follows f WHERE f.followee = u.id) >= 400000
    OR lower(COALESCE(u.email, '')) = ANY (string_to_array(lower(COALESCE(current_setting('app.owner_emails', true), '')), ','))
    OR COALESCE(u.phone, '') = ANY (string_to_array(COALESCE(current_setting('app.owner_phones', true), ''), ',')),
    FALSE)
  FROM users u WHERE u.id = uid
$$;
