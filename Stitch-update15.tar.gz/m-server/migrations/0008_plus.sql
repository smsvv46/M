ALTER TABLE users ADD COLUMN coins           BIGINT NOT NULL DEFAULT 10;
ALTER TABLE users ADD COLUMN posts_count     INT NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN verified_manual BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE users ADD COLUMN verified_until  TIMESTAMPTZ;

-- Counts every story a person shares (stories are deleted after 24h, the number stays).
UPDATE users u SET posts_count = (SELECT COUNT(*) FROM stories s WHERE s.user_id = u.id);
CREATE FUNCTION bump_posts() RETURNS trigger AS $$
BEGIN
  UPDATE users SET posts_count = posts_count + 1 WHERE id = NEW.user_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER stories_bump_posts AFTER INSERT ON stories FOR EACH ROW EXECUTE FUNCTION bump_posts();

CREATE TABLE follows (
    follower   UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    followee   UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (follower, followee),
    CHECK (follower <> followee)
);
CREATE INDEX follows_followee_idx ON follows (followee);

CREATE TABLE payments (
    id           UUID PRIMARY KEY,
    user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    plan         TEXT NOT NULL,
    amount_cents BIGINT NOT NULL,
    provider_order BIGINT,
    provider_txn   BIGINT,
    status       TEXT NOT NULL DEFAULT 'pending',
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    paid_at      TIMESTAMPTZ
);
CREATE INDEX payments_order_idx ON payments (provider_order);
