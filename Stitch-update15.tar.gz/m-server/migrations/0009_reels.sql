ALTER TABLE user_settings ADD COLUMN account_private BOOLEAN NOT NULL DEFAULT FALSE;

CREATE TABLE follow_requests (
    requester  UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    target     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (requester, target),
    CHECK (requester <> target)
);
CREATE INDEX follow_requests_target_idx ON follow_requests (target);

CREATE TABLE reels (
    id          UUID PRIMARY KEY,
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    media_url   TEXT NOT NULL,
    caption     TEXT NOT NULL DEFAULT '',
    repost_of   UUID REFERENCES reels(id) ON DELETE SET NULL,
    repost_name TEXT NOT NULL DEFAULT '',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX reels_created_idx ON reels (created_at DESC);
CREATE INDEX reels_user_idx ON reels (user_id, created_at DESC);
CREATE INDEX reels_repost_idx ON reels (repost_of);
CREATE TRIGGER reels_bump_posts AFTER INSERT ON reels FOR EACH ROW EXECUTE FUNCTION bump_posts();

CREATE TABLE reel_likes (
    reel_id    UUID NOT NULL REFERENCES reels(id) ON DELETE CASCADE,
    user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (reel_id, user_id)
);

CREATE TABLE reel_comments (
    id         BIGSERIAL PRIMARY KEY,
    reel_id    UUID NOT NULL REFERENCES reels(id) ON DELETE CASCADE,
    user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    body       TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX reel_comments_idx ON reel_comments (reel_id, id DESC);

-- kind: like, comment, mention, tag, repost, follow_request, follow, follow_back, follow_accept
CREATE TABLE notifications (
    id         BIGSERIAL PRIMARY KEY,
    user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    kind       TEXT NOT NULL,
    actor_id   UUID REFERENCES users(id) ON DELETE CASCADE,
    reel_id    UUID REFERENCES reels(id) ON DELETE CASCADE,
    text       TEXT NOT NULL DEFAULT '',
    read       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX notifications_user_idx ON notifications (user_id, id DESC);
