//! Followers, the Trusted verification badge (celebrities, 400k followers, or paid) and LIXO coins.

use axum::{
    extract::{Path, Query, State},
    http::{HeaderMap, StatusCode},
    Json,
};
use hmac::{Hmac, Mac};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sha2::Sha512;
use sqlx::FromRow;
use std::collections::HashMap;
use uuid::Uuid;

use crate::{auth::AuthUser, error::AppError, AppState};

type Res<T> = Result<T, AppError>;

/// Followers needed for the badge to appear on its own.
pub const POPULAR_FOLLOWERS: i64 = 400_000;

/// (plan id, months, price in EGP). The server decides the price, never the app.
const PLANS: [(&str, i32, i64); 2] = [("m3", 3, 500), ("y1", 12, 1500)];

#[derive(FromRow)]
struct StatsRow {
    followers: i64,
    following: i64,
    posts: i64,
    coins: i64,
    verified_until: Option<i64>,
    manual: bool,
    paid: bool,
    i_follow: bool,
}

#[derive(Serialize)]
pub struct Stats {
    followers: i64,
    following: i64,
    posts: i64,
    verified: bool,
    /// "celebrity", "popular" (400k followers) or "paid"
    verified_kind: Option<String>,
    verified_until: Option<i64>,
    coins: Option<i64>,
    i_follow: bool,
}

async fn stats_for(db: &sqlx::PgPool, target: Uuid, viewer: Uuid) -> Res<Stats> {
    let r = sqlx::query_as::<_, StatsRow>(
        "SELECT
           (SELECT COUNT(*) FROM follows WHERE followee = u.id) AS followers,
           (SELECT COUNT(*) FROM follows WHERE follower = u.id) AS following,
           u.posts_count::bigint AS posts,
           u.coins AS coins,
           EXTRACT(EPOCH FROM u.verified_until)::bigint AS verified_until,
           u.verified_manual AS manual,
           COALESCE(u.verified_until > now(), FALSE) AS paid,
           EXISTS (SELECT 1 FROM follows WHERE follower = $2 AND followee = u.id) AS i_follow
         FROM users u WHERE u.id = $1",
    )
    .bind(target)
    .bind(viewer)
    .fetch_optional(db)
    .await?
    .ok_or(AppError::NotFound)?;
    let kind = if r.manual {
        Some("celebrity")
    } else if r.followers >= POPULAR_FOLLOWERS {
        Some("popular")
    } else if r.paid {
        Some("paid")
    } else {
        None
    };
    let own = target == viewer;
    Ok(Stats {
        followers: r.followers,
        following: r.following,
        posts: r.posts,
        verified: kind.is_some(),
        verified_kind: kind.map(|k| k.to_string()),
        verified_until: if r.paid && own { r.verified_until } else { None },
        coins: if own { Some(r.coins) } else { None },
        i_follow: r.i_follow,
    })
}

pub async fn my_stats(State(s): State<AppState>, AuthUser(me): AuthUser) -> Res<Json<Stats>> {
    Ok(Json(stats_for(&s.db, me, me).await?))
}

async fn linked(db: &sqlx::PgPool, me: Uuid, other: Uuid) -> Res<bool> {
    if me == other {
        return Ok(true);
    }
    Ok(sqlx::query_scalar("SELECT EXISTS (SELECT 1 FROM contacts WHERE user_id = $1 AND contact_id = $2)")
        .bind(me)
        .bind(other)
        .fetch_one(db)
        .await?)
}

pub async fn user_stats(State(s): State<AppState>, AuthUser(me): AuthUser, Path(id): Path<Uuid>) -> Res<Json<Stats>> {
    if !linked(&s.db, me, id).await? {
        return Err(AppError::NotFound);
    }
    Ok(Json(stats_for(&s.db, id, me).await?))
}

pub async fn follow(State(s): State<AppState>, AuthUser(me): AuthUser, Path(id): Path<Uuid>) -> Res<Json<Stats>> {
    if me == id || !linked(&s.db, me, id).await? {
        return Err(AppError::NotFound);
    }
    sqlx::query("INSERT INTO follows (follower, followee) VALUES ($1, $2) ON CONFLICT DO NOTHING")
        .bind(me)
        .bind(id)
        .execute(&s.db)
        .await?;
    Ok(Json(stats_for(&s.db, id, me).await?))
}

pub async fn unfollow(State(s): State<AppState>, AuthUser(me): AuthUser, Path(id): Path<Uuid>) -> Res<Json<Stats>> {
    sqlx::query("DELETE FROM follows WHERE follower = $1 AND followee = $2")
        .bind(me)
        .bind(id)
        .execute(&s.db)
        .await?;
    Ok(Json(stats_for(&s.db, id, me).await?))
}

// ---------------------------------------------------------------- admin: celebrities

#[derive(Deserialize)]
pub struct AdminVerify {
    username: String,
    on: bool,
}

/// Gives or removes the badge for a celebrity. Needs the header `x-admin-key: <ADMIN_KEY>`.
pub async fn admin_verify(State(s): State<AppState>, headers: HeaderMap, Json(b): Json<AdminVerify>) -> Res<Json<Value>> {
    let key = std::env::var("ADMIN_KEY").ok().filter(|k| k.len() >= 16);
    let given = headers.get("x-admin-key").and_then(|v| v.to_str().ok()).unwrap_or("");
    match key {
        Some(k) if k == given => {}
        _ => return Err(AppError::Forbidden("forbidden")),
    }
    let n = sqlx::query("UPDATE users SET verified_manual = $2 WHERE lower(username) = $1")
        .bind(b.username.trim().trim_start_matches('@').to_lowercase())
        .bind(b.on)
        .execute(&s.db)
        .await?
        .rows_affected();
    if n == 0 {
        return Err(AppError::NotFound);
    }
    Ok(Json(json!({ "ok": true })))
}

// ---------------------------------------------------------------- paying for the badge (Paymob: Visa / Mastercard / bank cards in Egypt)

fn env(k: &str) -> Option<String> {
    std::env::var(k).ok().filter(|v| !v.is_empty())
}

async fn post_json(http: &reqwest::Client, url: &str, body: Value) -> Res<Value> {
    let res = http.post(url).json(&body).send().await.map_err(|e| {
        tracing::error!("paymob request failed: {e}");
        AppError::BadRequest("payment_failed")
    })?;
    if !res.status().is_success() {
        tracing::error!("paymob answered {} for {url}", res.status());
        return Err(AppError::BadRequest("payment_failed"));
    }
    res.json::<Value>().await.map_err(|_| AppError::BadRequest("payment_failed"))
}

#[derive(Deserialize)]
pub struct Checkout {
    plan: String,
}

/// Starts a payment: returns the secure card page address. The badge is only given after the bank confirms.
pub async fn checkout(State(s): State<AppState>, AuthUser(me): AuthUser, Json(b): Json<Checkout>) -> Res<Json<Value>> {
    let (plan, _months, egp) = PLANS.iter().find(|p| p.0 == b.plan).copied().ok_or(AppError::BadRequest("invalid_plan"))?;
    let (Some(api_key), Some(integration), Some(iframe)) =
        (env("PAYMOB_API_KEY"), env("PAYMOB_INTEGRATION_ID"), env("PAYMOB_IFRAME_ID"))
    else {
        return Err(AppError::BadRequest("payments_not_configured"));
    };
    let integration: i64 = integration.parse().map_err(|_| AppError::BadRequest("payments_not_configured"))?;
    let amount_cents = egp * 100;
    let pay_id = Uuid::new_v4();

    let (email, name): (Option<String>, String) = sqlx::query_as("SELECT email, name FROM users WHERE id = $1")
        .bind(me)
        .fetch_one(&s.db)
        .await?;

    let auth = post_json(&s.http, "https://accept.paymob.com/api/auth/tokens", json!({ "api_key": api_key })).await?;
    let auth_token = auth["token"].as_str().ok_or(AppError::BadRequest("payment_failed"))?.to_string();
    let order = post_json(
        &s.http,
        "https://accept.paymob.com/api/ecommerce/orders",
        json!({
            "auth_token": auth_token, "delivery_needed": false, "amount_cents": amount_cents,
            "currency": "EGP", "merchant_order_id": pay_id.to_string(), "items": [],
        }),
    )
    .await?;
    let order_id = order["id"].as_i64().ok_or(AppError::BadRequest("payment_failed"))?;
    let key = post_json(
        &s.http,
        "https://accept.paymob.com/api/acceptance/payment_keys",
        json!({
            "auth_token": auth_token, "amount_cents": amount_cents, "expiration": 3600, "order_id": order_id,
            "currency": "EGP", "integration_id": integration,
            "billing_data": {
                "apartment": "NA", "email": email.unwrap_or_else(|| "noreply@stitch.app".to_string()), "floor": "NA",
                "first_name": name, "street": "NA", "building": "NA", "phone_number": "+201000000000",
                "shipping_method": "NA", "postal_code": "NA", "city": "NA", "country": "EG", "last_name": "NA", "state": "NA",
            },
        }),
    )
    .await?;
    let pay_token = key["token"].as_str().ok_or(AppError::BadRequest("payment_failed"))?;

    sqlx::query("INSERT INTO payments (id, user_id, plan, amount_cents, provider_order) VALUES ($1, $2, $3, $4, $5)")
        .bind(pay_id)
        .bind(me)
        .bind(plan)
        .bind(amount_cents)
        .bind(order_id)
        .execute(&s.db)
        .await?;

    Ok(Json(json!({
        "url": format!("https://accept.paymob.com/api/acceptance/iframes/{iframe}?payment_token={pay_token}")
    })))
}

/// Reads "a.b.c" from the transaction the way Paymob builds its signature: text, numbers and true/false.
fn sig_field(v: &Value, path: &str) -> String {
    let mut cur = v;
    for part in path.split('.') {
        cur = &cur[part];
    }
    match cur {
        Value::String(x) => x.clone(),
        Value::Bool(x) => x.to_string(),
        Value::Number(x) => x.to_string(),
        _ => String::new(),
    }
}

const SIG_FIELDS: [&str; 20] = [
    "amount_cents", "created_at", "currency", "error_occured", "has_parent_transaction", "id", "integration_id",
    "is_3d_secure", "is_auth", "is_capture", "is_refunded", "is_standalone_payment", "is_voided", "order.id", "owner",
    "pending", "source_data.pan", "source_data.sub_type", "source_data.type", "success",
];

/// Paymob calls this after every payment. We check its signature, then check that the money really arrived
/// (success, not pending, not voided or refunded, same amount) before giving the badge.
pub async fn paymob_callback(
    State(s): State<AppState>,
    Query(q): Query<HashMap<String, String>>,
    Json(body): Json<Value>,
) -> Res<StatusCode> {
    let secret = env("PAYMOB_HMAC").ok_or(AppError::Forbidden("forbidden"))?;
    let given = q.get("hmac").and_then(|h| hex::decode(h).ok()).ok_or(AppError::Forbidden("forbidden"))?;
    let obj = &body["obj"];
    let text: String = SIG_FIELDS.iter().map(|f| sig_field(obj, f)).collect();
    let mut mac = Hmac::<Sha512>::new_from_slice(secret.as_bytes()).map_err(|_| AppError::Internal)?;
    mac.update(text.as_bytes());
    mac.verify_slice(&given).map_err(|_| AppError::Forbidden("forbidden"))?;

    let paid = obj["success"].as_bool() == Some(true)
        && obj["pending"].as_bool() == Some(false)
        && obj["is_voided"].as_bool() != Some(true)
        && obj["is_refunded"].as_bool() != Some(true);
    if !paid {
        return Ok(StatusCode::OK);
    }
    let order_id = obj["order"]["id"].as_i64().ok_or(AppError::BadRequest("bad_callback"))?;
    let amount = obj["amount_cents"].as_i64().unwrap_or(-1);
    let txn = obj["id"].as_i64();

    let mut tx = s.db.begin().await?;
    // Only a pending payment with exactly the expected amount can be completed, and only once.
    let row: Option<(Uuid, String)> = sqlx::query_as(
        "UPDATE payments SET status = 'paid', paid_at = now(), provider_txn = $3
         WHERE provider_order = $1 AND status = 'pending' AND amount_cents = $2
         RETURNING user_id, plan",
    )
    .bind(order_id)
    .bind(amount)
    .bind(txn)
    .fetch_optional(&mut *tx)
    .await?;
    if let Some((user_id, plan)) = row {
        if let Some((_, months, _)) = PLANS.iter().find(|p| p.0 == plan) {
            sqlx::query(
                "UPDATE users SET verified_until = GREATEST(COALESCE(verified_until, now()), now()) + ($2::int * interval '1 month')
                 WHERE id = $1",
            )
            .bind(user_id)
            .bind(*months)
            .execute(&mut *tx)
            .await?;
        }
    }
    tx.commit().await?;
    Ok(StatusCode::OK)
}
