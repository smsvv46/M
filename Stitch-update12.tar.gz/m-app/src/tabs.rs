use crate::{
    api::{call, fmt_count, ChatItem, Contact, Method, Settings, Stats, User},
    avatar,
    chat::{fmt_time, ChatScreen},
    i18n::{err_text, tr},
    login::Icon,
    look::{self, Look, Picker, ProfileHeader},
    social::{upload, BannerView, ContactsScreen, Overlay, ProfileView, ICON_SEARCH},
    settings::SettingsTab,
    stories::{NewStory, StoriesTab, StoryViewer},
    trusted::{SoonPage, TrustedPage},
    Ctx,
};
use dioxus::prelude::*;
use gloo_storage::{LocalStorage, Storage};
use serde_json::{json, Value};
use std::collections::HashMap;

const ICON_CHAT: &str = "M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8v.5z";
const ICON_STORY: &str = "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8z";
const ICON_USER: &str = "M12 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM4 21v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1";
const ICON_SLIDERS: &str = "M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0M16 4v4M10 10v4M18 16v4";

#[derive(Clone, Copy, PartialEq)]
enum Tab {
    Chats,
    Stories,
    Profile,
    Settings,
}

#[component]
pub fn Shell() -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let mut tab = use_signal(|| Tab::Chats);
    let overlay = use_signal(|| Overlay::None);

    // The profile loads right after sign-in. Show the app only once it is here.
    if ctx.user.read().is_none() {
        return rsx! { div { class: "screen center", {tr(&lang(), "loading")} } };
    }

    let item = move |t: Tab, label: &'static str, icon: &'static str| {
        let cls = if tab() == t { "nav-item on" } else { "nav-item" };
        rsx! {
            button { class: "{cls}", r#type: "button", onclick: move |_| tab.set(t),
                Icon { d: icon }
                span { {tr(&lang(), label)} }
            }
        }
    };

    rsx! {
        div { class: "screen",
            match overlay() {
                Overlay::Contacts => rsx! { ContactsScreen { overlay } },
                Overlay::Profile(id) => rsx! { ProfileView { id: id, overlay } },
                Overlay::Chat(id) => rsx! { ChatScreen { id: id, overlay } },
                Overlay::Story(id) => rsx! { StoryViewer { user_id: id, overlay } },
                Overlay::NewStory => rsx! { NewStory { overlay } },
                Overlay::None => rsx! {
                    div { class: "screen-body",
                        match tab() {
                            Tab::Chats => rsx! { ChatsTab { overlay } },
                            Tab::Stories => rsx! { StoriesTab { overlay } },
                            Tab::Profile => rsx! { ProfileTab { overlay } },
                            Tab::Settings => rsx! { SettingsTab {} },
                        }
                    }
                    nav { class: "nav",
                        {item(Tab::Chats, "chats", ICON_CHAT)}
                        {item(Tab::Stories, "stories", ICON_STORY)}
                        {item(Tab::Profile, "profile", ICON_USER)}
                        {item(Tab::Settings, "settings", ICON_SLIDERS)}
                    }
                },
            }
        }
    }
}

// ---------------------------------------------------------------- chats

const ICON_NEW_CHAT: &str = "M12 5v14M5 12h14";

#[component]
fn ChatRow(item: ChatItem, mut overlay: Signal<Overlay>, on_menu: EventHandler<String>, fav: bool) -> Element {
    let id = item.id.clone();
    let menu_id = item.id.clone();
    let time = item.last_ts.map(fmt_time).unwrap_or_default();
    let body = item.last_body.clone().unwrap_or_default();
    let unread = item.unread > 0;
    rsx! {
        div { class: "chat-row-wrap",
            button {
                class: "chat-row", r#type: "button",
                onclick: move |_| overlay.set(Overlay::Chat(id.clone())),
                img { class: "avatar md", src: "{avatar::user_uri(&item.avatar_kind, &item.avatar_value)}", alt: "" }
                div { class: "chat-main",
                    div { class: "chat-name",
                        "{item.name}"
                        if fav { span { class: "fav-star", " ★" } }
                    }
                    div { class: "chat-sub", "{body}" }
                }
                div { class: "chat-side",
                    span { class: if unread { "chat-time unread" } else { "chat-time" }, "{time}" }
                    if unread { span { class: "badge", "{item.unread}" } }
                }
            }
            button {
                class: "more-btn", r#type: "button", "aria-label": "menu",
                onclick: move |_| on_menu.call(menu_id.clone()),
                "⋮"
            }
        }
    }
}

#[component]
fn TagRow(label: String, on: bool, onpick: EventHandler<()>) -> Element {
    rsx! {
        button { class: "tag-row", r#type: "button", onclick: move |_| onpick.call(()),
            span { "{label}" }
            span { class: if on { "tag-check on" } else { "tag-check" }, if on { "✓" } }
        }
    }
}

fn load_tags() -> HashMap<String, Vec<String>> {
    LocalStorage::get("m_chat_tags").unwrap_or_default()
}

#[component]
fn ChatsTab(mut overlay: Signal<Overlay>) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;

    let mut chats = use_signal(Vec::<ChatItem>::new);
    let mut query = use_signal(String::new);
    let mut tags = use_signal(load_tags);
    let mut lists = use_signal(|| LocalStorage::get::<Vec<String>>("m_lists").unwrap_or_default());
    let mut filter = use_signal(|| "all".to_string());
    let mut menu_for = use_signal(|| None::<String>);
    let mut adding = use_signal(|| false);
    let mut new_list = use_signal(String::new);
    let keep_archived = crate::api::get_bool("m_keep_archived", true);

    // Refresh the list every few seconds so new messages and unread counts show up.
    use_hook(move || {
        spawn(async move {
            let mut seen: HashMap<String, i64> = HashMap::new();
            let mut first = true;
            loop {
                if let Ok(v) = call(Method::GET, "/chats", None, token()).await {
                    let list: Vec<ChatItem> = serde_json::from_value(v).unwrap_or_default();
                    for c in &list {
                        let before = seen.get(&c.id).copied().unwrap_or(0);
                        if !first && c.unread > before {
                            crate::api::notify_hidden(&c.name, c.last_body.as_deref().unwrap_or(""));
                        }
                        seen.insert(c.id.clone(), c.unread);
                    }
                    first = false;
                    chats.set(list);
                }
                gloo_timers::future::TimeoutFuture::new(crate::api::poll_ms(8000)).await;
            }
        });
    });

    // Put a chat in (or take it out of) favourites, the archive or one of my lists.
    let mut toggle = move |id: String, t: String| {
        let mut m = tags();
        let e = m.entry(id).or_default();
        if let Some(p) = e.iter().position(|x| *x == t) {
            e.remove(p);
        } else {
            e.push(t);
        }
        let _ = LocalStorage::set("m_chat_tags", m.clone());
        tags.set(m);
    };
    let add_list = move |_| {
        let name = new_list().trim().to_string();
        if name.is_empty() || name.chars().count() > 20 {
            return;
        }
        let mut l = lists();
        if !l.contains(&name) {
            l.push(name.clone());
            let _ = LocalStorage::set("m_lists", l.clone());
            lists.set(l);
        }
        new_list.set(String::new());
        adding.set(false);
        filter.set(format!("l:{name}"));
    };

    let tg = tags();
    let has = |id: &str, t: &str| tg.get(id).map_or(false, |v| v.iter().any(|x| x == t));
    let q = query().to_lowercase();
    let f = filter();
    let shown: Vec<ChatItem> = chats()
        .into_iter()
        .filter(|c| q.is_empty() || c.name.to_lowercase().contains(&q))
        .filter(|c| {
            let archived = has(&c.id, "archive");
            match f.as_str() {
                "all" => !archived || (!keep_archived && c.unread > 0),
                "unread" => c.unread > 0 && !archived,
                "fav" => has(&c.id, "fav"),
                "archive" => archived,
                other => has(&c.id, other),
            }
        })
        .collect();

    let mut chips: Vec<(String, String)> = vec![
        ("all".to_string(), tr(&lang(), "f_all")),
        ("unread".to_string(), tr(&lang(), "f_unread")),
        ("fav".to_string(), tr(&lang(), "f_fav")),
        ("archive".to_string(), tr(&lang(), "f_archive")),
    ];
    for l in lists() {
        chips.push((format!("l:{l}"), l));
    }

    let search_class = format!("search sf{}", LocalStorage::get::<usize>("m_search_frame").unwrap_or(0).min(look::SEARCH_FRAMES - 1));
    let search_ph = tr(&lang(), "search");
    let new_label = tr(&lang(), "new_chat");
    let list_ph = tr(&lang(), "list_name_ph");
    let add_list_label = tr(&lang(), "lists");

    rsx! {
        header { class: "top", h1 { class: "display", {tr(&lang(), "chats")} } }

        div { class: search_class,
            Icon { d: ICON_SEARCH }
            input {
                r#type: "search", placeholder: "{search_ph}", value: "{query}",
                oninput: move |e| query.set(e.value()),
            }
        }

        div { class: "chips",
            for (key, label) in chips {
                button {
                    key: "{key}", r#type: "button",
                    class: if f == key { "chip on" } else { "chip" },
                    onclick: {
                        let k = key.clone();
                        move |_| filter.set(k.clone())
                    },
                    "{label}"
                }
            }
            button {
                class: "chip", r#type: "button", "aria-label": "{add_list_label}",
                onclick: move |_| adding.set(!adding()),
                "+"
            }
        }
        if adding() {
            div { class: "row list-add",
                input {
                    class: "plain", r#type: "text", maxlength: "20", placeholder: "{list_ph}",
                    value: "{new_list}", oninput: move |e| new_list.set(e.value()),
                }
                button { class: "silver small", r#type: "button", onclick: add_list, {tr(&lang(), "create")} }
            }
        }

        if shown.is_empty() {
            p { class: "hint center-text", {tr(&lang(), "no_chats")} }
        }
        div { class: "chat-list",
            for c in shown {
                ChatRow {
                    key: "{c.id}", item: c.clone(), overlay, fav: has(&c.id, "fav"),
                    on_menu: move |id: String| menu_for.set(Some(id)),
                }
            }
        }

        if let Some(cid) = menu_for() {
            div { class: "theme-back", onclick: move |_| menu_for.set(None) }
            div { class: "theme-sheet",
                h3 { class: "section-title", {tr(&lang(), "add_to_list")} }
                TagRow {
                    label: tr(&lang(), "f_fav"), on: has(&cid, "fav"),
                    onpick: {
                        let c = cid.clone();
                        move |_| toggle(c.clone(), "fav".to_string())
                    },
                }
                TagRow {
                    label: tr(&lang(), "f_archive"), on: has(&cid, "archive"),
                    onpick: {
                        let c = cid.clone();
                        move |_| toggle(c.clone(), "archive".to_string())
                    },
                }
                for l in lists() {
                    TagRow {
                        key: "{l}", label: l.clone(), on: has(&cid, &format!("l:{l}")),
                        onpick: {
                            let c = cid.clone();
                            let t = format!("l:{l}");
                            move |_| toggle(c.clone(), t.clone())
                        },
                    }
                }
            }
        }

        button {
            class: "fab", r#type: "button", "aria-label": "{new_label}",
            onclick: move |_| overlay.set(Overlay::Contacts),
            Icon { d: ICON_NEW_CHAT }
        }
    }
}

// ---------------------------------------------------------------- profile

async fn patch_me(token: Option<String>, mut user: Signal<Option<User>>, body: Value) -> Result<(), String> {
    let v = call(Method::PATCH, "/me", Some(body), token).await?;
    user.set(serde_json::from_value(v).ok());
    Ok(())
}

#[component]
fn ProfileTab(mut overlay: Signal<Overlay>) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let mut user = ctx.user;

    let u = user().unwrap_or_else(User::blank);
    let mut name = use_signal(|| u.name.clone());
    let mut bio = use_signal(|| u.bio.clone());
    let mut note = use_signal(String::new);
    let mut failed = use_signal(|| false);
    let mut editing = use_signal(|| false);
    let mut friends = use_signal(Vec::<Contact>::new);
    let mut my_note = use_signal(|| LocalStorage::get::<String>("m_note").unwrap_or_default());
    let mut sub_page = use_signal(|| 0u8);
    let mut stats = use_signal(|| None::<Stats>);

    use_hook(move || {
        spawn(async move {
            if let Ok(v) = call(Method::GET, "/me/contacts", None, token()).await {
                friends.set(serde_json::from_value(v).unwrap_or_default());
            }
            if let Ok(v) = call(Method::GET, "/me/stats", None, token()).await {
                stats.set(serde_json::from_value(v).ok());
            }
        });
    });

    let save = move |_| {
        spawn(async move {
            match patch_me(token(), user, json!({ "name": name(), "bio": bio() })).await {
                Ok(_) => {
                    failed.set(false);
                    note.set(tr(&lang(), "saved"));
                }
                Err(e) => {
                    failed.set(true);
                    note.set(err_text(&lang(), &e));
                }
            }
        });
    };

    let pick_avatar = move |_| {
        spawn(async move {
            match upload("pick-avatar", "/me/avatar", 640, false, token()).await {
                Ok(u) => {
                    user.set(Some(u));
                    failed.set(false);
                    note.set(tr(&lang(), "saved"));
                }
                Err(e) => {
                    failed.set(true);
                    note.set(err_text(&lang(), &e));
                }
            }
        });
    };
    let pick_banner = move |_| {
        spawn(async move {
            match upload("pick-banner", "/me/banner", 1280, true, token()).await {
                Ok(u) => {
                    user.set(Some(u));
                    failed.set(false);
                    note.set(tr(&lang(), "saved"));
                }
                Err(e) => {
                    failed.set(true);
                    note.set(err_text(&lang(), &e));
                }
            }
        });
    };

    let current = user().unwrap_or(u);
    let picture = avatar::of(&current);
    let look_v = Look::parse(&current.look);
    let set_look = move |l: Look| {
        spawn(async move {
            let _ = patch_me(token(), user, json!({ "look": l.encode() })).await;
        });
    };
    let mut sframe = use_signal(|| LocalStorage::get::<usize>("m_search_frame").unwrap_or(0));
    let mut app_icon = use_signal(|| LocalStorage::get::<usize>("m_app_icon").unwrap_or(0));
    let sub = if current.bio.is_empty() {
        current.phone.clone().or(current.email.clone()).unwrap_or_default()
    } else {
        current.bio.clone()
    };
    let edit_label = tr(&lang(), if editing() { "pf_done" } else { "pf_edit" });
    let more = friends().len().saturating_sub(5);
    let coins = stats().and_then(|s| s.coins).map(fmt_count).unwrap_or_else(|| "0".to_string());

    match sub_page() {
        1 => return rsx! { SoonPage { title: "nitro", back: move |_| sub_page.set(0) } },
        2 => return rsx! { SoonPage { title: "shop", back: move |_| sub_page.set(0) } },
        3 => return rsx! { TrustedPage { stats, back: move |_| sub_page.set(0) } },
        _ => {}
    }

    rsx! {
        ProfileHeader {
            look: current.look.clone(), banner_kind: current.banner_kind.clone(), banner: current.banner,
            banner_url: current.banner_url.clone(), picture: picture.clone(), name: current.name.clone(), sub: sub.clone(),
            stats: stats(),
        }
        button {
            class: "silver pf-edit", r#type: "button",
            onclick: move |_| editing.set(!editing()),
            Icon { d: ICON_PENCIL }
            span { "{edit_label}" }
        }

        if editing() {
            section { class: "card",
                h2 { {tr(&lang(), "look_title")} }
                p { class: "hint", {tr(&lang(), "look_live")} }
                Picker { title: tr(&lang(), "look_name"), kind: "ns", count: look::NAME_STYLES, current: look_v.name, onpick: move |i: usize| set_look(look_v.with("name", i)) }
                Picker { title: tr(&lang(), "look_deco"), kind: "ad", count: look::DECOS, current: look_v.deco, onpick: move |i: usize| set_look(look_v.with("deco", i)) }
                Picker { title: tr(&lang(), "look_effect"), kind: "pe", count: look::EFFECTS, current: look_v.effect, onpick: move |i: usize| set_look(look_v.with("effect", i)) }
                Picker { title: tr(&lang(), "look_frame"), kind: "fr", count: look::FRAMES, current: look_v.frame, onpick: move |i: usize| set_look(look_v.with("frame", i)) }
                Picker { title: tr(&lang(), "look_plate"), kind: "np", count: look::PLATES, current: look_v.plate, onpick: move |i: usize| set_look(look_v.with("plate", i)) }
                Picker {
                    title: tr(&lang(), "look_search"), kind: "sf", count: look::SEARCH_FRAMES, current: sframe(),
                    onpick: move |i: usize| {
                        let _ = LocalStorage::set("m_search_frame", i);
                        sframe.set(i);
                    },
                }
                Picker {
                    title: tr(&lang(), "look_icon"), kind: "ic", count: look::ICONS, current: app_icon(),
                    onpick: move |i: usize| {
                        let _ = LocalStorage::set("m_app_icon", i);
                        look::apply_icon(i);
                        app_icon.set(i);
                    },
                }
                p { class: "hint", {tr(&lang(), "look_search_hint")} }
                p { class: "hint", {tr(&lang(), "icon_hint")} }
            }

            section { class: "card",
                label { class: "stack", span { {tr(&lang(), "name")} }
                    input { class: "plain", r#type: "text", maxlength: "30", value: "{name}", oninput: move |e| name.set(e.value()) }
                }
                label { class: "stack", span { {tr(&lang(), "bio")} }
                    textarea { class: "plain", maxlength: "120", value: "{bio}", oninput: move |e| bio.set(e.value()) }
                }
                button { class: "silver small", r#type: "button", onclick: save, {tr(&lang(), "save")} }
            }

            section { class: "card",
                h2 { {tr(&lang(), "photo")} }
                label { class: "silver small upload",
                    {tr(&lang(), "change_photo")}
                    input { id: "pick-avatar", class: "file-hidden", r#type: "file", accept: "image/*", onchange: pick_avatar }
                }
                label { class: "silver small upload",
                    {tr(&lang(), "upload_banner")}
                    input { id: "pick-banner", class: "file-hidden", r#type: "file", accept: "image/*,video/mp4,video/webm", onchange: pick_banner }
                }
                p { class: "hint", {tr(&lang(), "banner_hint")} }
            }

            section { class: "card",
                h2 { {tr(&lang(), "avatar")} }
                div { class: "grid6",
                    for i in 0..avatar::PRESET_COUNT {
                        button {
                            key: "{i}", r#type: "button",
                            class: if current.avatar_kind == "preset" && current.avatar_value == i.to_string() { "pick on round" } else { "pick round" },
                            "aria-label": "avatar {i}",
                            onclick: move |_| {
                                spawn(async move {
                                    let _ = patch_me(token(), user, json!({ "avatar_kind": "preset", "avatar_value": i.to_string() })).await;
                                });
                            },
                            img { src: "{avatar::preset_uri(i)}", alt: "" }
                        }
                    }
                }
            }

            section { class: "card",
                h2 { {tr(&lang(), "banner")} }
                div { class: "grid6",
                    for i in 0..6i16 {
                        button {
                            key: "{i}", r#type: "button",
                            class: if current.banner == i { "pick on wide" } else { "pick wide" },
                            "aria-label": "banner {i}",
                            onclick: move |_| {
                                spawn(async move {
                                    let _ = patch_me(token(), user, json!({ "banner": i })).await;
                                });
                            },
                            span { class: "banner b{i}" }
                        }
                    }
                }
            }
        }

        div { class: "card coins-card",
            span { class: "coin-ic", "aria-hidden": "true", "L" }
            strong { class: "grow", "LIXO COINS" }
            span { class: "coin-pill", "{coins}" }
        }

        button {
            class: "card pf-row", r#type: "button",
            onclick: move |_| overlay.set(Overlay::Contacts),
            strong { {tr(&lang(), "pf_friends")} }
            span { class: "pf-faces",
                for c in friends().into_iter().take(5) {
                    img { key: "{c.id}", class: "avatar sm", src: "{avatar::user_uri(&c.avatar_kind, &c.avatar_value)}", alt: "" }
                }
                if more > 0 { span { class: "hint", "+{more}" } }
            }
        }

        section { class: "card",
            label { class: "stack", span { {tr(&lang(), "pf_note")} }
                textarea {
                    class: "plain", maxlength: "300", value: "{my_note}",
                    oninput: move |e| {
                        let v = e.value();
                        let _ = LocalStorage::set("m_note", v.clone());
                        my_note.set(v);
                    },
                }
            }
        }

        if !note().is_empty() {
            p { class: if failed() { "note err" } else { "note ok" }, role: "status", "{note}" }
        }

        div { class: "pf-dock",
            button { r#type: "button", onclick: move |_| sub_page.set(1),
                Icon { d: ICON_BOLT }
                span { {tr(&lang(), "nitro")} }
            }
            button { r#type: "button", onclick: move |_| sub_page.set(2),
                Icon { d: ICON_SHOP }
                span { {tr(&lang(), "shop")} }
            }
            button { r#type: "button", onclick: move |_| sub_page.set(3),
                Icon { d: ICON_SEAL }
                span { {tr(&lang(), "trusted")} }
            }
        }
    }
}

const ICON_BOLT: &str = "M13 2L4 14h7l-1 8 9-12h-7z";
const ICON_SHOP: &str = "M3 9l1.5-5h15L21 9M4 9v11h16V9M9 20v-6h6v6";
const ICON_SEAL: &str = "M12 2l2.6 1.9 3.2-.2 1 3.1 2.6 1.9-1 3.1 1 3.1-2.6 1.9-1 3.1-3.2-.2L12 22l-2.6-1.9-3.2.2-1-3.1L2.6 15.3l1-3.1-1-3.1 2.6-1.9 1-3.1 3.2.2zM8 12l3 3 5-5.5";
const ICON_PENCIL: &str = "M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z";

// ---------------------------------------------------------------- settings

/// `{ field: value }` with the field name taken from a variable.
fn one(field: &str, value: Value) -> Value {
    let mut m = serde_json::Map::new();
    m.insert(field.to_string(), value);
    Value::Object(m)
}

pub async fn patch_settings(token: Option<String>, mut settings: Signal<Option<Settings>>, body: Value) {
    if let Ok(v) = call(Method::PATCH, "/me/settings", Some(body), token).await {
        settings.set(serde_json::from_value(v).ok());
    }
}

#[component]
pub fn ToggleRow(label: &'static str, hint: &'static str, field: &'static str, settings: Signal<Option<Settings>>) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let on = settings().map(|s| s.flag(field)).unwrap_or(true);
    let label_text = tr(&lang(), label);
    rsx! {
        div { class: "row-setting",
            div { class: "grow",
                strong { {tr(&lang(), label)} }
                small { {tr(&lang(), hint)} }
            }
            button {
                class: if on { "switch on" } else { "switch" },
                r#type: "button", role: "switch", "aria-checked": "{on}", "aria-label": "{label_text}",
                onclick: move |_| {
                    spawn(async move { patch_settings(token(), settings, one(field, json!(!on))).await });
                },
                span { class: "knob" }
            }
        }
    }
}

#[component]
pub fn VisRow(label: &'static str, field: &'static str, settings: Signal<Option<Settings>>) -> Element {
    let ctx = use_context::<Ctx>();
    let lang = ctx.lang;
    let token = ctx.token;
    let value = settings().map(|s| s.text(field)).unwrap_or_default();
    let label_text = tr(&lang(), label);
    rsx! {
        div { class: "row-setting",
            strong { class: "grow", {tr(&lang(), label)} }
            select {
                class: "plain compact", "aria-label": "{label_text}",
                onchange: move |e| {
                    let v = e.value();
                    spawn(async move { patch_settings(token(), settings, one(field, json!(v))).await });
                },
                for (val, key) in [("all", "all"), ("contacts", "contacts_only"), ("nobody", "nobody")] {
                    option { key: "{val}", value: "{val}", selected: value == val, {tr(&lang(), key)} }
                }
            }
        }
    }
}

/// Chat background colours. The choice is kept on this phone and applies to every chat.
#[component]
pub fn ThemePicker() -> Element {
    let lang = use_context::<Ctx>().lang;
    let mut theme = use_signal(|| LocalStorage::get::<usize>("m_chat_theme").unwrap_or(0));
    let label = tr(&lang(), "theme_bg");
    rsx! {
        div { class: "theme-grid",
            for i in 0..10usize {
                button {
                    key: "{i}", r#type: "button", "aria-label": "{label} {i}",
                    class: format!("theme-dot ct{i}{}", if theme() == i { " on" } else { "" }),
                    onclick: move |_| {
                        theme.set(i);
                        let _ = LocalStorage::set("m_chat_theme", i);
                    },
                }
            }
        }
    }
}
