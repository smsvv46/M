mod api;
mod avatar;
mod chat;
mod countries;
mod i18n;
mod login;
mod look;
mod settings;
mod social;
mod stories;
mod tabs;
mod trusted;

use api::{call, invite_from_url, Method, User};
use dioxus::prelude::*;
use gloo_storage::{LocalStorage, Storage};
use i18n::{is_rtl, load_language};

const CSS: Asset = asset!("/assets/main.css");

/// Shared app state: who is signed in and which language is on.
#[derive(Clone, Copy)]
pub struct Ctx {
    pub token: Signal<Option<String>>,
    pub user: Signal<Option<User>>,
    pub lang: Signal<String>,
    /// Bumped whenever a local preference changes, so the app re-reads them.
    pub rev: Signal<u32>,
}

fn main() {
    dioxus::launch(App);
}

#[component]
fn App() -> Element {
    let mut token = use_signal(|| LocalStorage::get::<String>("m_token").ok());
    let mut user = use_signal(|| None::<User>);
    let mut lang = use_signal(|| LocalStorage::get::<String>("m_lang").unwrap_or_else(|_| "en".to_string()));
    let rev = use_signal(|| 0u32);
    use_context_provider(|| Ctx { token, user, lang, rev });

    // Whenever the token changes, load the profile. An invalid token signs the person out.
    use_effect(move || {
        if let Some(t) = token() {
            spawn(async move {
                match call(Method::GET, "/me", None, Some(t.clone())).await {
                    Ok(v) => {
                        user.set(serde_json::from_value(v).ok());
                        if let Some(code) = invite_from_url() {
                            let _ = call(Method::POST, &format!("/invite/{code}"), None, Some(t)).await;
                        }
                    }
                    Err(e) => {
                        if e == "unauthorized" {
                            LocalStorage::delete("m_token");
                            token.set(None);
                        }
                    }
                }
            });
        } else {
            user.set(None);
        }
    });

    // A language other than English or Arabic: load its texts (saved copy first, then fresh from the server).
    use_hook(move || {
        let code = lang();
        if code != "en" && code != "ar" {
            spawn(async move {
                load_language(&code, token()).await;
                lang.set(code);
            });
        }
    });

    let dir = if is_rtl(&lang()) { "rtl" } else { "ltr" };
    use_hook(look::apply_saved_icon);
    use_hook(look::install_tilt);
    let _ = rev();
    let mut cls = String::from("app");
    if api::get_bool("m_hc", false) {
        cls.push_str(" hc");
    }
    if api::get_bool("m_nomotion", false) {
        cls.push_str(" nomotion");
    }
    if api::get_bool("m_big", false) {
        cls.push_str(" bigtext");
    }
    rsx! {
        document::Stylesheet { href: CSS }
        div { class: "{cls}", dir: "{dir}", lang: "{lang}",
            if token().is_some() {
                if user().map(|u| u.needs_profile).unwrap_or(false) {
                    login::CompleteProfile {}
                } else {
                    tabs::Shell {}
                }
            } else {
                login::Login {}
            }
        }
    }
}
