/// Languages offered in the picker. The server accepts any language tag, so adding
/// a language means adding a table below and one entry here.
use crate::api::{call, Method};
use gloo_storage::{LocalStorage, Storage};
use serde_json::json;
use std::{
    collections::HashMap,
    sync::{OnceLock, RwLock},
};

/// (code, name in its own language, name in English). Arabic and English are built in; every other
/// language is translated by the server the first time someone picks it, then kept for everyone.
pub const LANGUAGES: &[(&str, &str, &str)] = &[
    ("ar", "العربية", "Arabic"),
    ("en", "English", "English"),
    ("fr", "Français", "French"),
    ("es", "Español", "Spanish"),
    ("de", "Deutsch", "German"),
    ("it", "Italiano", "Italian"),
    ("pt-BR", "Português (Brasil)", "Brazilian Portuguese"),
    ("tr", "Türkçe", "Turkish"),
    ("ru", "Русский", "Russian"),
    ("uk", "Українська", "Ukrainian"),
    ("pl", "Polski", "Polish"),
    ("nl", "Nederlands", "Dutch"),
    ("sv", "Svenska", "Swedish"),
    ("el", "Ελληνικά", "Greek"),
    ("he", "עברית", "Hebrew"),
    ("fa", "فارسی", "Persian"),
    ("ur", "اردو", "Urdu"),
    ("hi", "हिन्दी", "Hindi"),
    ("bn", "বাংলা", "Bengali"),
    ("id", "Bahasa Indonesia", "Indonesian"),
    ("ms", "Bahasa Melayu", "Malay"),
    ("fil", "Filipino", "Filipino"),
    ("vi", "Tiếng Việt", "Vietnamese"),
    ("th", "ไทย", "Thai"),
    ("ja", "日本語", "Japanese"),
    ("ko", "한국어", "Korean"),
    ("zh-CN", "简体中文", "Chinese Simplified"),
    ("zh-TW", "繁體中文", "Chinese Traditional"),
    ("sw", "Kiswahili", "Swahili"),
    ("ro", "Română", "Romanian"),
    ("cs", "Čeština", "Czech"),
    ("hu", "Magyar", "Hungarian"),
];

/// Languages written from right to left.
pub fn is_rtl(code: &str) -> bool {
    matches!(code, "ar" | "he" | "fa" | "ur" | "ps" | "sd" | "yi" | "ug" | "ckb" | "dv")
}

fn dynamic() -> &'static RwLock<HashMap<String, HashMap<String, String>>> {
    static TABLES: OnceLock<RwLock<HashMap<String, HashMap<String, String>>>> = OnceLock::new();
    TABLES.get_or_init(|| RwLock::new(HashMap::new()))
}

fn set_dynamic(lang: &str, map: HashMap<String, String>) {
    if let Ok(mut w) = dynamic().write() {
        w.insert(lang.to_string(), map);
    }
}

/// Loads the texts of a language: the copy saved on this phone first, then a fresh one from the server.
/// Returns false when nothing is available (the app then stays in English).
pub async fn load_language(code: &str, token: Option<String>) -> bool {
    if code == "en" || code == "ar" {
        return true;
    }
    let cache_key = format!("m_i18n_{code}");
    let mut ok = false;
    if let Ok(m) = LocalStorage::get::<HashMap<String, String>>(&cache_key) {
        if !m.is_empty() {
            set_dynamic(code, m);
            ok = true;
        }
    }
    let Some(t) = token else { return ok };
    let name = LANGUAGES.iter().find(|l| l.0 == code).map(|l| l.2).unwrap_or(code);
    if let Ok(v) = call(Method::POST, "/i18n/translate", Some(json!({ "lang": code, "name": name })), Some(t)).await {
        if let Ok(m) = serde_json::from_value::<HashMap<String, String>>(v) {
            if !m.is_empty() {
                let _ = LocalStorage::set(&cache_key, m.clone());
                set_dynamic(code, m);
                ok = true;
            }
        }
    }
    ok
}

const EN: &[(&str, &str)] = &[
    ("welcome", "Welcome Back"),
    ("signin_sub", "Sign in to continue"),
    ("ident_ph", "Phone number or Email"),
    ("code_ph", "Verification code"),
    ("send_code", "Send code"),
    ("code_sent", "Code sent. Check your phone or email."),
    ("login", "Login"),
    ("or", "or"),
    ("no_account", "Don't have an account?"),
    ("sign_up", "Sign Up"),
    ("google_soon", "Google sign-in is coming soon. Use your phone or email for now."),
    ("phone_hint", "Phones need the country code, like +20"),
    ("chats", "Chats"),
    ("profile", "Profile"),
    ("settings", "Settings"),
    ("contacts", "Contacts"),
    ("no_contacts", "Nobody yet. Share your invite link."),
    ("invite_title", "Invite your friends"),
    ("invite_sub", "Send this link. When they sign in with it, you are added to each other."),
    ("copy", "Copy link"),
    ("copied", "Copied"),
    ("add_phone", "Add by phone number"),
    ("add", "Add"),
    ("added", "Added"),
    ("not_found", "No one can be added with that number"),
    ("name", "Name"),
    ("bio", "About you"),
    ("save", "Save"),
    ("saved", "Saved"),
    ("avatar", "Choose your avatar"),
    ("banner", "Animated banner"),
    ("change_pw", "Change password"),
    ("cur_pw", "Current password (if you have one)"),
    ("new_pw", "New password"),
    ("pw_done", "Password changed"),
    ("logout", "Sign out"),
    ("language", "App language"),
    ("privacy", "Privacy"),
    ("read_receipts", "Read receipts"),
    ("read_receipts_hint", "If off, nobody sees when you read their messages"),
    ("show_online", "Show when I'm online"),
    ("show_online_hint", "If off, you won't appear as Online"),
    ("last_seen", "Last seen"),
    ("photo_vis", "Who sees my photo"),
    ("story_vis", "Who sees my stories"),
    ("add_by_phone", "Who can add me by number"),
    ("calls", "Who can call me"),
    ("all", "Everyone"),
    ("contacts_only", "Contacts"),
    ("nobody", "Nobody"),
    ("loading", "Loading"),
    ("err_invalid_email", "Enter a valid email"),
    ("err_invalid_phone", "Enter a valid phone with the country code"),
    ("err_wrong_code", "Wrong code, try again"),
    ("err_code_expired", "The code expired, request a new one"),
    ("err_too_many_requests", "Too many tries, wait a few minutes"),
    ("err_network", "Cannot reach the server"),
    ("err_password_too_short", "Password needs at least 8 characters"),
    ("err_wrong_password", "Wrong current password"),
    ("search", "Search"),
    ("new_chat", "Select contact"),
    ("on_m", "On M"),
    ("invite_to_m", "Invite to M"),
    ("pick_contacts", "Choose contacts from your phone"),
    ("pick_again", "Choose more contacts"),
    ("picker_hint", "Tip: use Select all in the list to bring everyone."),
    ("picker_unsupported", "This browser cannot read your contacts. The Android app will do it for you. For now, add by number or share your invite link."),
    ("matching", "Checking who is on M"),
    ("invite_msg", "Join me on M:"),
    ("photo", "Photo and banner"),
    ("change_photo", "Choose photo from gallery"),
    ("upload_banner", "Choose banner (photo or video)"),
    ("banner_hint", "Videos up to 20 MB play on a loop without sound."),
    ("back", "Back"),
    ("chat_sub", "Tap to open profile"),
    ("no_chats", "No chats yet. Tap + to find your friends."),
    ("profile_missing", "This profile is not available"),
    ("err_unsupported_file", "Use a JPG, PNG or WebP photo, or an MP4 or WebM video"),
    ("err_file_too_large", "The file is too large"),
    ("err_empty_file", "The file is empty"),
    ("err_too_many_numbers", "Too many numbers at once"),
    ("err_not_found", "Not found"),
    ("online", "Online"),
    ("type_message", "Message"),
    ("send", "Send"),
    ("no_messages", "No messages yet. Say hello."),
    ("my_contacts", "Your contacts"),
    ("err_empty_message", "Write a message first"),
    ("err_message_too_long", "The message is too long"),
    ("err_cannot_chat_self", "You cannot chat with yourself"),
    ("stories", "Stories"),
    ("my_story", "My story"),
    ("add_story", "Tap + to add a story"),
    ("recent", "Recent updates"),
    ("new_story", "New story"),
    ("story_photo", "Photo or video"),
    ("story_text", "Text"),
    ("choose_story", "Choose photo or video"),
    ("caption_ph", "Add a caption (optional)"),
    ("text_ph", "Type your story"),
    ("story_hint", "Stories disappear after 24 hours. Videos up to 20 MB."),
    ("post", "Post"),
    ("comment_ph", "Add a comment"),
    ("chat", "Chat"),
    ("theme_bg", "Theme background"),
    ("repost", "Repost to my story"),
    ("reposted", "Reposted"),
    ("repost_from", "Reposted from"),
    ("comments", "Comments"),
    ("viewers", "Viewed by"),
    ("no_comments", "No comments yet"),
    ("delete", "Delete"),
    ("translating", "Translating the app"),
    ("translation_unavailable", "Translation is not available right now. The app stays in English."),
    ("err_caption_too_long", "The text is too long"),
    ("err_invalid_language", "This language is not supported"),
    ("err_generic", "Something went wrong"),
];

const AR: &[(&str, &str)] = &[
    ("welcome", "أهلاً بعودتك"),
    ("signin_sub", "سجّل دخولك للمتابعة"),
    ("ident_ph", "رقم الموبايل أو الإيميل"),
    ("code_ph", "كود التحقق"),
    ("send_code", "ابعت الكود"),
    ("code_sent", "اتبعت الكود، شوف موبايلك أو الإيميل."),
    ("login", "دخول"),
    ("or", "أو"),
    ("no_account", "ليس لديك حساب؟"),
    ("sign_up", "إنشاء حساب"),
    ("google_soon", "الدخول بجوجل قريباً. استخدم رقمك أو إيميلك الآن."),
    ("phone_hint", "الرقم لازم يبدأ بكود الدولة زي +20"),
    ("chats", "الدردشات"),
    ("profile", "حسابي"),
    ("settings", "الإعدادات"),
    ("contacts", "جهات الاتصال"),
    ("no_contacts", "لسه مفيش حد. ابعت لينك الدعوة."),
    ("invite_title", "ادعو أصحابك"),
    ("invite_sub", "ابعت اللينك ده. لما يسجلوا بيه بتتضافوا لبعض."),
    ("copy", "نسخ اللينك"),
    ("copied", "تم النسخ"),
    ("add_phone", "ضيف برقم موبايل"),
    ("add", "إضافة"),
    ("added", "تمت الإضافة"),
    ("not_found", "مش ممكن إضافة حد بالرقم ده"),
    ("name", "الاسم"),
    ("bio", "نبذة عنك"),
    ("save", "حفظ"),
    ("saved", "تم الحفظ"),
    ("avatar", "اختار شخصيتك"),
    ("banner", "البانر المتحرك"),
    ("change_pw", "تغيير كلمة المرور"),
    ("cur_pw", "كلمة المرور الحالية (لو عندك)"),
    ("new_pw", "كلمة المرور الجديدة"),
    ("pw_done", "تم تغيير كلمة المرور"),
    ("logout", "تسجيل الخروج"),
    ("language", "لغة التطبيق"),
    ("privacy", "الخصوصية"),
    ("read_receipts", "إيصالات القراءة"),
    ("read_receipts_hint", "لو قفلتها محدش هيعرف إنك شفت رسايله"),
    ("show_online", "إظهار إني متصل"),
    ("show_online_hint", "لو قفلتها مش هيظهر إنك Online"),
    ("last_seen", "آخر ظهور"),
    ("photo_vis", "مين يشوف صورتي"),
    ("story_vis", "مين يشوف الاستوريز"),
    ("add_by_phone", "مين يضيفني برقم موبايلي"),
    ("calls", "مين يقدر يكلمني"),
    ("all", "الكل"),
    ("contacts_only", "جهات الاتصال"),
    ("nobody", "محدش"),
    ("loading", "جاري التحميل"),
    ("err_invalid_email", "اكتب إيميل صحيح"),
    ("err_invalid_phone", "اكتب رقم صحيح بكود الدولة"),
    ("err_wrong_code", "الكود غلط، جرب تاني"),
    ("err_code_expired", "الكود انتهى، اطلب كود جديد"),
    ("err_too_many_requests", "محاولات كتير، استنى كام دقيقة"),
    ("err_network", "مش قادر أوصل للسيرفر"),
    ("err_password_too_short", "كلمة المرور لازم 8 حروف على الأقل"),
    ("err_wrong_password", "كلمة المرور الحالية غلط"),
    ("search", "بحث"),
    ("new_chat", "اختار جهة اتصال"),
    ("on_m", "على M"),
    ("invite_to_m", "ادعو للتطبيق"),
    ("pick_contacts", "اختار جهات الاتصال من موبايلك"),
    ("pick_again", "اختار جهات تانية"),
    ("picker_hint", "نصيحة: اضغط تحديد الكل في القائمة عشان تجيب كل الأرقام."),
    ("picker_unsupported", "المتصفح ده مش بيقرا جهات الاتصال. تطبيق الأندرويد هيعملها لوحده. دلوقتي ضيف بالرقم أو ابعت لينك الدعوة."),
    ("matching", "بنشوف مين على M"),
    ("invite_msg", "انضم لي على M:"),
    ("photo", "الصورة والبانر"),
    ("change_photo", "اختار صورة من المعرض"),
    ("upload_banner", "اختار بانر (صورة أو فيديو)"),
    ("banner_hint", "الفيديو لحد 20 ميجا وبيشتغل متكرر من غير صوت."),
    ("back", "رجوع"),
    ("chat_sub", "اضغط لفتح البروفايل"),
    ("no_chats", "لسه مفيش دردشات. اضغط + عشان تلاقي أصحابك."),
    ("profile_missing", "البروفايل ده مش متاح"),
    ("err_unsupported_file", "استخدم صورة JPG أو PNG أو WebP، أو فيديو MP4 أو WebM"),
    ("err_file_too_large", "الملف كبير أوي"),
    ("err_empty_file", "الملف فاضي"),
    ("err_too_many_numbers", "أرقام كتير مرة واحدة"),
    ("err_not_found", "مش موجود"),
    ("online", "متصل"),
    ("type_message", "اكتب رسالة"),
    ("send", "إرسال"),
    ("no_messages", "لسه مفيش رسايل. قول أهلاً."),
    ("my_contacts", "جهات اتصالك"),
    ("err_empty_message", "اكتب رسالة الأول"),
    ("err_message_too_long", "الرسالة طويلة أوي"),
    ("err_cannot_chat_self", "مينفعش تكلم نفسك"),
    ("stories", "الستوري"),
    ("my_story", "ستوري بتاعي"),
    ("add_story", "اضغط + عشان تضيف ستوري"),
    ("recent", "آخر التحديثات"),
    ("new_story", "ستوري جديد"),
    ("story_photo", "صورة أو فيديو"),
    ("story_text", "نص"),
    ("choose_story", "اختار صورة أو فيديو"),
    ("caption_ph", "اكتب تعليق (اختياري)"),
    ("text_ph", "اكتب ستوريك"),
    ("story_hint", "الستوري بيختفي بعد 24 ساعة. الفيديو لحد 20 ميجا."),
    ("post", "نشر"),
    ("comment_ph", "اكتب تعليق"),
    ("chat", "محادثة"),
    ("theme_bg", "خلفية المحادثة"),
    ("repost", "إعادة نشر في قصتي"),
    ("reposted", "تمت إعادة النشر"),
    ("repost_from", "أُعيد نشرها من"),
    ("comments", "التعليقات"),
    ("viewers", "شاهدها"),
    ("no_comments", "لسه مفيش تعليقات"),
    ("delete", "حذف"),
    ("translating", "بنترجم التطبيق"),
    ("translation_unavailable", "الترجمة مش متاحة دلوقتي. التطبيق هيفضل بالإنجليزي."),
    ("err_caption_too_long", "النص طويل أوي"),
    ("err_invalid_language", "اللغة دي مش مدعومة"),
    ("err_generic", "حصلت مشكلة"),
];

/// Translate a key. Falls back to English, then to the key itself.
pub fn tr(lang: &str, key: &str) -> String {
    if lang != "ar" && lang != "en" {
        if let Ok(r) = dynamic().read() {
            if let Some(t) = r.get(lang).and_then(|m| m.get(key)) {
                return t.clone();
            }
        }
    }
    let table = if lang == "ar" { AR } else { EN };
    table
        .iter()
        .chain(EN.iter())
        .find(|(k, _)| *k == key)
        .map(|(_, v)| v.to_string())
        .unwrap_or_else(|| key.to_string())
}

/// Turn a server error code into a sentence in the current language.
pub fn err_text(lang: &str, code: &str) -> String {
    let key = format!("err_{code}");
    let text = tr(lang, &key);
    if text == key { tr(lang, "err_generic") } else { text }
}
