mod auth;
mod error;
mod notify;
mod routes;

use std::{net::SocketAddr, sync::Arc};

use axum::{
    routing::{get, post},
    Router,
};
use sqlx::postgres::PgPoolOptions;
use tower_http::{cors::CorsLayer, trace::TraceLayer};

#[derive(Clone)]
pub struct AppState {
    pub db: sqlx::PgPool,
    pub jwt_secret: String,
    pub notifier: Arc<notify::Notifier>,
}

#[tokio::main]
async fn main() {
    dotenvy::dotenv().ok();
    tracing_subscriber::fmt()
        .with_env_filter(std::env::var("RUST_LOG").unwrap_or_else(|_| "info".into()))
        .init();

    let database_url = std::env::var("DATABASE_URL").expect("DATABASE_URL is required");
    let jwt_secret = std::env::var("JWT_SECRET").expect("JWT_SECRET is required");
    assert!(jwt_secret.len() >= 32, "JWT_SECRET must be at least 32 characters");

    let db = PgPoolOptions::new()
        .max_connections(10)
        .connect(&database_url)
        .await
        .expect("cannot connect to the database");
    sqlx::migrate!().run(&db).await.expect("migration failed");

    // Remove expired verification codes every 10 minutes.
    let cleanup_db = db.clone();
    tokio::spawn(async move {
        let mut tick = tokio::time::interval(std::time::Duration::from_secs(600));
        loop {
            tick.tick().await;
            let _ = sqlx::query("DELETE FROM otp_codes WHERE expires_at < now() - interval '1 day'")
                .execute(&cleanup_db)
                .await;
        }
    });

    let state = AppState {
        db,
        jwt_secret,
        notifier: Arc::new(notify::Notifier::from_env()),
    };

    let app = Router::new()
        .route("/health", get(|| async { "ok" }))
        .route("/auth/request-code", post(routes::request_code))
        .route("/auth/verify", post(routes::verify_code))
        .route("/me", get(routes::get_me).patch(routes::patch_me))
        .route("/me/password", post(routes::set_password))
        .route("/me/settings", get(routes::get_settings).patch(routes::patch_settings))
        .route("/me/contacts", get(routes::list_contacts).post(routes::add_contact_by_phone))
        .route("/invite/:code", post(routes::accept_invite))
        .layer(CorsLayer::permissive()) // development only: restrict origins before launch
        .layer(TraceLayer::new_for_http())
        .with_state(state);

    let port: u16 = std::env::var("PORT").ok().and_then(|p| p.parse().ok()).unwrap_or(8080);
    let addr = SocketAddr::from(([0, 0, 0, 0], port));
    tracing::info!("M server listening on {addr}");
    let listener = tokio::net::TcpListener::bind(addr).await.unwrap();
    axum::serve(listener, app).await.unwrap();
}
